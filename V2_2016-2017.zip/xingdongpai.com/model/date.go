package model

import (
	"gopkg.in/mgo.v2/bson"
	"time"
)

//面基
type Date struct {
	Id         bson.ObjectId `json:"id" bson:"_id"`
	ScriptId   bson.ObjectId `json:"sid" bson:"sid"`               //剧本Id
	Owner      bson.ObjectId `json:"owner" bson:"owner"`           //贴主
	Sender     bson.ObjectId `json:"sender" bson:"sender"`         //搭档
	SenderAddr string        `json:"senderAddr" bson:"senderAddr"` //搭档所在地点
	SenderTime string        `json:"senderTime" bson:"senderTime"` //可约时间 随时／周末／工作日
	Note       string        `json:"note" bson:"note"`             //备注 字数限制128字
	State      uint8         `json:"state" bson:"state"`           //状态: 等待接受(已发送)0--->已接受1/已拒绝2--->已见面3--->已付款(已收款)4
	Cue        string        `json:"cue" bson:"cue"`               //见面暗号
	Rank       uint8         `json:"rank" bson:"rank"`             //评分 1-5星 (0是未打分)
	Comment    string        `json:"comment" bson:"comment"`       //评价
	IsDelete   bool          `json:"-" bson:"isDelete"`            //帖子不物理删除
	CreatedAt  time.Time     `json:"createdAt" bson:"createdAt"`
}

type DateForm struct {
	ScriptId   string `json:"sid"`
	Owner      string `json:"owner"`
	SenderAddr string `json:"senderAddr"`
	SenderTime string `json:"senderTime"`
	Note       string `json:"note"`
}

type RankForm struct {
	Rank    uint8  `json:"rank"`
	Comment string `json:"comment"`
}
