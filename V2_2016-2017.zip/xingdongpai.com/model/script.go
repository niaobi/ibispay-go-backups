package model

import (
	"gopkg.in/mgo.v2/bson"
	"time"
	"xingdongpai.com/utils"
)

type ScriptForm struct {
	Passion   string `form:"passion"`   //剧本原型
	Script    string `form:"script"`    //剧本内容
	Type      string `form:"type"`      //剧情类型 喜剧/爱情/动作等
	Partner   string `form:"partner"`   //搭档招募要求
	Pay       bool   `form:"pay"`       //是否有片酬
	SuperCoin bool   `form:"superCoin"` //是否是超级鸟币
	Price     int64  `form:"price"`     //价格
}

//剧本
type Script struct {
	Id bson.ObjectId `json:"id" bson:"_id"`

	Owner   bson.ObjectId `json:"owner" bson:"owner"`     //作者
	Passion bson.ObjectId `json:"passion" bson:"passion"` //剧本原型

	Script  string    `json:"script" bson:"script"`   //剧本内容 不超过300字
	Type    string    `json:"type" bson:"type"`       //剧情类型 喜剧/爱情/动作等
	Partner string    `json:"partner" bson:"partner"` //搭档招募要求
	Photo   utils.Pic `json:"photo" bson:"photo"`     //图片

	Pay       bool   `json:"pay" bson:"pay"`             //是否有片酬
	SuperCoin bool   `json:"superCoin" bson:"superCoin"` //是否是超级鸟币
	Price     int64  `json:"price" bson:"price"`         //价格
	CoinName  string `json:"coinName" bson:"coinName"`   //鸟币类型

	Likes     uint64    `json:"likes" bson:"likes"`       //喜欢数
	UpdateAt  int64     `json:"updateAt" bson:"updateAt"` //更新时间
	CreatedAt time.Time `json:"createdAt" bson:"createdAt"`
}
