package model

import (
	"time"

	"gopkg.in/mgo.v2/bson"
	"xingdongpai.com/utils"
)

type User struct {
	Id bson.ObjectId `json:"id" bson:"_id"`
	//注册必填
	Phone   string `json:"phone,omitempty" bson:"phone" binding:"required"` //不可重复
	PhoneCC string `json:"phoneCC,omitempty" bson:"phoneCC" binding:"required"`
	Pwd     string `json:"pwd" bson:"pwd" binding:"required"`
	//基本属性
	Name      string    `json:"name,omitempty" bson:"name"`           //@昵称 不可重复 不可修改 最多8个汉字
	Sex       uint8     `json:"sex,omitempty" bson:"sex"`             //生理性别
	Bio       string    `json:"bio,omitempty" bson:"bio"`             //简介 最多256个汉字
	City      string    `json:"city,omitempty" bson:"city"`           //当前城市
	Lat       float64   `json:"lat,omitempty" bson:"lat"`             //纬度
	Lng       float64   `json:"lng,omitempty" bson:"lng"`             //经度
	Birthday  float64   `json:"birthday,omitempty" bson:"birthday"`   //生日 unix时间戳
	OpenType  string    `json:"openType,omitempty" bson:"openType"`   //理想搭档
	Avatar    utils.Pic `json:"avatar,omitempty" bson:"avatar"`       //头像 原图/640/320/160
	Email     string    `json:"email,omitempty" bson:"email"`         //邮箱
	UpdateAt  int64     `json:"updateAt" bson:"updateAt"`             //最后活跃时间
	CreatedAt time.Time `json:"createdAt,omitempty" bson:"createdAt"` //加入时间
	//-----鸟币相关-----
	SuperCoinEnabled bool      `json:"superCoinEnabled,omitempty" bson:"superCoinEnabled"` //是否激活超级鸟币
	CoinEnabled      bool      `json:"coinEnabled,omitempty" bson:"coinEnabled"`           //是否激活鸟币
	CoinAlias        string    `json:"coinAlias,omitempty" bson:"coinAlias"`               //鸟币别名
	Wealth           float64   `json:"wealth,omitempty" bson:"wealth"`                     //财富指数，默认为0
	Credit           float64   `json:"credit,omitempty" bson:"credit"`                     //鸟币信用，默认为0
	HasPhoto         bool      `json:"hasPhoto,omitempty" bson:"hasPhoto"`                 //是否拍摄了真人照片
	Photo            utils.Pic `json:"photo,omitempty" bson:"photo"`                       //微笑自拍 真人照片
	RmbExr           float64   `json:"rmbExr,omitempty" bson:"rmbExr"`                     //汇率(1鸟币合人民币多少)
	SkillUpdated     bool      `json:"-" bson:"skillUpdated"`                              //技能更新标记

	//-----消息板块-----
	HasNews  bool `json:"hasNews,omitempty" bson:"hasNews"`   //是否有新消息
	ReadNews int  `json:"readNews,omitempty" bson:"readNews"` //已读的消息数
	HasTask  bool `json:"hasTask,omitempty" bson:"hasTask"`   //是否有新任务(见面/交易)
	ReadTask int  `json:"readTask,omitempty" bson:"readTask"` //已读的任务数

	Likes       uint64 `json:"likes,omitempty" bson:"likes"`             //喜欢的人的数量
	DeviceToken string `json:"diviceToken,omitempty" bson:"diviceToken"` //iphone消息推送token

	Founder bool `json:"founder,omitempty" bson:"founder"` //共同发起人，黄色昵称，拥有首页推荐权限
}

type AutoRejectDealLocks struct {
	Locks map[string]bool
}

type UserForm struct {
	Name     string  `form:"name"`      //@昵称 不可重复 最多14个汉字
	Sex      uint8   `form:"sex"`       //生理性别
	Bio      string  `form:"bio"`       //简介 最多256个汉字
	City     string  `form:"city"`      //当前城市
	Lat      float64 `form:"lat"`       //纬度
	Lng      float64 `form:"lng" `      //经度
	Birthday uint64  `form:"birthday" ` //生日 unix时间戳
	OpenType string  `form:"openType"`  //喜欢的小伙伴类型
}

type MyProfile struct {
	User       User `json:"user"`
	TaskNum    int  `json:"taskNum"`    //任务数
	UnReadNews int  `json:"unReadNews"` //新请求数
}

type PwdUpdateForm struct {
	OldPwd string `form:"oldPwd"` //旧密码
	NewPwd string `form:"newPwd"` //新密码
}
