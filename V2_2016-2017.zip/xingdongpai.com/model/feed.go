package model

import (
	"gopkg.in/mgo.v2/bson"
	"time"
)

type Feed struct {
	Id        bson.ObjectId `json:"id" bson:"_id"`
	Uid       bson.ObjectId `json:"uid" bson:"uid"`           //user Id
	SId       bson.ObjectId `json:"sid" bson:"sid"`           //skill id or script id
	FeedType  int8          `json:"feedType" bson:"feedType"` //0:skill 1:script
	CreatedAt time.Time     `json:"createdAt" bson:"createdAt"`
}
