package model

import (
	"gopkg.in/mgo.v2/bson"
	"time"
)

type News struct {
	Id     bson.ObjectId `json:"id" bson:"_id"`
	ToUser bson.ObjectId `json:"toUser" bson:"toUser"`
	DId    bson.ObjectId `json:"did" bson:"did"` //deal id or date id
	Msg    string        `json:"msg" bson:"msg"`
	//0:官方通知+msg
	//100:deal 购买请求已发送(等待对方接单 灰色)                     	101:deal 想购买你的技能,是否接受(需要确认 黄色) (若为鸟币回流 红色正文)
	//102:deal 已接单,可以和我联系了(等待对方服务 蓝色)              	103:deal 已接受xx的订单，请联系对方提供服务（联系对方 蓝色）
	//104:deal xo婉拒了你的订单(订单被拒 灰色)                      	105:deal 已拒绝了xx的订单(已拒订单 灰色)
	//106:deal 已完成交易(行动完成 灰色)								107:deal 已完成交易(行动完成 灰色)
	//200:date 已请求入戏(等待对方接戏 灰色)                         	201:date 想和你一起玩剧本(需要确认 黄色)
	//202:date 已接受入戏请求,可以和我联系了(联系对方 蓝色）           	203:date 已接受了xx的入戏请求,可以和对方联系了（联系对方 蓝色）
	//204:date xo婉拒了你的入戏请求(约戏被拒 灰色)                    	205:date 已经拒绝了xx的入戏请求(已拒绝入戏)
	//206(无片酬情况):date 已见面(行动完成 灰色)						207(无片酬情况):date 已见面(行动完成 灰色)
	//208:date 对方稍后会支付给你片酬(已见面,待收片酬 红色)				209:date 见面结束后，请支付给对方片酬(等待支付片酬 红色)
	//210:date 已见面，已收取片酬(行动完成 灰色)						211:date 已见面，已支付片酬(行动完成 灰色)
	NewsType       int16     `json:"newsType" bson:"newsType"`
	NeedAutoReject bool      `json:"needAutoReject" bson:"needAutoReject"` //"普通鸟币回流请求"需要24小时自动拒绝回流
	UpdateAt       int64     `json:"updateAt" bson:"updateAt"`             //更新时间
	CreatedAt      time.Time `json:"createdAt" bson:"createdAt"`
}
