package freecoin

import (
	"gopkg.in/mgo.v2/bson"
	"time"
)

//一次交易 deal
type Deal struct {
	Id       bson.ObjectId `json:"id" bson:"_id"`
	Buyer    bson.ObjectId `json:"buyer" bson:"buyer" binding:"required"`    //买家 出鸟币的人
	Seller   bson.ObjectId `json:"seller" bson:"seller"  binding:"required"` //卖家 收鸟币的人
	CoinTLId bson.ObjectId `json:"ctlid" bson:"ctlid"`                       //交易流水表

	SkillId    bson.ObjectId `json:"sid" bson:"sid"`               //交易内容
	Price      int64         `json:"price" bson:"price"`           //卖方价格
	CounterBid int64         `json:"counterBid" bson:"counterBid"` //买家出价
	CoinName   string        `json:"coinName" bson:"coinName"`     //买家出价使用的鸟币
	SuperCoin  bool          `json:"superCoin" bson:"superCoin"`   //是否是超级鸟币
	Pact       string        `json:"pact" bson:"pact"`             //交易的约定 如:个人主页，买家定制需求
	Note       string        `json:"note" bson:"note"`             //交易的备注
	State      uint8         `json:"state" bson:"state"`           //交易状态: 待接单(已下单)0--->已接单1(已付款)/已拒绝2--->已完成3
	Rank       uint8         `json:"rank" bson:"rank"`             //评分 1-5星 (0是未打分)
	Comment    string        `json:"comment" bson:"comment"`       //评价
	UpdateAt   int64         `json:"updateAt" bson:"updateAt"`     //状态更新时间
	CreatedAt  time.Time     `json:"createdAt" bson:"createdAt"`   //交易时间
}

type DealForm struct {
	Seller     string `json:"seller""`
	SkillId    string `json:"sid"`
	Price      int64  `json:"price"`
	CounterBid int64  `json:"counterBid"`
	CoinName   string `json:"coinName"`
	SuperCoin  bool   `json:"superCoin"`
	Pact       string `json:"pact"`
	Note       string `json:"note"`
}
