package freecoin

import (
	"gopkg.in/mgo.v2/bson"
	"time"
)

//技能的列表 表名：skillIds
type SkillIds struct {
	Id        bson.ObjectId   `json:"id" bson:"_id"`
	List      []bson.ObjectId `json:"list" bson:"list"`
	CreatedAt time.Time       `json:"createdAt" bson:"createdAt"`
}
