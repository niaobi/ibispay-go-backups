package freecoin

import (
	"gopkg.in/mgo.v2/bson"
	"time"
)

//发行的鸟币版本 coinVision
//发行(转账或交易)鸟币时，版本号+1；若技能有更新，新建技能集合
type CoinV struct {
	Id          bson.ObjectId `json:"id" bson:"_id"`
	CoinTId     bson.ObjectId `json:"ctid" bson:"ctid"  binding:"required"`          //鸟币类型id
	SkillIdList bson.ObjectId `json:"sidl" bson:"sidl"   binding:"required"`         //技能集合快照
	Vision      uint64        `json:"vision" bson:"vision" binding:"required"`       //发行时版本号每次+1
	CreatedAt   time.Time     `json:"createdAt" bson:"createdAt" binding:"required"` //发行时间
}

//拥有的同一个版本鸟币总数 coinVT
//收入方 tally+正，支出方 tally+负
type CoinVTally struct {
	Id    bson.ObjectId `json:"id" bson:"_id"`
	Owner bson.ObjectId `json:"owner" bson:"owner" binding:"required"` //持有者
	CoinV CoinV         `json:"coinV" bson:"coinV" binding:"required"` //鸟币版本
	Tally int64         `json:"tally" bson:"tally" binding:"required"` //同一个版本的拥有总量
}
