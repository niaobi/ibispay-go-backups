package freecoin

import (
	"gopkg.in/mgo.v2/bson"
	"xingdongpai.com/model"
)

//发行的鸟币类型 coinType
type CoinT struct {
	Id        bson.ObjectId `json:"id" bson:"_id"`
	Alias     string        `json:"alias" bson:"alias" binding:"required"`         //鸟币别名,"xxx币", 唯一索引, 不可更改
	SuperCoin bool          `json:"superCoin" bson:"superCoin" binding:"required"` //是否是超级鸟币
	Creator   bson.ObjectId `json:"creator" bson:"creator" binding:"required"`     //鸟币发行者
}

//赚到同一个类型的鸟币总数 coinTT
//收入方 tally+正，支出方 tally+负
type CoinTTally struct {
	Id       bson.ObjectId `json:"id" bson:"_id"`
	Owner    bson.ObjectId `json:"owner" bson:"owner" binding:"required"` //持有者
	CoinType *CoinT        `json:"coinT" bson:"coinT" binding:"required"` //鸟币类型
	Tally    int64         `json:"tally" bson:"tally" binding:"required"` //同一个类型的拥有总量
}

type CoinTTallyReturn struct {
	Id       bson.ObjectId `json:"id"`
	Owner    model.User    `json:"owner"`
	CoinType CoinT         `json:"coinT"`
	Tally    int64         `json:"tally"`
}

type CoinTTReturn struct {
	Tally int64 `json:"tally"`
}
