package freecoin

import (
	"gopkg.in/mgo.v2/bson"
	"time"
)

//热情
type Passion struct {
	Id           bson.ObjectId `json:"id" bson:"_id"`
	Owner        bson.ObjectId `json:"owner" bson:"owner"`
	Md           bool          `json:"md" bson:"md"  form:"md"`                              //是否是markdown编辑器发布的
	Title        string        `json:"title" bson:"title" form:"title"`                      //标题
	Desc         string        `json:"desc" bson:"desc"`                                     //缩略内容，不超过128字
	DescText     string        `json:"descText" bson:"descText" form:"descText"`             //不带格式的内容，用于搜索
	DescMarkdown string        `json:"descMarkdown" bson:"descMarkdown" form:"descMarkdown"` //markdown格式的内容 不超过5000字
	DescHtml     string        `json:"descHtml" bson:"descHtml"  form:"descHtml"`            //html格式的内容 不超过5000字
	Views        uint64        `json:"views" bson:"views"`                                   //查看次数
	UpdateAt     int64         `json:"updateAt" bson:"updateAt"`                             //更新时间
	CreatedAt    time.Time     `json:"createdAt" bson:"createdAt"`
}
