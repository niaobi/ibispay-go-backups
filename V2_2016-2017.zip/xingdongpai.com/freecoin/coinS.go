package freecoin

import (
	"gopkg.in/mgo.v2/bson"
	"time"
)

//转账后双方鸟币的持有状态明细 coinState
//情况1.买家或转账方使用自己发行的鸟币
//情况2.买家或转账方使用第三方发行的鸟币
//情况3.买家或转账方使用收款人方发行的鸟币(即收款人鸟币回收)
type CoinS struct {
	Id        bson.ObjectId `json:"id" bson:"_id"`
	User      bson.ObjectId `json:"user" bson:"user" binding:"required"`           //买家或卖家
	CoinTLId  bson.ObjectId `json:"ctlid" bson:"ctlid" binding:"required"`         //转账流水id
	CoinVId   bson.ObjectId `json:"cvid" bson:"cvid"`                              //使用的鸟币版本
	CoinT     *CoinT        `json:"coinT" bson:"coinT"`                            //使用的鸟币类型
	Count     int64         `json:"count" bson:"count"`                            //数量 注意：买家为负数，卖家为正数
	CreatedAt time.Time     `json:"createdAt" bson:"createdAt" binding:"required"` //交易时间
}
type CoinSTReturn struct {
	Tally int64 `json:"tally"`
}

//转账流水记录 coinTL
//每当有新的交易和转账就新建一个
//一个log下，可以对应不同鸟币版本的转账明细，
//如：转账总数200xx币是由 100xx币版本3＋50xx币版本2＋50xx币版本1 同时转账后得到的
//鸟币版本使用的优先级为倒序
type CoinTransferLog struct {
	Id         bson.ObjectId `json:"id" bson:"_id"`
	FromUser   bson.ObjectId `json:"fromUser" bson:"fromUser" binding:"required"`
	ToUser     bson.ObjectId `json:"toUser" bson:"toUser" binding:"required"`
	Tally      int64         `json:"tally" bson:"tally" binding:"required"`         //转账总数
	CoinT      *CoinT        `json:"coinT" bson:"coinT" binding:"required"`         //鸟币类型
	Note       string        `json:"note" bson:"note"`                              //转账备忘
	CoinGoBack bool          `json:"coinGoBack" bson:"coinGoBack"`                  //是否是鸟币回流
	CreatedAt  time.Time     `json:"createdAt" bson:"createdAt" binding:"required"` //交易时间
}

type TransferLocks struct {
	Locks map[string]bool
}

//普通鸟币回流被拒记录 coinRL
//鸟币回流接受时间未24小时，超时未接受将自动视为拒绝回收
//如果出价<卖价,拒绝不算做拒绝回流,也不自动拒绝
type CoinGoBackRejectLog struct {
	Id        bson.ObjectId `json:"id" bson:"_id"`
	DealId    bson.ObjectId `json:"dealId" bson:"dealId"`
	FromUser  bson.ObjectId `json:"fromUser" bson:"fromUser"`
	ToUser    bson.ObjectId `json:"toUser" bson:"toUser"`       //creator 鸟币发行者
	CoinT     *CoinT        `json:"coinT" bson:"coinT"`         //鸟币类型
	Tally     int64         `json:"tally" bson:"tally"`         //转账总数
	Accpet    bool          `json:"accpet" bson:"accpet"`       //回流已接受
	CreatedAt time.Time     `json:"createdAt" bson:"createdAt"` //被拒时间
}
type CoinRLReturn struct {
	Tally int64 `json:"tally"`
}

//鸟币详情
type MyCoinDetailReturn struct {
	MyCoinCount     int64 `json:"myCoinCount"`
	EarnedCoinCount int64 `json:"earnedCoinCount"`
	RejectNum       int64 `json:"rejectNum"`
	TransferNum     int64 `json:"transferNum"`
}

//转账
type TransferForm struct {
	CoinName  string `json:coinName`    //鸟币名称
	SuperCoin bool   `json:"superCoin"` //是否是超级鸟币
	Note      string `json:"note"`      //转账备忘
	Count     int64  `json:"count"`     //数量
	ToName    string `json:"toName"`    //通过用户名转账
	ToPhone   string `json:"toPhone"`   //通过电话号码转账
	PhoneCC   string `json:"phoneCC"`
}
