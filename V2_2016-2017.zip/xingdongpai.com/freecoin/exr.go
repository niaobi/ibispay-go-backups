package freecoin

import (
	"gopkg.in/mgo.v2/bson"
	"time"
)

type ExrOf2Coin struct {
	CoinTId2 bson.ObjectId `json:"ctid2" bson:"ctid2"  binding:"required"`
	Exr      float64       `json:"exr" bson:"exr"  binding:"required"`           //最后一次交易汇率 ctid1:coin2
	UpdateAt time.Time     `json:"updateAt" bson:"updateAt" bingding:"required"` //最后一次交易时间
}

//不同鸟币之间的汇率 exr
type ExchangeRate struct {
	CoinTId1 bson.ObjectId `json:"ctid1" bson:"ctid1"  binding:"required"`
	Exrs     []ExrOf2Coin  `json:"exrs" bson:"exrs"  binding:"required"`
}
