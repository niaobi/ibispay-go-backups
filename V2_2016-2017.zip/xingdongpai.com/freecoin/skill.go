package freecoin

import (
	"gopkg.in/mgo.v2/bson"
	"time"
	"xingdongpai.com/utils"
)

//技能
//isSnap=false 第一条主贴
//InStock=true 当前最新版本
type Skill struct {
	Id bson.ObjectId `json:"id" bson:"_id"`

	Owner   bson.ObjectId `json:"owner" bson:"owner"`
	Passion bson.ObjectId `json:"passion" bson:"passion"` //背景故事
	GroupId bson.ObjectId `json:"gid" bson:"gid"`         //主贴和备份贴的组

	Title    string      `json:"title" bson:"title"`       //不可修改,不超过10个中文
	Desc     string      `json:"desc" bson:"desc"`         //描述
	Pics     []utils.Pic `json:"pics" bson:"pics"`         //图片 可选1334/1136/320
	Price    uint64      `json:"price" bson:"price"`       //价格，0则为超级鸟币，>0为普通鸟币
	Unit     string      `json:"unit" bson:"unit" `        //单位，如每单／每克／每次／每件
	Category string      `json:"category" bson:"category"` //大分类，日常技能／专业服务／实物出售
	Tag      string      `json:"tag" bson:"tag"`           //主标签，如修电脑、做指甲等，不超过5个中文
	//服务方式 1.去他家 2.来我家 3.约地方 4.线上或者其他
	CanGo      bool   `json:"canGo" bson:"canGo"`
	CanCome    bool   `json:"canCome" bson:"canCome"`
	CanCafe    bool   `json:"canCafe" bson:"canCafe"`
	CanOnline  bool   `json:"canOnline" bson:"canOnline"`
	GoNote     string `json:"goNote" bson:"goNote" `
	ComeNote   string `json:"comeNote" bson:"comeNote"`
	CafeNote   string `json:"cafeNote" bson:"cafeNote" `
	OnlineNote string `json:"onlineNote" bson:"onlineNote"`

	Likes     uint64    `json:"likes" bson:"likes"`         //喜欢数
	InStock   bool      `json:"inStock" bson:"inStock"`     //是否出售中
	IsSnap    bool      `json:"isSnap" bson:"isSnap"`       //是否是备份版本
	UpdateAt  int64     `json:"updateAt" bson:"updateAt"`   //更新时间
	CreatedAt time.Time `json:"createdAt" bson:"createdAt"` //创建时间

	PassionDetail Passion `json:"passionDetail" bson:"-"` //return
}

type SkillForm struct {
	Passion string `form:"passion"` //背景故事

	Title    string `form:"title"`    //不可修改,不超过14个中文
	Desc     string `form:"desc"`     //描述，不超过300字
	Price    uint64 `form:"price"`    //价格，0则为超级鸟币，>0为普通鸟币
	Unit     string `form:"unit"`     //单位，如每单／每克／每次／每件
	Category string `form:"category"` //大分类，常用技能／专业服务／实物出售
	Tag      string `form:"tag"`      //主标签，如修电脑、做指甲等，不超过5个中文
	//服务方式 1.去他家 2.来我家 3.约地方 4.线上或者其他
	CanGo      bool   `form:"canGo"`
	CanCome    bool   `form:"canCome"`
	CanCafe    bool   `form:"canCafe"`
	CanOnline  bool   `form:"canOnline"`
	GoNote     string `form:"goNote"`
	ComeNote   string `form:"comeNote"`
	CafeNote   string `form:"cafeNote"`
	OnlineNote string `form:"onlineNote"`
}
