package main

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"github.com/gin-gonic/contrib/static"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"os/exec"
	"runtime"
	"strings"
	"syscall"

	"github.com/fvbock/endless"
	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/scrypt"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"xingdongpai.com/config"
	"xingdongpai.com/controller"
	"xingdongpai.com/errs"
	"xingdongpai.com/freecoin"
	"xingdongpai.com/model"
)

//部署时 安装golang
//部署时 安装mongodb
//部署时 安装图片处理库 https://github.com/DAddYE/vips
//部署时 在FontDir放置字体文件
//部署时 在PublicDir放置web网站
//部署时 在HtmlDir放置隐私协议等单网页
//升级app时更改了数据结构需要给api地址加上版本号
//定时更新鸟币汇率

var (
	pid                 int
	transionLocks       freecoin.TransferLocks
	autoRejectDealLocks model.AutoRejectDealLocks
)

func main() {
	numCPUs := runtime.NumCPU()
	runtime.GOMAXPROCS(numCPUs)

	os.MkdirAll(config.PublicDir, os.FileMode(0777))
	os.MkdirAll(config.HtmlDir, os.FileMode(0777))
	os.MkdirAll(config.PicDir, os.FileMode(0777))
	os.MkdirAll(config.FontDir, os.FileMode(0777))

	transionLocks := new(freecoin.TransferLocks)
	transionLocks.Locks = make(map[string]bool)

	autoRejectDealLocks := new(model.AutoRejectDealLocks)
	autoRejectDealLocks.Locks = make(map[string]bool)

	session := getSession()
	db := session.DB(config.MgoDB)
	addIndex(db)

	gin.SetMode(gin.ReleaseMode)
	g := gin.Default()

	g.Use(errHandler())
	g.Use(dbHandler(session))
	g.Use(static.Serve("/", static.LocalFile(config.PublicDir, true)))

	g.Static("/html", "./html")
	g.StaticFS("/files/font", http.Dir(config.FontDir))
	g.StaticFS("/files/pic", http.Dir(config.PicDir))
	g.LoadHTMLGlob("templates/*")

	user := g.Group("/user")
	{
		user.POST("/register", controller.Register)
		user.POST("/login", controller.Login)
		user.Use(authHandler(db))
		{
			user.Use(autoRDLockHandler(autoRejectDealLocks))
			{
				user.GET("/profile", controller.Profile)
				user.GET("/profilePage/:uid", controller.ProfilePage)
			}
			user.POST("/finishRegister", controller.FinishRegister)
			user.PUT("/editProfileWithPhoto", controller.EditProfileWithPhoto)       //带头像
			user.PUT("/editProfileWithoutPhoto", controller.EditProfileWithOutPhoto) //不带头像
			user.PUT("/editRealPhoto", controller.EditRealPhoto)                     //真人头像
			user.PUT("/updateEmail/:email", controller.UpdateEmail)
			user.PUT("/updatePwd", controller.UpdatePwd)
		}
	}

	coinT := g.Group("/coinT", authHandler(db))
	{
		coinT.POST("new/:alias", controller.NewCoinType)
	}

	passion := g.Group("/passion")
	{
		passion.GET("/html/:pid", controller.PassionHtmlById)
		passion.Use(authHandler(db))
		{
			passion.POST("/new", controller.NewPassion)
			passion.PUT("/edit/:pid", controller.EditPassion)
			passion.GET("/listById/:uid/:skip", controller.PassionListById)
			passion.GET("/passionById/:pid/:md", controller.PassionById)
		}
	}

	skill := g.Group("/skill", authHandler(db))
	{
		skill.POST("/new", controller.NewSkill)
		skill.POST("/newPics", controller.NewSkillPics) //带图片
		skill.GET("/list/:skip", controller.SkillList)
		skill.GET("/listByUser/:uid/:skip", controller.SkillListByUser)
		skill.GET("/listByCoinName/:coinName/:super/:skip", controller.SkillListByCoinName)
		skill.GET("/listByCoinVision/:cvid/:skip", controller.SkillListByCoinVision)
		skill.GET("/skillById/:sid", controller.SkillById)
		skill.PUT("/updateSkill/:sid", controller.UpdateSkill)
	}

	script := g.Group("/script", authHandler(db))
	{
		script.POST("/new", controller.NewScript)
		script.POST("/newPic", controller.NewScriptPic) //带图片
		script.GET("/scriptById/:sid", controller.ScriptById)
		script.PUT("/updateScript/:sid", controller.UpdateScript)
		script.PUT("/updatePic/:sid", controller.UpdateScriptPic)
	}

	feed := g.Group("/feed", authHandler(db))
	{
		feed.GET("/list/:skip", controller.FeedList)
		feed.GET("/myListById/:uid/:skip", controller.MyFeedList)
	}

	coinS := g.Group("/coinS", authHandler(db))
	{
		coinS.Use(lockHandler(transionLocks))
		{
			coinS.POST("/transfer", controller.TransferCoin)
		}
		coinS.GET("/coinTEarned/:super/:skip", controller.CoinTypeEarned)
		coinS.GET("/coinAllVision/:coinName/:super/:skip", controller.CoinAllVision)
		coinS.GET("/coinDetail/:super", controller.CoinDetail)
		coinS.GET("/coinGoBackRejectedList/:skip", controller.CoinGoBackRejectedList)
	}

	deal := g.Group("/deal", authHandler(db))
	{
		deal.POST("/new", controller.NewDeal)
		deal.GET("/dealById/:did", controller.DealById)
		deal.PUT("/reject/:did", controller.RejectDeal)
		deal.Use(lockHandler(transionLocks))
		{
			deal.PUT("/accept/:did", controller.AcceptDeal)
		}
		deal.PUT("/rank/:did", controller.RankDeal)
		deal.PUT("/close/:did", controller.CloseDeal)
	}

	date := g.Group("/date", authHandler(db))
	{
		date.POST("/new", controller.NewDate)
		date.GET("/dateById/:did", controller.DateByID)
		date.PUT("/reject/:did", controller.RejectDate)
		date.PUT("/accept/:did", controller.AcceptDate)
		date.PUT("/met/:did", controller.Met)
		date.Use(lockHandler(transionLocks))
		{
			date.PUT("/pay/:did", controller.Pay)
		}
		date.PUT("/rank/:did", controller.RankDate)
	}

	news := g.Group("/news", authHandler(db))
	{
		news.GET("/list/:skip", controller.NewsList)
		news.GET("/task/:skip", controller.TaskList)
	}

	g.GET("/reboot/:pwd", func(c *gin.Context) {
		if c.Param("pwd") == "server" {
			cmd := exec.Command("go", "build", "-o", "action", "main.go")
			err := cmd.Run()
			errs.Check400(c, err, errs.E1000)
			cmd = exec.Command("kill", "-1", fmt.Sprintf("%d", pid))
			err = cmd.Run()
			errs.Check400(c, err, errs.E1000)
			c.String(http.StatusOK, "ok")
		}
	})

	server := endless.NewServer(":6180", g)
	server.BeforeBegin = func(add string) {
		log.Printf("Actual pid is %d", syscall.Getpid())
		pid = syscall.Getpid()

		file, err := os.OpenFile(getPidPath(), os.O_CREATE|os.O_WRONLY, os.FileMode(0775))
		if err != nil {
			log.Println(err)
			return
		}
		defer file.Close()

		writeInfo(syscall.Getpid())
	}
	err := server.ListenAndServe()
	log.Println(err)

}

func getSession() *mgo.Session {
	session, err := mgo.Dial(config.MgoAddr)
	if err != nil {
		panic(err)
	}
	session.SetMode(mgo.Monotonic, true)
	return session
}

func addIndex(db *mgo.Database) {
	checkErr := func(err error) {
		if err != nil {
			panic(err)
		}
	}

	//user index
	index := mgo.Index{Key: []string{"phone"}, DropDups: true, Background: true, Unique: true}
	err := db.C("user").EnsureIndex(index)
	checkErr(err)

	index = mgo.Index{Key: []string{"phone", "pwd"}, DropDups: true, Background: true}
	err = db.C("user").EnsureIndex(index)
	checkErr(err)

	index = mgo.Index{Key: []string{"name"}, DropDups: true, Background: true, Unique: true}
	err = db.C("user").EnsureIndex(index)
	checkErr(err)

	//coinState index
	index = mgo.Index{Key: []string{"user"}, DropDups: true, Background: true}
	err = db.C("coinS").EnsureIndex(index)
	checkErr(err)

	index = mgo.Index{Key: []string{"user", "cvid"}, DropDups: true, Background: true}
	err = db.C("coinS").EnsureIndex(index)
	checkErr(err)

	//coinType index
	index = mgo.Index{Key: []string{"alias", "superCoin"}, DropDups: true, Background: true}
	err = db.C("coinT").EnsureIndex(index)
	checkErr(err)

	index = mgo.Index{Key: []string{"creator", "superCoin"}, DropDups: true, Background: true}
	err = db.C("coinT").EnsureIndex(index)
	checkErr(err)

	//coinVision index
	index = mgo.Index{Key: []string{"ctid"}, DropDups: true, Background: true}
	err = db.C("coinV").EnsureIndex(index)
	checkErr(err)

	//deal index
	index = mgo.Index{Key: []string{"buyer"}, DropDups: true, Background: true}
	err = db.C("deal").EnsureIndex(index)
	checkErr(err)

	index = mgo.Index{Key: []string{"seller"}, DropDups: true, Background: true}
	err = db.C("deal").EnsureIndex(index)
	checkErr(err)

	index = mgo.Index{Key: []string{"skill"}, DropDups: true, Background: true}
	err = db.C("deal").EnsureIndex(index)
	checkErr(err)

	//skill index
	index = mgo.Index{Key: []string{"isSnap", "inStock"}, DropDups: true, Background: true}
	err = db.C("user").EnsureIndex(index)
	checkErr(err)

	index = mgo.Index{Key: []string{"owner"}, DropDups: true, Background: true}
	err = db.C("skill").EnsureIndex(index)
	checkErr(err)
}

//middleware
func errHandler() gin.HandlerFunc {
	return func(c *gin.Context) {
		defer errs.CatchPanic()
		c.Next()
	}
}

func dbHandler(session *mgo.Session) gin.HandlerFunc {
	return func(c *gin.Context) {
		s := session.Clone()
		c.Set("db", s.DB(config.MgoDB))
		defer s.Close()
		c.Next()
	}
}

func authHandler(db *mgo.Database) gin.HandlerFunc {
	return func(c *gin.Context) {
		unauthorized := func() {
			http.Error(c.Writer, errs.E1003, http.StatusBadRequest)
			return
		}

		checkUser := func(username, password string) model.User {
			safePwd, _ := scrypt.Key([]byte(password), []byte(config.PwdSalt), 16384, 8, 1, 32)
			strSafePwd := fmt.Sprintf("%x", safePwd)
			u := model.User{}
			db.C("user").Find(bson.M{"phone": username, "pwd": strSafePwd}).One(&u)
			return u
		}

		auth := c.Request.Header.Get("Authorization")
		if len(auth) < 6 || auth[:6] != "Basic " {
			unauthorized()
		}

		b, err := base64.StdEncoding.DecodeString(auth[6:])
		if err != nil {
			unauthorized()
		}

		tokens := strings.SplitN(string(b), ":", 2)
		if len(tokens) != 2 {
			unauthorized()
		}

		user := checkUser(tokens[0], tokens[1])
		if !bson.IsObjectIdHex(user.Id.Hex()) {
			unauthorized()
		}

		c.Set(gin.AuthUserKey, user)
	}
}

func lockHandler(locks *freecoin.TransferLocks) gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Set("lock", locks)
	}
}

func autoRDLockHandler(locks *model.AutoRejectDealLocks) gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Set("ARDLock", locks)
	}
}

func getPidPath() string {
	return config.RootDir + "/pid"
}

func writeInfo(pid int) error {
	type PidModel struct {
		PId int `json:"pid"`
	}

	pidModel := new(PidModel)
	pidModel.PId = pid
	data, err := json.Marshal(pid)
	if err != nil {
		return err
	}
	return ioutil.WriteFile(getPidPath(), data, os.FileMode(0775))
}
