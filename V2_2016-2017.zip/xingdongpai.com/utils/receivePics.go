package utils

import (
	"errors"
	"fmt"
	"github.com/SKAhack/go-shortid"
	"github.com/daddye/vips"
	"github.com/gin-gonic/gin"
	"io/ioutil"
	"os"
)

type PicMeta struct {
	PId    string `json:"pid" bson:"pid"`
	W      int    `json:"w" bson:"w"`
	H      int    `json:"h" bson:"h"`
	Format string `json:"f" bson:"f"`
}

type Pic struct {
	Thumbnail PicMeta `json:"thumbnail" bson:"thumbnail"`
	Middle    PicMeta `json:"middle" bson:"middle"`
	Large     PicMeta `json:"large" bson:"large"`
	Largest   PicMeta `json:"largest" bson:"largest"` //原图
}

//图片字段为"files"
func ReceivePics(c *gin.Context, picDir string) ([]Pic, error) {
	//接收图片
	g := shortid.Generator()
	pics := []Pic{}
	files := c.Request.MultipartForm.File["files"]
	for _, file := range files {
		//先接收原图
		f, err := file.Open()
		if err != nil {
			fmt.Fprintf(os.Stderr, "revice file error:%v\n", err)
			continue
		}
		defer f.Close()

		inBuf, err := ioutil.ReadAll(f)
		if err != nil {
			fmt.Fprintf(os.Stderr, "read file error:%v\n", err)
			continue
		}

		//移动图片
		pid := g.Generate()
		picFullDir := fmt.Sprintf("%s/%s.jpg", picDir, pid)
		err = ioutil.WriteFile(picFullDir, inBuf, os.ModePerm)
		if err != nil {
			fmt.Fprintf(os.Stderr, "move file error:%v\n", err)
			continue
		}

		//获取图片信息
		imgFile, err := os.Open(picFullDir)
		if err != nil {
			fmt.Fprintf(os.Stderr, "Impossible to open the file:%s: %v\n", imgFile.Name(), err)
			continue
		}
		defer imgFile.Close()
		format := GetFormat(imgFile)
		w, h := GetJpgDimensions(imgFile)

		//添加到图片数组
		pic := Pic{
			Largest: PicMeta{
				PId:    pid,
				W:      w,
				H:      h,
				Format: format,
			},
		}
		pics = append(pics, pic)
	}

	if len(pics) != 0 {
		return pics, nil
	} else {
		return nil, errors.New("error")
	}
}

func ResizePics(pics []Pic, picDir string, large int, middle int, thumbnail int) ([]Pic, error) {
	newPics := []Pic{}
	for _, pic := range pics {
		largestPicDir := fmt.Sprintf("%s/%s.jpg", picDir, pic.Largest.PId)
		file, err := os.Open(largestPicDir)
		if err != nil {
			continue
		}
		defer file.Close()
		inBuf, err := ioutil.ReadAll(file)
		if err != nil {
			continue
		}

		var getNewPicDir = func(meta PicMeta) string {
			return fmt.Sprintf("%s/%s.jpg", picDir, meta.PId)
		}
		var resize = func(meta PicMeta) {
			options := vips.Options{
				Width:        meta.W,
				Height:       meta.H,
				Crop:         true,
				Extend:       vips.EXTEND_WHITE,
				Interpolator: vips.BILINEAR,
				Gravity:      vips.CENTRE,
				Quality:      90,
			}
			buf, _ := vips.Resize(inBuf, options)
			newPicDir := getNewPicDir(meta)
			ioutil.WriteFile(newPicDir, buf, os.ModePerm)
		}
		var onlyCopy = func(meta PicMeta) {
			newPicDir := getNewPicDir(meta)
			CopyFileContents(largestPicDir, newPicDir)
		}

		var newPic Pic
		newPic.Largest = pic.Largest
		var meta PicMeta
		meta.Format = pic.Largest.Format

		longer := pic.Largest.H
		if pic.Largest.W > pic.Largest.H {
			longer = pic.Largest.W
		}
		largePid := fmt.Sprintf("%s_%s", pic.Largest.PId, "large")
		middlePid := fmt.Sprintf("%s_%s", pic.Largest.PId, "middle")
		thumbnailPid := fmt.Sprintf("%s_%s", pic.Largest.PId, "thumbnail")
		if longer > large {
			meta.PId = largePid
			scale := float64(large) / float64(longer)
			meta.W = int(scale * float64(pic.Largest.W))
			meta.H = int(scale * float64(pic.Largest.H))
			resize(meta)
		} else {
			meta.PId = largePid
			meta.W = pic.Largest.W
			meta.H = pic.Largest.H
			onlyCopy(meta)
		}
		newPic.Large = meta

		if longer > middle {
			scale := float64(middle) / float64(longer)
			meta.W = int(scale * float64(pic.Largest.W))
			meta.H = int(scale * float64(pic.Largest.H))
			meta.PId = middlePid
			resize(meta)
		} else {
			meta.PId = middlePid
			meta.W = pic.Largest.W
			meta.H = pic.Largest.H
			onlyCopy(meta)
		}
		newPic.Middle = meta

		if longer > thumbnail {
			scale := float64(thumbnail) / float64(longer)
			meta.W = int(scale * float64(pic.Largest.W))
			meta.H = int(scale * float64(pic.Largest.H))
			meta.PId = thumbnailPid
			resize(meta)
		} else {
			meta.PId = thumbnailPid
			meta.W = pic.Largest.W
			meta.H = pic.Largest.H
			onlyCopy(meta)
		}
		newPic.Thumbnail = meta

		newPics = append(newPics, newPic)
	}

	if len(newPics) > 0 {
		return newPics, nil
	} else {
		return nil, errors.New("error")
	}
}
