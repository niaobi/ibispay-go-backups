package common

import (
	"github.com/asaskevich/govalidator"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"gopkg.in/mgo.v2/txn"
	"log"
	"math"
	"time"
	"xingdongpai.com/config"
	"xingdongpai.com/freecoin"
	"xingdongpai.com/model"
)

type M map[string]interface{}

func RefreshDataInBG(user *model.User) {
	//后台继续执行
	go func(user *model.User) {
		session, err := mgo.Dial(config.MgoAddr)
		if err != nil {
			log.Println(err.Error())
			return
		}
		session.SetMode(mgo.Monotonic, true)
		db := session.DB(config.MgoDB)
		defer session.Close()

		checkErr2 := func(err error) bool {
			if err != nil {
				return true
			} else {
				return false
			}
		}

		//鸟币激活后才有鸟币名称，才计算鸟币信用和财富指数
		if govalidator.IsNull(user.CoinAlias) {
			return
		}
		//==============刷新鸟币信用================
		//发行出去的鸟币拥有3种状态：
		//状态A:已回流 100% = 1
		//状态B:未回流 61.8034% = Φ
		//	未回流说明信任存在
		//状态C:拒绝回收 5.571294% = 1/17.9491525
		//	鸟币回流被拒绝后，发行者信用值会降低；若主动向债主提供服务，则可以立刻恢复正常信用值
		//
		//如果存在状态C: 鸟币信用 = (B*B个数＋C*C个数) / (B个数+C个数)
		//如果不存在状态C: 鸟币信用 = (A*A个数+B*B个数) / (A个数+B个数)
		//
		//评级：
		//极差：0.0% < 鸟币信用 < 23.6068%
		//差等：23.6068% <= 鸟币信用 < 50.0%
		//中等：50.0% <= 鸟币信用 < 61.8034%
		//可信：61.8034% <= 鸟币信用 < 76.3932%
		//优秀：76.3932% <= 鸟币信用 < 100.0%

		//计算B：我发行的普通鸟币总数
		coinType := freecoin.CoinT{}
		err = db.C("coinT").Find(bson.M{"creator": user.Id, "superCoin": false}).One(&coinType)
		myCoinTT := freecoin.CoinTTally{}
		if checkErr2(err) {
			myCoinTT.Tally = 0
		} else {
			err = db.C("coinTT").Find(M{"owner": user.Id, "coinT._id": coinType.Id}).One(&myCoinTT)
			if checkErr2(err) {
				myCoinTT.Tally = 0
			}
		}
		B := math.Abs(float64(myCoinTT.Tally))
		// log.Println("B:%d", B)

		//拒绝回收的次数
		rejectCount, err := db.C("coinRL").Find(bson.M{"toUser": user.Id, "accpet": false}).Count()
		// log.Println("rejectCount:%d", rejectCount)
		if checkErr2(err) {
			rejectCount = 0
		}
		credit := 0.0
		if rejectCount > 0 {
			//如果存在状态C: 鸟币信用 = (B*B个数＋C*C个数) / (B个数+C个数)
			//计算C个数
			m1 := bson.M{"$match": bson.M{"toUser": user.Id}}
			m2 := bson.M{"$match": bson.M{"accpet": false}}
			m3 := bson.M{"$group": bson.M{"_id": 0, "tally": bson.M{"$sum": "$tally"}}}
			operations := []bson.M{m1, m2, m3}
			coinRLT := freecoin.CoinRLReturn{}
			err = db.C("coinRL").Pipe(operations).One(&coinRLT)
			if checkErr2(err) {
				coinRLT.Tally = 0
			}
			C := float64(coinRLT.Tally)
			// log.Println("C:%d", C)
			//计算鸟币信用
			if B+C == 0 {
				credit = 0.0
			} else {
				credit = (B*0.618034 + C*0.05571294) / (B + C)
			}
		} else {
			//如果不存在状态C: 鸟币信用 = (A*A个数+B*B个数) / (A个数+B个数)
			m1 := bson.M{"$match": bson.M{"user": user.Id}}
			m2 := bson.M{"$match": bson.M{"count": bson.M{"$gt": 0}}}
			m3 := bson.M{"$match": bson.M{"coinT._id": coinType.Id}}
			m4 := bson.M{"$match": bson.M{"coinT.superCoin": false}}
			m5 := bson.M{"$group": bson.M{"_id": 0, "tally": bson.M{"$sum": "$count"}}}
			operations := []bson.M{m1, m2, m3, m4, m5}
			coinRLT := freecoin.CoinSTReturn{}
			err = db.C("coinS").Pipe(operations).One(&coinRLT)
			if checkErr2(err) {
				coinRLT.Tally = 0
			}
			A := float64(coinRLT.Tally)
			// log.Println("A:%d", A)

			//我赚到"过"鸟币或者发行"过"鸟币
			isNewUser := true
			coinSNum, err := db.C("coinS").Find(bson.M{"user": user.Id}).Count()
			if checkErr2(err) {
				isNewUser = true
			}
			if coinSNum > 0 {
				isNewUser = false
			}

			//计算鸟币信用
			if A+B == 0 {
				credit = 0.0
				if isNewUser == false {
					credit = 0.618034
				}
			} else {
				credit = float64(A*1.0+B*0.618034) / (A + B)
			}
		}
		user.Credit = credit
		// log.Println("credit:%.f", credit)

		//========================================

		//============刷新财富指数================
		// a:普通鸟币(非自己发行)收入=世界欠我的债务
		// b:普通鸟币(自己发行)收入=我偿还的欠世界的债务
		// c:普通鸟币(自己发行)支出=我欠世界的债务
		// d:普通鸟币(非自己发行)支出=世界偿还的欠我的债务
		// e:超级鸟币(非自己发行)收入=我给予世界的爱
		// f:超级鸟币(自己发行)收入=我对世界给予我的爱的回报
		// g:超级鸟币(自己发行)支出=世界给予我的爱
		// h:超级鸟币(非自己发行)支出＝世界对我给予世界的爱的回报
		// i:我欠世界的总债务=普通鸟币(自己发行)总支出=c-b >= 0
		// j:世界欠我的总债务=普通鸟币(非自己发行)总收入=a-d >= 0
		// k:世界给予我的不求回报的爱=超级鸟币(自己发行)总支出＝g-f >= 0
		// l:我给予世界的不求回报的爱＝超级鸟币(非自己发行)总收入=e-h >= 0
		// m:我对世界给予我的爱总共振量＝f*f
		// n:世界对我给世界的爱的总共振量＝h*h
		// o:债务总量=i+j
		// p:发光总量 m+n>0时,p=l*(m+n);m+n=0时,p=l
		// 财富指数＝p:o
		// 财富指数越大越好

		// //计算i：我发行的普通鸟币总数
		// coinType := freecoin.CoinT{}
		// err = db.C("coinT").Find(bson.M{"creator": user.Id, "superCoin": false}).One(&coinType)
		// checkErr(err)
		// myCoinTT := freecoin.CoinTTally{}
		// err = db.C("coinTT").Find(M{"owner": user.Id, "coinT._id": coinType.Id}).One(&myCoinTT)
		// if checkErr2(err) {
		// 	myCoinTT.Tally = 0
		// }
		// i := math.Abs(float64(myCoinTT.Tally))
		i := B
		// log.Println("i:%d", i)
		//计算j：我赚到的普通鸟币总数(不包括鸟币回流)
		myCoinTT2 := freecoin.CoinTTReturn{}
		m1 := bson.M{"$match": bson.M{"owner": user.Id}}
		m2 := bson.M{"$match": bson.M{"coinT._id": bson.M{"$ne": coinType.Id}}}
		m3 := bson.M{"$group": bson.M{"_id": 0, "tally": bson.M{"$sum": "$tally"}}}
		m32 := bson.M{"$match": bson.M{"coinT.superCoin": false}}
		operations := []bson.M{m1, m2, m32, m3}
		err = db.C("coinTT").Pipe(operations).One(&myCoinTT2)
		if checkErr2(err) {
			myCoinTT2.Tally = 0
		}
		j := float64(myCoinTT2.Tally)
		// log.Println("j:%d", j)
		o := float64(i + j)
		// log.Println("o:%f", o)
		//计算l：我赚到的超级鸟币(不包括鸟币回流)
		coinType2 := freecoin.CoinT{}
		err = db.C("coinT").Find(bson.M{"creator": user.Id, "superCoin": true}).One(&coinType2)
		myCoinTT3 := freecoin.CoinTTReturn{}
		if checkErr2(err) {
			myCoinTT3.Tally = 0
		} else {
			m4 := bson.M{"$match": bson.M{"coinT._id": bson.M{"$ne": coinType2.Id}}}
			m42 := bson.M{"$match": bson.M{"coinT.superCoin": true}}
			operations2 := []bson.M{m1, m4, m42, m3}
			err = db.C("coinTT").Pipe(operations2).One(&myCoinTT3)
			if checkErr2(err) {
				myCoinTT3.Tally = 0
			}
		}
		l := float64(myCoinTT3.Tally)
		// log.Println("l:%d", l)
		//计算f：我回收的超级鸟币
		m5 := bson.M{"$match": bson.M{"user": user.Id}}
		m6 := bson.M{"$match": bson.M{"count": bson.M{"$gt": 0}}}
		m7 := bson.M{"$match": bson.M{"coinT._id": coinType2.Id}}
		m8 := bson.M{"$match": bson.M{"coinT.superCoin": true}}
		m9 := bson.M{"$group": bson.M{"_id": 0, "tally": bson.M{"$sum": "$count"}}}
		operations3 := []bson.M{m5, m6, m7, m8, m9}
		myCoinST := freecoin.CoinSTReturn{}
		err = db.C("coinS").Pipe(operations3).One(&myCoinST)
		if checkErr2(err) {
			myCoinST.Tally = 0
		}
		f := float64(myCoinST.Tally)
		// log.Println("f:%d", f)
		//计算h：我支出的超级鸟币(不包括发行)
		m10 := bson.M{"$match": bson.M{"user": user.Id}}
		m11 := bson.M{"$match": bson.M{"count": bson.M{"$lt": 0}}}
		m12 := bson.M{"$match": bson.M{"coinT._id": bson.M{"$ne": coinType2.Id}}}
		m13 := bson.M{"$match": bson.M{"coinT.superCoin": true}}
		m14 := bson.M{"$group": bson.M{"_id": 0, "tally": bson.M{"$sum": "$count"}}}
		operations4 := []bson.M{m10, m11, m12, m13, m14}
		myCoinST2 := freecoin.CoinSTReturn{}
		err = db.C("coinS").Pipe(operations4).One(&myCoinST2)
		if checkErr2(err) {
			myCoinST2.Tally = 0
		}
		h := math.Abs(float64(myCoinST2.Tally))
		// log.Println("h:%d", h)
		//最后计算p/o
		m := f * f
		n := h * h
		p := float64(l*m + l*n)
		if l == 0 {
			p = float64(m + n)
		}
		if m+n == 0 {
			p = float64(l)
		}
		// log.Println("p:%f", p)
		if o == 0 {
			user.Wealth = p
			// log.Println("p:%f", p)
		} else {
			user.Wealth = p / o
			// log.Println("p/o:%f", p/o)
		}

		//更新数据
		db.C("user").UpdateId(user.Id, bson.M{"$set": bson.M{"wealth": user.Wealth, "credit": user.Credit}})
		//=======================================
	}(user)
}

//24超时未接受回流--->自动转为拒绝
func AutoRejectDealInBG(user *model.User, autoRecectLock *model.AutoRejectDealLocks) {
	//锁
	if autoRecectLock.Locks[user.Id.Hex()] == true {
		return
	}

	go func(user *model.User, autoRecectLock *model.AutoRejectDealLocks) {
		autoRecectLock.Locks[user.Id.Hex()] = true
		defer func() {
			delete(autoRecectLock.Locks, user.Id.Hex())
		}()

		session, err := mgo.Dial(config.MgoAddr)
		if err != nil {
			log.Println(err.Error())
			return
		}
		session.SetMode(mgo.Monotonic, true)
		db := session.DB(config.MgoDB)
		defer session.Close()

		coinGoBackNews := []model.News{}
		err = db.C("news").Find(bson.M{"toUser": user.Id, "newsType": 101, "needAutoReject": true}).All(&coinGoBackNews)
		if err == nil && len(coinGoBackNews) > 0 {
			for _, n := range coinGoBackNews {
				//判断是否超过24小时
				rejectDate := n.CreatedAt.AddDate(0, 0, 1)
				needAutoReject := time.Now().After(rejectDate)
				if needAutoReject {
					deal := freecoin.Deal{}
					err := db.C("deal").FindId(n.DId).One(&deal)
					if err != nil {
						continue
					}

					//买家消息需更新
					buyerNews := model.News{}
					err = db.C("news").Find(M{"did": deal.Id, "toUser": deal.Buyer}).One(&buyerNews)
					if err != nil {
						continue
					}
					//卖家消息需更新
					sellerNews := model.News{}
					err = db.C("news").Find(M{"did": deal.Id, "toUser": deal.Seller}).One(&sellerNews)
					if err != nil {
						continue
					}
					coinType := new(freecoin.CoinT)
					err = db.C("coinT").Find(bson.M{"alias": deal.CoinName, "superCoin": false}).One(&coinType)
					if err != nil {
						continue
					}
					//普通鸟币回流
					coinRejectLog := freecoin.CoinGoBackRejectLog{}
					coinRejectLog.Id = bson.NewObjectId()
					coinRejectLog.DealId = deal.Id
					coinRejectLog.FromUser = deal.Buyer
					coinRejectLog.ToUser = deal.Seller
					coinRejectLog.Tally = deal.CounterBid
					coinRejectLog.Accpet = false
					coinRejectLog.CreatedAt = time.Now()
					coinRejectLog.CoinT = coinType

					ops := []txn.Op{}
					ops = append(ops,
						txn.Op{C: "deal", Id: deal.Id, Update: M{"$set": M{"state": 2, "updateAt": time.Now().Unix()}}},
						txn.Op{C: "news", Id: buyerNews.Id, Update: M{"$set": M{"newsType": 104, "updateAt": time.Now().Unix()}}},
						txn.Op{C: "news", Id: sellerNews.Id, Update: M{"$set": M{"newsType": 105, "updateAt": time.Now().Unix()}}},
						txn.Op{C: "user", Id: deal.Buyer, Update: M{"$set": M{"hasNews": true}}},
						txn.Op{C: "coinRL", Id: coinRejectLog.Id, Insert: coinRejectLog},
					)

					runner := txn.NewRunner(db.C("txns"))
					id := bson.NewObjectId()
					err = runner.Run(ops, id, nil)
					if err != nil {
						continue
					}
				}
			}
		}
	}(user, autoRecectLock)
}
