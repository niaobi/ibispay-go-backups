package errs

import (
	valid "github.com/asaskevich/govalidator"
	"github.com/gin-gonic/gin"
	"log"
	"net/http"
)

func Check400(c *gin.Context, err error, msg string) {
	if err != nil {
		if valid.IsNull(msg) == false {
			c.JSON(http.StatusBadRequest, gin.H{"status": msg})
		} else {
			c.JSON(http.StatusBadRequest, gin.H{"status": err.Error()})
		}
		panic(err.Error())
	}
}

func CatchPanic() {
	if err := recover(); err != nil {
		log.Println("[action]->err:", err)
	}
}
