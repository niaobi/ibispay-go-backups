package config

const (
	PwdSalt     = "在梦里醒过来发现现实确实是场梦，鸟神号海盗船和你的火车擦肩而过"
	MgoAddr     = "mongodb://127.0.0.1"
	MgoDB       = "xingdongpai"
	RootDir     = "/xingdongpai.com"
	PublicDir   = RootDir + "/public"   //存放hugo生成的静态网站
	HtmlDir     = RootDir + "/html"     //存放隐私协议等单网页
	UserFileDir = RootDir + "/files"    //存放用户文件根目录
	PicDir      = UserFileDir + "/pic"  //图片
	FontDir     = UserFileDir + "/font" //字体
)
