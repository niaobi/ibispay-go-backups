package controller

import (
	"fmt"
	"github.com/asaskevich/govalidator"
	"github.com/gin-gonic/gin"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"log"
	"net/http"
	"os"
	"time"
	"xingdongpai.com/config"
	"xingdongpai.com/errs"
	"xingdongpai.com/freecoin"
	"xingdongpai.com/model"
	"xingdongpai.com/utils"
)

const (
	ScriptPerPage = 15
	ScriptMaxPic  = 3 * 1024 * 1024 //3MB
)

func UpdateScript(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	sid := bson.ObjectIdHex(c.Param("sid"))

	sf := model.ScriptForm{}
	err := c.Bind(&sf)
	errs.Check400(c, err, errs.E1010)

	err = db.C("script").UpdateId(sid, M{"$set": M{"passion": bson.ObjectIdHex(sf.Passion), "script": sf.Script, "type": sf.Type, "partner": sf.Partner, "pay": sf.Pay, "superCoin": sf.SuperCoin, "price": sf.Price, "updateAt": time.Now().Unix()}})
	errs.Check400(c, err, errs.E1000)

	c.JSON(http.StatusOK, sf)
}

func UpdateScriptPic(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	sid := bson.ObjectIdHex(c.Param("sid"))

	script := model.Script{}
	err := db.C("script").FindId(sid).One(&script)
	errs.Check400(c, err, errs.E1000)
	oldPicId := script.Photo.Largest.PId

	err = c.Request.ParseMultipartForm(ScriptMaxPic)
	errs.Check400(c, err, errs.E1004)
	//接收原图
	pics, err := utils.ReceivePics(c, config.PicDir)
	errs.Check400(c, err, errs.E1007)

	err = db.C("script").Update(bson.M{"_id": script.Id}, bson.M{"$set": bson.M{"photo": pics[0]}})
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"status": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"status": "ok"})

	//生成缩略图、更新数据库、删除老的图片
	go func(pics []utils.Pic, script model.Script, oldPicId string) {
		session, err := mgo.Dial(config.MgoAddr)
		if err != nil {
			log.Println(err.Error())
			return
		}
		session.SetMode(mgo.Monotonic, true)
		db := session.DB(config.MgoDB)
		defer session.Close()

		newPics, err := utils.ResizePics(pics, config.PicDir, 1334, 1136, 320)
		if err != nil {
			return
		}

		//更新缩略后的图片
		err = db.C("script").Update(bson.M{"_id": script.Id}, bson.M{"$set": bson.M{"photo": newPics[0]}})

		if err == nil && govalidator.IsNull(oldPicId) == false {
			//删除老的图片
			largestPicDir := fmt.Sprintf("%s/%s.jpg", config.PicDir, oldPicId)
			largePicDir := fmt.Sprintf("%s/%s_%s.jpg", config.PicDir, oldPicId, "large")
			middlePicDir := fmt.Sprintf("%s/%s_%s.jpg", config.PicDir, oldPicId, "middle")
			thumbnailPicDir := fmt.Sprintf("%s/%s_%s.jpg", config.PicDir, oldPicId, "thumbnail")

			os.Remove(largestPicDir)
			os.Remove(largePicDir)
			os.Remove(middlePicDir)
			os.Remove(thumbnailPicDir)
		}
	}(pics, script, oldPicId)
}

func NewScript(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)

	sf := model.ScriptForm{}
	err := c.Bind(&sf)
	errs.Check400(c, err, errs.E1010)

	script := model.Script{}
	script.Id = bson.NewObjectId()
	script.Owner = user.Id
	script.Passion = bson.ObjectIdHex(sf.Passion)
	script.UpdateAt = time.Now().Unix()
	script.CreatedAt = time.Now()

	script.Script = sf.Script
	script.Type = sf.Type
	script.Partner = sf.Partner
	script.Pay = sf.Pay
	script.SuperCoin = sf.SuperCoin
	script.Price = sf.Price
	script.CoinName = user.CoinAlias

	//新建post，插入数据库
	err = db.C("script").Insert(script)
	errs.Check400(c, err, errs.E1000)

	c.JSON(http.StatusCreated, script)

	//后台继续执行
	go func(script model.Script, user model.User) {
		session, err := mgo.Dial(config.MgoAddr)
		if err != nil {
			log.Println(err.Error())
			return
		}
		session.SetMode(mgo.Monotonic, true)
		db := session.DB(config.MgoDB)
		defer session.Close()

		//插入feed
		feed := model.Feed{}
		feed.Id = bson.NewObjectId()
		feed.Uid = user.Id
		feed.SId = script.Id
		feed.FeedType = 1
		feed.CreatedAt = script.CreatedAt
		err = db.C("feed").Insert(feed)
		if err != nil {
			log.Println(errs.E1012)
		}
	}(script, user)
}

func NewScriptPic(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)

	err := c.Request.ParseMultipartForm(ScriptMaxPic)
	errs.Check400(c, err, errs.E1004)

	//接收参数
	sf := model.ScriptForm{}
	err = c.Bind(&sf)
	errs.Check400(c, err, errs.E1010)
	//接收图片
	pics, err := utils.ReceivePics(c, config.PicDir)
	errs.Check400(c, err, errs.E1007)

	script := model.Script{}
	script.Id = bson.NewObjectId()
	script.Owner = user.Id
	script.Passion = bson.ObjectIdHex(sf.Passion)
	script.UpdateAt = time.Now().Unix()
	script.CreatedAt = time.Now()

	script.Script = sf.Script
	script.Type = sf.Type
	script.Partner = sf.Partner
	script.Photo = pics[0]
	script.Pay = sf.Pay
	script.SuperCoin = sf.SuperCoin
	script.Price = sf.Price
	script.CoinName = user.CoinAlias

	//新建post，插入数据库
	err = db.C("script").Insert(script)
	errs.Check400(c, err, errs.E1000)

	c.JSON(http.StatusCreated, script)

	//后台继续执行
	go func(pics []utils.Pic, script model.Script, user model.User) {
		session, err := mgo.Dial(config.MgoAddr)
		if err != nil {
			log.Println(err.Error())
			return
		}
		session.SetMode(mgo.Monotonic, true)
		db = session.DB(config.MgoDB)
		defer session.Close()

		//生成缩略图
		newPics, err := utils.ResizePics(pics, config.PicDir, 1334, 1136, 320)
		if err == nil {
			//更新图片对象
			db.C("script").Update(bson.M{"_id": script.Id}, bson.M{"$set": bson.M{"photo": newPics[0]}})
		}

		//插入feed
		feed := model.Feed{}
		feed.Id = bson.NewObjectId()
		feed.Uid = user.Id
		feed.SId = script.Id
		feed.FeedType = 1
		feed.CreatedAt = script.CreatedAt
		err = db.C("feed").Insert(feed)
		if err != nil {
			log.Println(errs.E1012)
		}
	}(pics, script, user)
}

type scriptReturn struct {
	Id bson.ObjectId `json:"id" bson:"_id"`

	Owner   bson.ObjectId `json:"owner"`   //作者
	Passion bson.ObjectId `json:"passion"` //剧本原型

	Script  string    `json:"script"`  //剧本内容 不超过300字
	Type    string    `json:"type"`    //剧情类型 喜剧/爱情/动作等
	Partner string    `json:"partner"` //搭档招募要求
	Photo   utils.Pic `json:"photo"`   //图片

	Pay       bool   `json:"pay"`       //是否有片酬
	SuperCoin bool   `json:"superCoin"` //是否是超级鸟币
	Price     int64  `json:"price"`     //价格
	CoinName  string `json:"coinName" ` //鸟币类型

	Likes     uint64    `json:"likes" `    //喜欢数
	UpdateAt  int64     `json:"updateAt" ` //更新时间
	CreatedAt time.Time `json:"createdAt"`

	PassionDetail freecoin.Passion `json:"passionDetail"`
}

func ScriptById(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	sid := bson.ObjectIdHex(c.Param("sid"))

	script := scriptReturn{}
	err := db.C("script").FindId(sid).One(&script)
	errs.Check400(c, err, errs.E1000)

	passion := freecoin.Passion{}
	err = db.C("passion").FindId(script.Passion).Select(M{"owner": 1, "md": 1, "title": 1, "desc": 1, "views": 1, "updateAt": 1, "createdAt": 1}).One(&passion)
	errs.Check400(c, err, errs.E1000)
	script.PassionDetail = passion

	c.JSON(http.StatusOK, script)
}
