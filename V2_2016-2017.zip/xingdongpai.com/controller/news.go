package controller

import (
	"github.com/gin-gonic/gin"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"net/http"
	"strconv"
	"xingdongpai.com/errs"
	"xingdongpai.com/freecoin"
	"xingdongpai.com/model"
)

const (
	NewsListPage = 10
)

func NewsList(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)
	skip, _ := strconv.Atoi(c.Param("skip"))

	newsList := []model.News{}
	err := db.C("news").Find(bson.M{"toUser": user.Id}).Skip(skip).Limit(NewsListPage).Sort("-createdAt").All(&newsList)
	errs.Check400(c, err, errs.E1000)

	newNewsList := []gin.H{}
	for _, n := range newsList {
		if n.NewsType == 0 {
			newNewsList = append(newNewsList, gin.H{"news": n})
		} else if n.NewsType >= 100 && n.NewsType < 200 {
			deal := freecoin.Deal{}
			if db.C("deal").FindId(n.DId).One(&deal) != nil {
				continue
			}

			skill := freecoin.Skill{}
			if db.C("skill").FindId(deal.SkillId).One(&skill) != nil {
				continue
			}

			buyer := model.User{}
			if db.C("user").FindId(deal.Buyer).Select(bson.M{"avatar": 1, "name": 1, "wealth": 1, "credit": 1, "coinAlias": 1, "hasPhoto": 1, "city": 1, "lat": 1, "lng": 1, "openType": 1, "bio": 1, "phone": 1, "phoneCC": 1, "founder": 1, "createdAt": 1}).One(&buyer) != nil {
				continue
			}

			seller := model.User{}
			if db.C("user").FindId(deal.Seller).Select(bson.M{"avatar": 1, "name": 1, "wealth": 1, "credit": 1, "coinAlias": 1, "hasPhoto": 1, "city": 1, "lat": 1, "lng": 1, "openType": 1, "bio": 1, "phone": 1, "phoneCC": 1, "founder": 1, "createdAt": 1}).One(&seller) != nil {
				continue
			}

			newNewsList = append(newNewsList, gin.H{"news": n, "deal": deal, "skill": skill, "buyer": buyer, "seller": seller})
		} else if n.NewsType >= 200 && n.NewsType < 300 {
			date := model.Date{}
			if db.C("date").FindId(n.DId).One(&date) != nil {
				continue
			}

			script := model.Script{}
			if db.C("script").FindId(date.ScriptId).One(&script) != nil {
				continue
			}

			sender := model.User{}
			if db.C("user").FindId(date.Sender).Select(bson.M{"avatar": 1, "name": 1, "wealth": 1, "credit": 1, "coinAlias": 1, "hasPhoto": 1, "city": 1, "lat": 1, "lng": 1, "openType": 1, "bio": 1, "phone": 1, "phoneCC": 1, "founder": 1, "createdAt": 1}).One(&sender) != nil {
				continue
			}

			owner := model.User{}
			if db.C("user").FindId(date.Owner).Select(bson.M{"avatar": 1, "name": 1, "wealth": 1, "credit": 1, "coinAlias": 1, "hasPhoto": 1, "city": 1, "lat": 1, "lng": 1, "openType": 1, "bio": 1, "phone": 1, "phoneCC": 1, "founder": 1, "createdAt": 1}).One(&owner) != nil {
				continue
			}

			newNewsList = append(newNewsList, gin.H{"news": n, "date": date, "script": script, "sender": sender, "owner": owner})
		}
	}

	returnSkip := skip + NewsListPage
	if len(newNewsList) < NewsListPage {
		returnSkip = -1
	}

	if skip == 0 {
		//已读标记
		if user.HasNews == true {
			readCount, _ := db.C("news").Find(bson.M{"toUser": user.Id}).Count()
			db.C("user").UpdateId(user.Id, M{"$set": M{"hasNews": false, "readNews": readCount}})
		}
	}
	c.JSON(http.StatusOK, gin.H{"list": newNewsList, "skip": returnSkip})
}

func TaskList(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)
	skip, _ := strconv.Atoi(c.Param("skip"))

	newsList := []model.News{}
	m1 := M{"$in": []int{102, 103, 202, 203, 208, 209}}
	err := db.C("news").Find(M{"toUser": user.Id, "newsType": m1}).Skip(skip).Limit(50).Sort("-createdAt").All(&newsList)
	errs.Check400(c, err, errs.E1000)

	newNewsList := []gin.H{}
	for _, n := range newsList {
		if n.NewsType > 100 && n.NewsType < 200 {
			deal := freecoin.Deal{}
			if db.C("deal").FindId(n.DId).One(&deal) != nil {
				continue
			}

			skill := freecoin.Skill{}
			if db.C("skill").FindId(deal.SkillId).One(&skill) != nil {
				continue
			}

			buyer := model.User{}
			if db.C("user").FindId(deal.Buyer).Select(bson.M{"avatar": 1, "name": 1, "wealth": 1, "credit": 1, "coinAlias": 1, "hasPhoto": 1, "city": 1, "lat": 1, "lng": 1, "openType": 1, "bio": 1, "phone": 1, "phoneCC": 1}).One(&buyer) != nil {
				continue
			}

			seller := model.User{}
			if db.C("user").FindId(deal.Seller).Select(bson.M{"avatar": 1, "name": 1, "wealth": 1, "credit": 1, "coinAlias": 1, "hasPhoto": 1, "city": 1, "lat": 1, "lng": 1, "openType": 1, "bio": 1, "phone": 1, "phoneCC": 1}).One(&seller) != nil {
				continue
			}

			newNewsList = append(newNewsList, gin.H{"news": n, "deal": deal, "skill": skill, "buyer": buyer, "seller": seller})
		} else if n.NewsType > 200 && n.NewsType < 300 {
			date := model.Date{}
			if db.C("date").FindId(n.DId).One(&date) != nil {
				continue
			}

			script := model.Script{}
			if db.C("script").FindId(date.ScriptId).One(&script) != nil {
				continue
			}

			sender := model.User{}
			if db.C("user").FindId(date.Sender).Select(bson.M{"avatar": 1, "name": 1, "wealth": 1, "credit": 1, "coinAlias": 1, "hasPhoto": 1, "city": 1, "lat": 1, "lng": 1, "openType": 1, "bio": 1, "phone": 1, "phoneCC": 1}).One(&sender) != nil {
				continue
			}

			owner := model.User{}
			if db.C("user").FindId(date.Owner).Select(bson.M{"avatar": 1, "name": 1, "wealth": 1, "credit": 1, "coinAlias": 1, "hasPhoto": 1, "city": 1, "lat": 1, "lng": 1, "openType": 1, "bio": 1, "phone": 1, "phoneCC": 1}).One(&owner) != nil {
				continue
			}

			newNewsList = append(newNewsList, gin.H{"news": n, "date": date, "script": script, "sender": sender, "owner": owner})
		}
	}
	returnSkip := skip + NewsListPage
	if len(newNewsList) < NewsListPage {
		returnSkip = -1
	}

	c.JSON(http.StatusOK, gin.H{"list": newNewsList, "skip": returnSkip})
}
