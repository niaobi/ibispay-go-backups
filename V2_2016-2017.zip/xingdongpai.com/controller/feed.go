package controller

import (
	"github.com/asaskevich/govalidator"
	"github.com/gin-gonic/gin"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"net/http"
	"strconv"
	"xingdongpai.com/errs"
	"xingdongpai.com/freecoin"
	"xingdongpai.com/model"
)

const (
	FeedListPage = 20
)

func FeedList(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	skip, _ := strconv.Atoi(c.Param("skip"))

	feedList := []model.Feed{}
	err := db.C("feed").Find(nil).Skip(skip).Limit(FeedListPage).Sort("-createdAt").All(&feedList)
	errs.Check400(c, err, errs.E1000)

	newFeedList := []gin.H{}
	for _, f := range feedList {
		if f.FeedType == 0 {
			user := model.User{}
			skill := freecoin.Skill{}
			passion := freecoin.Passion{}
			if db.C("skill").FindId(f.SId).One(&skill) != nil {
				continue
			}
			if db.C("user").FindId(skill.Owner).Select(bson.M{"avatar": 1, "name": 1, "wealth": 1, "credit": 1, "coinAlias": 1, "hasPhoto": 1, "city": 1, "lat": 1, "lng": 1, "openType": 1, "bio": 1, "founder": 1, "createdAt": 1}).One(&user) != nil {
				continue
			}
			if db.C("passion").FindId(skill.Passion).Select(bson.M{"owner": 1, "md": 1, "title": 1, "desc": 1, "createdAt": 1}).One(&passion) != nil {
				continue
			}
			newFeedList = append(newFeedList, gin.H{"owner": user, "passion": passion, "skill": skill, "feedType": 0})
		} else if f.FeedType == 1 {
			user := model.User{}
			script := model.Script{}
			passion := freecoin.Passion{}
			if db.C("script").FindId(f.SId).One(&script) != nil {
				continue
			}
			if db.C("user").FindId(script.Owner).Select(bson.M{"avatar": 1, "name": 1, "wealth": 1, "credit": 1, "coinAlias": 1, "hasPhoto": 1, "city": 1, "lat": 1, "lng": 1, "openType": 1, "bio": 1, "founder": 1, "createdAt": 1}).One(&user) != nil {
				continue
			}
			if db.C("passion").FindId(script.Passion).Select(bson.M{"owner": 1, "md": 1, "title": 1, "desc": 1, "createdAt": 1}).One(&passion) != nil {
				continue
			}
			newFeedList = append(newFeedList, gin.H{"owner": user, "passion": passion, "script": script, "feedType": 1})
		}
	}

	returnSkip := skip + FeedListPage
	if len(newFeedList) < FeedListPage {
		returnSkip = -1
	}

	c.JSON(http.StatusOK, gin.H{"list": newFeedList, "skip": returnSkip})
}

//我的所有行动
func MyFeedList(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)
	skip, _ := strconv.Atoi(c.Param("skip"))

	uid := bson.ObjectIdHex(c.Param("uid"))
	if govalidator.IsNull(c.Param("uid")) {
		uid = user.Id
	}

	feedList := []model.Feed{}
	err := db.C("feed").Find(bson.M{"uid": uid}).Skip(skip).Limit(FeedListPage).Sort("-createdAt").All(&feedList)
	errs.Check400(c, err, errs.E1000)

	newFeedList := []gin.H{}
	for _, f := range feedList {
		if f.FeedType == 0 {
			skill := freecoin.Skill{}
			passion := freecoin.Passion{}
			if db.C("skill").FindId(f.SId).One(&skill) != nil {
				continue
			}
			if db.C("passion").FindId(skill.Passion).Select(bson.M{"owner": 1, "md": 1, "title": 1, "desc": 1, "createdAt": 1}).One(&passion) != nil {
				continue
			}
			newFeedList = append(newFeedList, gin.H{"passion": passion, "skill": skill, "feedType": 0})
		} else if f.FeedType == 1 {
			script := model.Script{}
			passion := freecoin.Passion{}
			if db.C("script").FindId(f.SId).One(&script) != nil {
				continue
			}
			if db.C("passion").FindId(script.Passion).Select(bson.M{"owner": 1, "md": 1, "title": 1, "desc": 1, "createdAt": 1}).One(&passion) != nil {
				continue
			}
			newFeedList = append(newFeedList, gin.H{"passion": passion, "script": script, "feedType": 1})
		}
	}

	returnSkip := skip + FeedListPage
	if len(newFeedList) < FeedListPage {
		returnSkip = -1
	}

	c.JSON(http.StatusOK, gin.H{"list": newFeedList, "skip": returnSkip})
}
