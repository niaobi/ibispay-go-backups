package controller

import (
	"net/http"
	"unicode/utf8"

	"github.com/asaskevich/govalidator"
	"github.com/gin-gonic/gin"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"gopkg.in/mgo.v2/txn"
	"xingdongpai.com/errs"
	"xingdongpai.com/freecoin"
	"xingdongpai.com/model"
)

//新建鸟币类型
func NewCoinType(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)
	alias := c.Param("alias")

	if user.CoinEnabled == false || user.SuperCoinEnabled == false {
		c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1021})
		return
	}

	if govalidator.IsNull(alias) == true || utf8.RuneCountInString(alias) > 4 {
		c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1014})
		return
	}

	num, err := db.C("coinT").Find(bson.M{"coinAlias": alias}).Count()
	errs.Check400(c, err, errs.E1000)
	if num > 0 {
		c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1013})
		return
	}

	//普通鸟币
	ct := freecoin.CoinT{}
	ct.Id = bson.NewObjectId()
	ct.Creator = user.Id
	ct.SuperCoin = false
	ct.Alias = alias
	//超级鸟币
	superCT := new(freecoin.CoinT)
	superCT.Id = bson.NewObjectId()
	superCT.Creator = user.Id
	superCT.SuperCoin = true
	superCT.Alias = alias

	runner := txn.NewRunner(db.C("txns"))
	ops := []txn.Op{{C: "coinT", Id: ct.Id, Insert: ct},
		{C: "coinT", Id: superCT.Id, Insert: superCT},
		{C: "user", Id: user.Id, Update: M{"$set": M{"coinAlias": alias}}}}

	id := bson.NewObjectId()
	err = runner.Run(ops, id, nil)
	errs.Check400(c, err, errs.E1000)

	user.CoinAlias = alias

	c.JSON(http.StatusCreated, user)
}
