package controller

import (
	"github.com/asaskevich/govalidator"
	"github.com/gin-gonic/gin"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"gopkg.in/mgo.v2/txn"
	"net/http"
	"strconv"
	"time"
	"xingdongpai.com/errs"
	"xingdongpai.com/freecoin"
	"xingdongpai.com/model"
)

func NewDeal(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)

	dealForm := new(freecoin.DealForm)
	seller := model.User{}
	if c.BindJSON(&dealForm) == nil {
		if user.Id.Hex() == dealForm.Seller {
			c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1017})
			return
		}

		err := db.C("user").FindId(bson.ObjectIdHex(dealForm.Seller)).Select(bson.M{"_id": 1, "coinAlias": 1}).One(&seller)
		errs.Check400(c, err, errs.E1000)

		//检查是否是有被拒绝的鸟币回流，有则不能使用鸟币回流进行交易（因为鸟币信用不能在因为同一个卖家重复降低）
		coinRLNum, err := db.C("coinRL").Find(bson.M{"fromUser": user.Id, "toUser": bson.ObjectIdHex(dealForm.Seller), "accpet": false}).Count()
		if err != nil && err != mgo.ErrNotFound {
			errs.Check400(c, err, errs.E1000)
		} else {
			if coinRLNum > 0 && dealForm.CoinName == seller.CoinAlias {
				c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1023})
				return
			}
		}

		buyerCoinTTally := freecoin.CoinTTally{}
		if dealForm.CoinName != user.CoinAlias {
			//鸟币类型
			coinType := new(freecoin.CoinT)
			if dealForm.SuperCoin {
				err := db.C("coinT").Find(bson.M{"alias": dealForm.CoinName, "superCoin": true}).One(&coinType)
				errs.Check400(c, err, errs.E1000)
			} else {
				err := db.C("coinT").Find(bson.M{"alias": dealForm.CoinName, "superCoin": false}).One(&coinType)
				errs.Check400(c, err, errs.E1000)
			}

			//检查鸟币和自己的出价相比是否足够
			err := db.C("coinTT").Find(M{"owner": user.Id, "coinT._id": coinType.Id}).One(&buyerCoinTTally)
			errs.Check400(c, err, errs.E1000)
			if buyerCoinTTally.Tally < dealForm.CounterBid {
				//鸟币数量不够
				c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1018})
				return
			}
		}

		//"普通鸟币回流"需要标记24小时自动拒绝回流
		needAutoReject := false
		if dealForm.CoinName == seller.CoinAlias && dealForm.CounterBid >= dealForm.Price && dealForm.SuperCoin == false {
			needAutoReject = true
		}

		deal := new(freecoin.Deal)
		deal.Id = bson.NewObjectId()
		deal.Buyer = user.Id
		deal.Seller = bson.ObjectIdHex(dealForm.Seller)
		deal.CoinTLId = bson.NewObjectId() //假id占位置
		deal.SkillId = bson.ObjectIdHex(dealForm.SkillId)
		deal.Price = dealForm.Price
		deal.CounterBid = dealForm.CounterBid
		deal.CoinName = dealForm.CoinName
		deal.SuperCoin = dealForm.SuperCoin
		deal.Pact = dealForm.Pact
		deal.Note = dealForm.Note
		deal.State = 0
		deal.Rank = 0
		deal.UpdateAt = time.Now().Unix()
		deal.CreatedAt = time.Now()

		//买家消息
		news := new(model.News)
		news.Id = bson.NewObjectId()
		news.DId = deal.Id
		news.ToUser = user.Id
		news.NewsType = 100
		news.NeedAutoReject = needAutoReject
		news.UpdateAt = time.Now().Unix()
		news.CreatedAt = time.Now()
		//卖家消息
		news2 := new(model.News)
		news2.Id = bson.NewObjectId()
		news2.DId = deal.Id
		news2.ToUser = deal.Seller
		news2.NewsType = 101
		news2.NeedAutoReject = needAutoReject
		news2.UpdateAt = time.Now().Unix()
		news2.CreatedAt = time.Now()

		//新建交易，插入数据库
		runner := txn.NewRunner(db.C("txns"))
		ops := []txn.Op{
			{C: "news", Id: news.Id, Insert: news},
			{C: "news", Id: news2.Id, Insert: news2},
			{C: "deal", Id: deal.Id, Insert: deal},
			{C: "user", Id: deal.Buyer, Update: M{"$set": M{"hasNews": true}}},
			{C: "user", Id: deal.Seller, Update: M{"$set": M{"hasNews": true}}},
		}
		if dealForm.CoinName != user.CoinAlias {
			//检查鸟币和自己的出价相比是否足够
			ops = append(ops, txn.Op{C: "coinTT", Id: buyerCoinTTally.Id, Assert: bson.M{"tally": bson.M{"$gte": dealForm.CounterBid}}})
		}
		id := bson.NewObjectId()
		err = runner.Run(ops, id, nil)
		errs.Check400(c, err, errs.E1000)

		c.JSON(http.StatusCreated, deal)
	} else {
		c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1010})
	}
}

func DealById(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	did := bson.ObjectIdHex(c.Param("did"))

	deal := freecoin.Deal{}
	err := db.C("deal").FindId(did).One(&deal)
	errs.Check400(c, err, errs.E1000)

	c.JSON(http.StatusOK, deal)
}

func RejectDeal(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	seller := c.MustGet(gin.AuthUserKey).(model.User)
	did := bson.ObjectIdHex(c.Param("did"))

	deal := freecoin.Deal{}
	err := db.C("deal").FindId(did).One(&deal)
	errs.Check400(c, err, errs.E1000)

	//买家消息需更新
	buyerNews := model.News{}
	err = db.C("news").Find(M{"did": did, "toUser": deal.Buyer}).One(&buyerNews)
	errs.Check400(c, err, errs.E1000)
	//卖家消息需更新
	sellerNews := model.News{}
	err = db.C("news").Find(M{"did": did, "toUser": deal.Seller}).One(&sellerNews)
	errs.Check400(c, err, errs.E1000)
	//买家被拒绝消息提示
	news := model.News{}
	news.Id = bson.NewObjectId()
	news.DId = deal.Id
	news.ToUser = deal.Buyer
	news.Msg = "[" + seller.Name + "]婉拒了你的购买请求"
	news.NewsType = 0
	news.UpdateAt = time.Now().Unix()
	news.CreatedAt = time.Now()

	//买家
	buyer := model.User{}
	err = db.C("user").FindId(deal.Buyer).Select(bson.M{"_id": 1, "coinAlias": 1, "name": 1}).One(&buyer)
	errs.Check400(c, err, errs.E1000)
	//鸟币类型
	coinType := new(freecoin.CoinT)
	err = db.C("coinT").Find(bson.M{"alias": deal.CoinName, "superCoin": deal.SuperCoin}).One(&coinType)
	errs.Check400(c, err, errs.E1000)
	//判断是否是"普通鸟币回流"
	ops := []txn.Op{}
	if deal.SuperCoin == false && buyer.CoinAlias != deal.CoinName && coinType.Creator == seller.Id && deal.CounterBid >= deal.Price {
		//普通鸟币回流
		coinRejectLog := freecoin.CoinGoBackRejectLog{}
		coinRejectLog.Id = bson.NewObjectId()
		coinRejectLog.DealId = deal.Id
		coinRejectLog.FromUser = buyer.Id
		coinRejectLog.ToUser = seller.Id
		coinRejectLog.Tally = deal.CounterBid
		coinRejectLog.Accpet = false
		coinRejectLog.CreatedAt = time.Now()
		coinRejectLog.CoinT = coinType
		//买家消息
		news.Msg = "[" + seller.Name + "]婉拒了你的购买请求，其鸟币信用已被降低，在对方重新接单之前，你将无法使用鸟币回流的方式购买对方的任何服务(其他鸟币不受影响)。"
		ops = append(ops,
			txn.Op{C: "deal", Id: deal.Id, Update: M{"$set": M{"state": 2, "updateAt": time.Now().Unix()}}},
			txn.Op{C: "news", Id: buyerNews.Id, Update: M{"$set": M{"newsType": 104, "updateAt": time.Now().Unix()}}},
			txn.Op{C: "news", Id: sellerNews.Id, Update: M{"$set": M{"newsType": 105, "updateAt": time.Now().Unix()}}},
			txn.Op{C: "news", Id: news.Id, Insert: news},
			txn.Op{C: "user", Id: deal.Buyer, Update: M{"$set": M{"hasNews": true}}},
			txn.Op{C: "coinRL", Id: coinRejectLog.Id, Insert: coinRejectLog},
		)
	} else {
		ops = append(ops,
			txn.Op{C: "deal", Id: deal.Id, Update: M{"$set": M{"state": 2, "updateAt": time.Now().Unix()}}},
			txn.Op{C: "news", Id: buyerNews.Id, Update: M{"$set": M{"newsType": 104, "updateAt": time.Now().Unix()}}},
			txn.Op{C: "news", Id: sellerNews.Id, Update: M{"$set": M{"newsType": 105, "updateAt": time.Now().Unix()}}},
			txn.Op{C: "news", Id: news.Id, Insert: news},
			txn.Op{C: "user", Id: deal.Buyer, Update: M{"$set": M{"hasNews": true}}},
		)
	}

	runner := txn.NewRunner(db.C("txns"))
	id := bson.NewObjectId()
	err = runner.Run(ops, id, nil)
	errs.Check400(c, err, errs.E1000)

	c.JSON(http.StatusCreated, gin.H{"status": "ok"})
}

func AcceptDeal(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	seller := c.MustGet(gin.AuthUserKey).(model.User)
	lock := c.MustGet("lock").(*freecoin.TransferLocks)
	did := bson.ObjectIdHex(c.Param("did"))

	//订单
	deal := freecoin.Deal{}
	err := db.C("deal").FindId(did).One(&deal)
	errs.Check400(c, err, errs.E1000)

	//检查是否是被拒绝的普通鸟币回流 重新被卖家接受
	isAccpetTheRejected := false
	coinRejectLog := freecoin.CoinGoBackRejectLog{}
	err = db.C("coinRL").Find(bson.M{"dealId": deal.Id}).One(&coinRejectLog)
	if err != nil {
		if err == mgo.ErrNotFound {
			isAccpetTheRejected = false
		} else {
			errs.Check400(c, err, errs.E1000)
		}
	} else {
		if govalidator.IsNull(coinRejectLog.Id.Hex()) == false {
			isAccpetTheRejected = true
		}
	}

	//交易锁
	if lock.Locks[deal.Seller.Hex()] == true || lock.Locks[deal.Buyer.Hex()] == true {
		http.Error(c.Writer, errs.E1019, http.StatusBadRequest)
		return
	}
	lock.Locks[deal.Seller.Hex()] = true
	lock.Locks[deal.Buyer.Hex()] = true
	defer func() {
		delete(lock.Locks, deal.Seller.Hex())
		delete(lock.Locks, deal.Buyer.Hex())
	}()

	//买家
	buyer := model.User{}
	err = db.C("user").FindId(deal.Buyer).Select(bson.M{"_id": 1, "coinAlias": 1, "name": 1}).One(&buyer)
	errs.Check400(c, err, errs.E1000)
	//买家消息需更新
	buyerNews := model.News{}
	err = db.C("news").Find(M{"did": did, "toUser": deal.Buyer}).One(&buyerNews)
	errs.Check400(c, err, errs.E1000)
	//卖家消息需更新
	sellerNews := model.News{}
	err = db.C("news").Find(M{"did": did, "toUser": deal.Seller}).One(&sellerNews)
	errs.Check400(c, err, errs.E1000)
	//买家被接单消息提示
	news := model.News{}
	news.Id = bson.NewObjectId()
	news.DId = deal.Id
	news.ToUser = buyer.Id
	counterBid := strconv.FormatInt(deal.CounterBid, 10)
	if deal.SuperCoin {
		news.Msg = "[" + seller.Name + "]接受了你的订单,你支出了 " + counterBid + "个 超级" + deal.CoinName + "币"
	} else {
		if isAccpetTheRejected {
			news.Msg = "[" + seller.Name + "]重新接受了之前拒绝的你的订单,你支出了 " + counterBid + "个 " + deal.CoinName + "币"
		} else {
			news.Msg = "[" + seller.Name + "]接受了你的订单,你支出了 " + counterBid + "个 " + deal.CoinName + "币"
		}
	}
	news.NewsType = 0
	news.UpdateAt = time.Now().Unix()
	news.CreatedAt = time.Now()
	//卖家赚到了多少个xx币的消息提示/卖家回收了多少个鸟币
	news2 := model.News{}
	news2.Id = bson.NewObjectId()
	news2.DId = deal.Id
	news2.ToUser = seller.Id
	if deal.SuperCoin {
		news2.Msg = "你赚到了 " + counterBid + "个 超级" + deal.CoinName + "币,来自于[" + buyer.Name + "]的订单"
	} else {
		news2.Msg = "你赚到了 " + counterBid + "个 " + deal.CoinName + "币,来自于[" + buyer.Name + "]的订单"
	}
	news2.NewsType = 0
	news2.UpdateAt = time.Now().Unix()
	news2.CreatedAt = time.Now()

	//====================转账相关=======================
	//鸟币类型
	coinType := new(freecoin.CoinT)
	err = db.C("coinT").Find(bson.M{"alias": deal.CoinName, "superCoin": deal.SuperCoin}).One(&coinType)
	errs.Check400(c, err, errs.E1000)
	//鸟币发行者
	coinCreator := new(model.User)
	err = db.C("user").FindId(coinType.Creator).Select(bson.M{"_id": 1, "skillUpdated": 1}).One(&coinCreator)
	errs.Check400(c, err, errs.E1000)
	//转账流水transferLog
	ctLog := new(freecoin.CoinTransferLog)
	ctLog.Id = bson.NewObjectId()
	ctLog.FromUser = buyer.Id
	ctLog.ToUser = seller.Id
	ctLog.Tally = deal.CounterBid
	ctLog.CoinT = coinType
	ctLog.CoinGoBack = false
	ctLog.Note = deal.Note
	ctLog.CreatedAt = time.Now()

	//============coinTT=============
	//卖家赚到的此类型鸟币总数
	coinTTNum, err := db.C("coinTT").Find(bson.M{"coinT._id": coinType.Id, "owner": seller.Id}).Count()
	errs.Check400(c, err, errs.E1000)
	coinTT := new(freecoin.CoinTTally)
	if coinTTNum == 0 {
		coinTT.Id = bson.NewObjectId()
		coinTT.Owner = seller.Id
		coinTT.CoinType = coinType
		coinTT.Tally = deal.CounterBid
	} else {
		err := db.C("coinTT").Find(bson.M{"coinT._id": coinType.Id, "owner": seller.Id}).One(&coinTT)
		errs.Check400(c, err, errs.E1000)
	}
	//买家支出的此类型鸟币总数
	coinTTNum2, err := db.C("coinTT").Find(bson.M{"coinT._id": coinType.Id, "owner": buyer.Id}).Count()
	errs.Check400(c, err, errs.E1000)
	coinTT2 := new(freecoin.CoinTTally)
	if coinTTNum2 == 0 {
		coinTT2.Id = bson.NewObjectId()
		coinTT2.Owner = buyer.Id
		coinTT2.CoinType = coinType
		coinTT2.Tally = -deal.CounterBid
	} else {
		err := db.C("coinTT").Find(bson.M{"coinT._id": coinType.Id, "owner": buyer.Id}).One(&coinTT2)
		errs.Check400(c, err, errs.E1000)
	}
	ops := []txn.Op{}
	//卖家
	if coinTTNum == 0 {
		ops = append(ops, txn.Op{C: "coinTT", Id: coinTT.Id, Insert: coinTT})
	} else {
		ops = append(ops, txn.Op{C: "coinTT", Id: coinTT.Id, Update: M{"$inc": M{"tally": deal.CounterBid}}})
	}
	//买家
	if coinTTNum2 == 0 {
		ops = append(ops, txn.Op{C: "coinTT", Id: coinTT2.Id, Insert: coinTT2})
	} else {
		ops = append(ops, txn.Op{C: "coinTT", Id: coinTT2.Id, Update: M{"$inc": M{"tally": -deal.CounterBid}}})
	}
	//============coinTT=============

	//============coinRL=============
	if isAccpetTheRejected {
		//重新接受鸟币回流，更新coinRL表
		ops = append(ops, txn.Op{C: "coinRL", Id: coinRejectLog.Id, Update: M{"$set": M{"accpet": true}}})
	}
	//============coinRL=============

	//情况1.买家或转账方使用自己发行的鸟币
	//情况2.买家或转账方使用收款人方发行的鸟币(即鸟币回流)
	//情况3.买家或转账方使用第三方发行的鸟币
	buyerIsCreator := false
	coinGoBack := false
	otherCreator := false
	if buyer.CoinAlias == deal.CoinName {
		//判断是否买家自己发行
		buyerIsCreator = true //情况1
	} else {
		//判断是否是鸟币回流
		if coinType.Creator == seller.Id {
			coinGoBack = true //情况2
		} else {
			otherCreator = true //情况3
		}
	}
	//-------------不同情况不同的转账过程-------------
	if buyerIsCreator == true {
		//技能id列表
		skillList := []freecoin.Skill{}
		if deal.SuperCoin {
			err = db.C("skill").Find(bson.M{"owner": coinType.Creator, "inStock": true, "price": 0}).Select(bson.M{"_id": 1}).Sort("-createdAt").All(&skillList)
			errs.Check400(c, err, errs.E1000)
		} else {
			err = db.C("skill").Find(bson.M{"owner": coinType.Creator, "inStock": true, "price": M{"$gt": 0}}).Select(bson.M{"_id": 1}).Sort("-createdAt").All(&skillList)
			errs.Check400(c, err, errs.E1000)
		}
		skillIdList := []bson.ObjectId{}
		for _, s := range skillList {
			skillIdList = append(skillIdList, s.Id)
		}
		//发行次数
		coinVNum, err := db.C("coinV").Find(bson.M{"ctid": coinType.Id}).Count()
		errs.Check400(c, err, errs.E1000)
		//获取最后一个发行版本
		coinVisionArray := []freecoin.CoinV{}
		if coinVNum > 0 {
			err = db.C("coinV").Find(bson.M{"ctid": coinType.Id}).Limit(1).Sort("-createdAt").All(&coinVisionArray)
			errs.Check400(c, err, errs.E1000)
		}
		//发行(转账或交易)鸟币时，若技能有改动，则版本号+1
		if coinCreator.SkillUpdated == true || coinVNum == 0 {
			//版本＋1
			sids := new(freecoin.SkillIds)
			sids.Id = bson.NewObjectId()
			sids.List = skillIdList
			sids.CreatedAt = time.Now()

			coinVision := freecoin.CoinV{}
			coinVision.Id = bson.NewObjectId()
			coinVision.CoinTId = coinType.Id
			coinVision.CreatedAt = time.Now()
			coinVision.SkillIdList = sids.Id
			if coinVNum == 0 {
				coinVision.Vision = 1
			} else {
				coinVision.Vision = coinVisionArray[0].Vision + 1
			}

			//卖家收入明细
			coinState := new(freecoin.CoinS)
			coinState.Id = bson.NewObjectId()
			coinState.User = seller.Id
			coinState.CoinTLId = ctLog.Id
			coinState.CoinVId = coinVision.Id
			coinState.CoinT = coinType
			coinState.Count = deal.CounterBid
			coinState.CreatedAt = time.Now()
			//买家支出明细
			coinState2 := new(freecoin.CoinS)
			coinState2.Id = bson.NewObjectId()
			coinState2.User = buyer.Id
			coinState2.CoinTLId = ctLog.Id
			coinState2.CoinVId = coinVision.Id
			coinState2.CoinT = coinType
			coinState2.Count = -deal.CounterBid
			coinState2.CreatedAt = time.Now()

			//卖家赚到的同一个版本的鸟币总数
			coinVT := new(freecoin.CoinVTally)
			coinVT.Id = bson.NewObjectId()
			coinVT.Owner = seller.Id
			coinVT.CoinV = coinVision
			coinVT.Tally = deal.CounterBid
			//买家支出的同一个版本的鸟币总数
			coinVT2 := new(freecoin.CoinVTally)
			coinVT2.Id = bson.NewObjectId()
			coinVT2.Owner = buyer.Id
			coinVT2.CoinV = coinVision
			coinVT2.Tally = -deal.CounterBid

			ops = append(ops,
				//＝＝＝转账＝＝＝
				txn.Op{C: "skillIds", Id: sids.Id, Insert: sids},
				txn.Op{C: "coinV", Id: coinVision.Id, Insert: coinVision},
				txn.Op{C: "coinS", Id: coinState.Id, Insert: coinState},
				txn.Op{C: "coinS", Id: coinState2.Id, Insert: coinState2},
				txn.Op{C: "coinTL", Id: ctLog.Id, Insert: ctLog},
				txn.Op{C: "user", Id: coinCreator.Id, Update: M{"$set": M{"skillUpdated": false}}},
				txn.Op{C: "coinVT", Id: coinVT.Id, Insert: coinVT},
				txn.Op{C: "coinVT", Id: coinVT2.Id, Insert: coinVT2},
				//＝＝＝更新订单等＝＝＝
				txn.Op{C: "deal", Id: deal.Id, Update: M{"$set": M{"ctlid": ctLog.Id, "state": 1, "updateAt": time.Now().Unix()}}},
				txn.Op{C: "news", Id: buyerNews.Id, Update: M{"$set": M{"newsType": 102, "updateAt": time.Now().Unix()}}},
				txn.Op{C: "news", Id: sellerNews.Id, Update: M{"$set": M{"newsType": 103, "updateAt": time.Now().Unix()}}},
				txn.Op{C: "news", Id: news.Id, Insert: news},
				txn.Op{C: "news", Id: news2.Id, Insert: news2},
				txn.Op{C: "user", Id: deal.Buyer, Update: M{"$set": M{"hasNews": true}}},
				txn.Op{C: "user", Id: deal.Seller, Update: M{"$set": M{"hasNews": true}}})

			runner := txn.NewRunner(db.C("txns"))
			id := bson.NewObjectId()
			err = runner.Run(ops, id, nil)
			errs.Check400(c, err, errs.E1000)
		} else {
			//版本未变
			//技能列表和上一次发行时一样
			coinState := new(freecoin.CoinS)
			coinState.Id = bson.NewObjectId()
			coinState.User = seller.Id
			coinState.CoinTLId = ctLog.Id
			coinState.CoinVId = coinVisionArray[0].Id
			coinState.CoinT = coinType
			coinState.Count = deal.CounterBid
			coinState.CreatedAt = time.Now()

			coinState2 := new(freecoin.CoinS)
			coinState2.Id = bson.NewObjectId()
			coinState2.User = buyer.Id
			coinState2.CoinTLId = ctLog.Id
			coinState2.CoinVId = coinVisionArray[0].Id
			coinState2.CoinT = coinType
			coinState2.Count = -deal.CounterBid
			coinState2.CreatedAt = time.Now()

			//卖家赚到的同一个版本的鸟币总数
			coinVTNum, err := db.C("coinVT").Find(bson.M{"coinV._id": coinVisionArray[0].Id, "owner": seller.Id}).Count()
			errs.Check400(c, err, errs.E1000)
			coinVT := new(freecoin.CoinVTally)
			if coinVTNum == 0 {
				coinVT.Id = bson.NewObjectId()
				coinVT.Owner = seller.Id
				coinVT.CoinV = coinVisionArray[0]
				coinVT.Tally = deal.CounterBid
			} else {
				err := db.C("coinVT").Find(bson.M{"coinV._id": coinVisionArray[0].Id, "owner": seller.Id}).One(&coinVT)
				errs.Check400(c, err, errs.E1000)
			}
			//卖家
			if coinVTNum == 0 {
				ops = append(ops, txn.Op{C: "coinVT", Id: coinVT.Id, Insert: coinVT})
			} else {
				ops = append(ops, txn.Op{C: "coinVT", Id: coinVT.Id, Update: M{"$inc": M{"tally": deal.CounterBid}}})
			}
			//买家支出的同一个版本的鸟币总数
			coinVT2 := new(freecoin.CoinVTally)
			err = db.C("coinVT").Find(bson.M{"coinV._id": coinVisionArray[0].Id, "owner": buyer.Id}).One(&coinVT2)
			errs.Check400(c, err, errs.E1000)
			//买家
			ops = append(ops, txn.Op{C: "coinVT", Id: coinVT2.Id, Update: M{"$inc": M{"tally": -deal.CounterBid}}})

			ops = append(ops,
				//＝＝＝转账＝＝＝
				txn.Op{C: "coinV", Id: coinVisionArray[0].Id, Update: M{"$inc": M{"tally": deal.CounterBid}}},
				txn.Op{C: "coinS", Id: coinState.Id, Insert: coinState},
				txn.Op{C: "coinS", Id: coinState2.Id, Insert: coinState2},
				txn.Op{C: "coinTL", Id: ctLog.Id, Insert: ctLog},
				txn.Op{C: "user", Id: coinCreator.Id, Update: M{"$set": M{"skillUpdated": false}}},
				//＝＝＝更新订单等＝＝＝
				txn.Op{C: "deal", Id: deal.Id, Update: M{"$set": M{"ctlid": ctLog.Id, "state": 1, "updateAt": time.Now().Unix()}}},
				txn.Op{C: "news", Id: buyerNews.Id, Update: M{"$set": M{"newsType": 102, "updateAt": time.Now().Unix()}}},
				txn.Op{C: "news", Id: sellerNews.Id, Update: M{"$set": M{"newsType": 103, "updateAt": time.Now().Unix()}}},
				txn.Op{C: "news", Id: news.Id, Insert: news},
				txn.Op{C: "news", Id: news2.Id, Insert: news2},
				txn.Op{C: "user", Id: deal.Buyer, Update: M{"$set": M{"hasNews": true}}},
				txn.Op{C: "user", Id: deal.Seller, Update: M{"$set": M{"hasNews": true}}})

			runner := txn.NewRunner(db.C("txns"))
			id := bson.NewObjectId()
			err = runner.Run(ops, id, nil)
			errs.Check400(c, err, errs.E1000)
		}
	} else if coinGoBack == true || otherCreator == true {
		//检查鸟币是否足够
		buyerCoinTTally := freecoin.CoinTTally{}
		err = db.C("coinTT").Find(M{"owner": buyer.Id, "coinT._id": coinType.Id}).One(&buyerCoinTTally)
		errs.Check400(c, err, errs.E1000)
		if buyerCoinTTally.Tally < deal.CounterBid {
			//鸟币数量不够
			c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1018})
			return
		}

		//买家拥有的此鸟币的全部版本(tally大于0)，按照倒序使用鸟币版本
		coinVTs := []freecoin.CoinVTally{}
		err = db.C("coinVT").Find(M{"owner": buyer.Id, "coinV.ctid": coinType.Id, "tally": M{"$gt": 0}}).Sort("-coinV.vision").All(&coinVTs)
		errs.Check400(c, err, errs.E1000)

		leftTransfer := deal.CounterBid
		for i := 0; i < len(coinVTs); i++ {
			var buyerCountChange int64
			var sellerCountChange int64
			breakNow := false
			if coinVTs[i].Tally < leftTransfer {
				leftTransfer = leftTransfer - coinVTs[i].Tally
				buyerCountChange = -coinVTs[i].Tally
				sellerCountChange = coinVTs[i].Tally
			} else {
				buyerCountChange = -leftTransfer
				sellerCountChange = leftTransfer
				breakNow = true
			}

			//--------coinState------------
			coinState := new(freecoin.CoinS)
			coinState.Id = bson.NewObjectId()
			coinState.User = buyer.Id
			coinState.CoinTLId = ctLog.Id
			coinState.CoinVId = coinVTs[i].CoinV.Id
			coinState.CoinT = coinType
			coinState.Count = buyerCountChange
			coinState.CreatedAt = time.Now()

			coinState2 := new(freecoin.CoinS)
			coinState2.Id = bson.NewObjectId()
			coinState2.User = seller.Id
			coinState2.CoinTLId = ctLog.Id
			coinState2.CoinVId = coinVTs[i].CoinV.Id
			coinState2.CoinT = coinType
			coinState2.Count = sellerCountChange
			coinState2.CreatedAt = time.Now()

			ops = append(ops,
				//＝＝＝转账相关＝＝＝
				txn.Op{C: "coinS", Id: coinState.Id, Insert: coinState},
				txn.Op{C: "coinS", Id: coinState2.Id, Insert: coinState2})

			cv := freecoin.CoinV{}
			err = db.C("coinV").FindId(coinVTs[i].CoinV.Id).One(&cv)
			if err != nil {
				errs.Check400(c, err, errs.E1000)
				break
			}

			//--------coinVT------------
			//卖家赚到的同一个版本的鸟币总数
			coinVTNum, err := db.C("coinVT").Find(bson.M{"coinV._id": coinVTs[i].CoinV.Id, "owner": seller.Id}).Count()
			errs.Check400(c, err, errs.E1000)
			coinVT := new(freecoin.CoinVTally)
			if coinVTNum == 0 {
				coinVT.Id = bson.NewObjectId()
				coinVT.Owner = seller.Id
				coinVT.CoinV = cv
				coinVT.Tally = sellerCountChange
			} else {
				err := db.C("coinVT").Find(bson.M{"coinV._id": coinVTs[i].CoinV.Id, "owner": seller.Id}).One(&coinVT)
				errs.Check400(c, err, errs.E1000)
			}
			//买家支出的同一个版本的鸟币总数
			coinVTNum2, err := db.C("coinVT").Find(bson.M{"coinV._id": coinVTs[i].CoinV.Id, "owner": buyer.Id}).Count()
			errs.Check400(c, err, errs.E1000)
			coinVT2 := new(freecoin.CoinVTally)
			if coinVTNum2 == 0 {
				coinVT2.Id = bson.NewObjectId()
				coinVT2.Owner = buyer.Id
				coinVT2.CoinV = cv
				coinVT2.Tally = buyerCountChange
			} else {
				err := db.C("coinVT").Find(bson.M{"coinV._id": coinVTs[i].CoinV.Id, "owner": buyer.Id}).One(&coinVT2)
				errs.Check400(c, err, errs.E1000)
			}
			//卖家
			if coinVTNum == 0 {
				ops = append(ops, txn.Op{C: "coinVT", Id: coinVT.Id, Insert: coinVT})
			} else {
				ops = append(ops, txn.Op{C: "coinVT", Id: coinVT.Id, Update: M{"$inc": M{"tally": sellerCountChange}}})
			}
			//买家
			if coinVTNum2 == 0 {
				ops = append(ops, txn.Op{C: "coinVT", Id: coinVT2.Id, Insert: coinVT2})
			} else {
				ops = append(ops, txn.Op{C: "coinVT", Id: coinVT2.Id, Update: M{"$inc": M{"tally": buyerCountChange}}})
			}

			if breakNow {
				break
			}
		}

		if coinGoBack == true {
			ctLog.CoinGoBack = true
			if deal.SuperCoin {
				news2.Msg = "回收了 " + counterBid + "个 超级" + deal.CoinName + "币,来自于[" + buyer.Name + "]的订单"
			} else {
				if isAccpetTheRejected {
					news2.Msg = "重新接受了之前拒绝的鸟币回流，相对应的鸟币信用已经恢复。回收了 " + counterBid + "个 " + deal.CoinName + "币,来自于[" + buyer.Name + "]的订单"
				} else {
					news2.Msg = "回收了 " + counterBid + "个 " + deal.CoinName + "币,来自于[" + buyer.Name + "]的订单"
				}
			}
		}
		ops = append(ops,
			//＝＝＝转账相关＝＝＝
			txn.Op{C: "coinTL", Id: ctLog.Id, Insert: ctLog},
			//＝＝＝更新订单等＝＝＝
			txn.Op{C: "deal", Id: deal.Id, Update: M{"$set": M{"ctlid": ctLog.Id, "state": 1, "updateAt": time.Now().Unix()}}},
			txn.Op{C: "news", Id: buyerNews.Id, Update: M{"$set": M{"newsType": 102, "updateAt": time.Now().Unix()}}},
			txn.Op{C: "news", Id: sellerNews.Id, Update: M{"$set": M{"newsType": 103, "updateAt": time.Now().Unix()}}},
			txn.Op{C: "news", Id: news.Id, Insert: news},
			txn.Op{C: "news", Id: news2.Id, Insert: news2},
			txn.Op{C: "user", Id: deal.Buyer, Update: M{"$set": M{"hasNews": true}}},
			txn.Op{C: "user", Id: deal.Seller, Update: M{"$set": M{"hasNews": true}}})

		runner := txn.NewRunner(db.C("txns"))
		id := bson.NewObjectId()
		err = runner.Run(ops, id, nil)
		errs.Check400(c, err, errs.E1000)
	}

	c.JSON(http.StatusCreated, gin.H{"status": "ok"})
}

func RankDeal(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	did := bson.ObjectIdHex(c.Param("did"))

	rf := new(model.RankForm)
	if c.BindJSON(&rf) == nil {
		err := db.C("deal").UpdateId(did, bson.M{"$set": bson.M{"rank": rf.Rank, "comment": rf.Comment}})
		errs.Check400(c, err, errs.E1000)
		c.JSON(http.StatusCreated, gin.H{"status": "ok"})
	} else {
		c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1010})
	}
}

func CloseDeal(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	did := bson.ObjectIdHex(c.Param("did"))

	deal := freecoin.Deal{}
	err := db.C("deal").FindId(did).One(&deal)
	errs.Check400(c, err, errs.E1000)

	if deal.State == 3 {
		c.JSON(http.StatusCreated, gin.H{"status": "ok"})
		return
	}

	//买家消息需更新
	buyerNews := model.News{}
	err = db.C("news").Find(M{"did": did, "toUser": deal.Buyer}).One(&buyerNews)
	errs.Check400(c, err, errs.E1000)
	//卖家消息需更新
	sellerNews := model.News{}
	err = db.C("news").Find(M{"did": did, "toUser": deal.Seller}).One(&sellerNews)
	errs.Check400(c, err, errs.E1000)

	runner := txn.NewRunner(db.C("txns"))
	ops := []txn.Op{
		{C: "deal", Id: deal.Id, Update: M{"$set": M{"state": 3, "updateAt": time.Now().Unix()}}},
		{C: "news", Id: buyerNews.Id, Update: M{"$set": M{"newsType": 106, "updateAt": time.Now().Unix()}}},
		{C: "news", Id: sellerNews.Id, Update: M{"$set": M{"newsType": 107, "updateAt": time.Now().Unix()}}},
	}
	id := bson.NewObjectId()
	err = runner.Run(ops, id, nil)
	errs.Check400(c, err, errs.E1000)

	c.JSON(http.StatusCreated, gin.H{"status": "ok"})
}
