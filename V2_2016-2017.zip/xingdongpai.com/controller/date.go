package controller

import (
	"fmt"
	"math/rand"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"gopkg.in/mgo.v2/txn"
	"xingdongpai.com/errs"
	"xingdongpai.com/freecoin"
	"xingdongpai.com/model"
)

//NewDate 新建面基
func NewDate(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)

	dateForm := new(model.DateForm)
	if c.BindJSON(&dateForm) == nil {
		if user.Id.Hex() == dateForm.Owner {
			c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1016})
			return
		}

		//4位数字暗号
		rnd := rand.New(rand.NewSource(time.Now().UnixNano()))
		cue := fmt.Sprintf("%04v", rnd.Int31n(10000))

		date := new(model.Date)
		date.Id = bson.NewObjectId()
		date.ScriptId = bson.ObjectIdHex(dateForm.ScriptId)
		date.Owner = bson.ObjectIdHex(dateForm.Owner)
		date.Sender = user.Id
		date.SenderAddr = dateForm.SenderAddr
		date.SenderTime = dateForm.SenderTime
		date.Note = dateForm.Note
		date.State = 0
		date.Cue = cue
		date.IsDelete = false
		date.CreatedAt = time.Now()

		//搭档消息
		news := new(model.News)
		news.Id = bson.NewObjectId()
		news.DId = date.Id
		news.ToUser = date.Sender
		news.NewsType = 200
		news.UpdateAt = time.Now().Unix()
		news.CreatedAt = time.Now()
		//楼主消息
		news2 := new(model.News)
		news2.Id = bson.NewObjectId()
		news2.DId = date.Id
		news2.ToUser = date.Owner
		news2.NewsType = 201
		news2.UpdateAt = time.Now().Unix()
		news2.CreatedAt = time.Now()

		//新建面基请求，插入数据库
		runner := txn.NewRunner(db.C("txns"))
		ops := []txn.Op{
			{C: "news", Id: news.Id, Insert: news},
			{C: "news", Id: news2.Id, Insert: news2},
			{C: "date", Id: date.Id, Insert: date},
			{C: "user", Id: date.Sender, Update: M{"$set": M{"hasNews": true}}},
			{C: "user", Id: date.Owner, Update: M{"$set": M{"hasNews": true}}},
		}
		id := bson.NewObjectId()
		err := runner.Run(ops, id, nil)
		errs.Check400(c, err, errs.E1000)

		c.JSON(http.StatusCreated, date)
	} else {
		c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1010})
	}
}

//DateByID 通过id获取面基
func DateByID(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	// user := c.MustGet(gin.AuthUserKey).(model.User)
	did := bson.ObjectIdHex(c.Param("did"))

	date := model.Date{}
	err := db.C("date").FindId(did).One(&date)
	errs.Check400(c, err, errs.E1000)

	c.JSON(http.StatusOK, date)
}

func RejectDate(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	owner := c.MustGet(gin.AuthUserKey).(model.User)
	did := bson.ObjectIdHex(c.Param("did"))

	date := model.Date{}
	err := db.C("date").FindId(did).One(&date)
	errs.Check400(c, err, errs.E1000)

	//搭档消息需更新
	senderNews := model.News{}
	err = db.C("news").Find(M{"did": did, "toUser": date.Sender}).One(&senderNews)
	errs.Check400(c, err, errs.E1000)
	//楼主消息需更新
	ownerNews := model.News{}
	err = db.C("news").Find(M{"did": did, "toUser": date.Owner}).One(&ownerNews)
	errs.Check400(c, err, errs.E1000)
	//搭档被拒绝消息提示
	news := model.News{}
	news.Id = bson.NewObjectId()
	news.DId = date.Id
	news.ToUser = date.Sender
	news.Msg = owner.Name + "婉拒了你的入戏请求"
	news.NewsType = 0
	news.UpdateAt = time.Now().Unix()
	news.CreatedAt = time.Now()

	runner := txn.NewRunner(db.C("txns"))
	ops := []txn.Op{
		{C: "date", Id: date.Id, Update: M{"$set": M{"state": 2, "updateAt": time.Now().Unix()}}},
		{C: "news", Id: senderNews.Id, Update: M{"$set": M{"newsType": 204, "updateAt": time.Now().Unix()}}},
		{C: "news", Id: ownerNews.Id, Update: M{"$set": M{"newsType": 205, "updateAt": time.Now().Unix()}}},
		{C: "news", Id: news.Id, Insert: news},
		{C: "user", Id: date.Sender, Update: M{"$set": M{"hasNews": true}}},
	}
	id := bson.NewObjectId()
	err = runner.Run(ops, id, nil)
	errs.Check400(c, err, errs.E1000)

	c.JSON(http.StatusCreated, gin.H{"status": "ok"})
}

func AcceptDate(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	owner := c.MustGet(gin.AuthUserKey).(model.User)
	did := bson.ObjectIdHex(c.Param("did"))

	date := model.Date{}
	err := db.C("date").FindId(did).One(&date)
	errs.Check400(c, err, errs.E1000)

	//搭档消息需更新
	senderNews := model.News{}
	err = db.C("news").Find(M{"did": did, "toUser": date.Sender}).One(&senderNews)
	errs.Check400(c, err, errs.E1000)
	//楼主消息需更新
	ownerNews := model.News{}
	err = db.C("news").Find(M{"did": did, "toUser": date.Owner}).One(&ownerNews)
	errs.Check400(c, err, errs.E1000)
	//搭档消息提示
	news := model.News{}
	news.Id = bson.NewObjectId()
	news.DId = date.Id
	news.ToUser = date.Sender
	news.Msg = "[" + owner.Name + "]接受了你的入戏请求"
	news.NewsType = 0
	news.UpdateAt = time.Now().Unix()
	news.CreatedAt = time.Now()

	runner := txn.NewRunner(db.C("txns"))
	ops := []txn.Op{
		{C: "date", Id: date.Id, Update: M{"$set": M{"state": 1, "updateAt": time.Now().Unix()}}},
		{C: "news", Id: senderNews.Id, Update: M{"$set": M{"newsType": 202, "updateAt": time.Now().Unix()}}},
		{C: "news", Id: ownerNews.Id, Update: M{"$set": M{"newsType": 203, "updateAt": time.Now().Unix()}}},
		{C: "news", Id: news.Id, Insert: news},
		{C: "user", Id: date.Sender, Update: M{"$set": M{"hasNews": true}}},
	}
	id := bson.NewObjectId()
	err = runner.Run(ops, id, nil)
	errs.Check400(c, err, errs.E1000)

	c.JSON(http.StatusCreated, gin.H{"status": "ok"})
}

func Met(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	sender := c.MustGet(gin.AuthUserKey).(model.User)
	did := bson.ObjectIdHex(c.Param("did"))

	date := model.Date{}
	err := db.C("date").FindId(did).One(&date)
	errs.Check400(c, err, errs.E1000)
	script := model.Script{}
	err = db.C("script").FindId(date.ScriptId).One(&script)
	errs.Check400(c, err, errs.E1000)

	//搭档消息需更新
	senderNews := model.News{}
	err = db.C("news").Find(M{"did": did, "toUser": sender.Id}).One(&senderNews)
	errs.Check400(c, err, errs.E1000)
	//楼主消息需更新
	ownerNews := model.News{}
	err = db.C("news").Find(M{"did": did, "toUser": date.Owner}).One(&ownerNews)
	errs.Check400(c, err, errs.E1000)

	ops := []txn.Op{{C: "date", Id: did, Update: M{"$set": M{"state": 3, "updateAt": time.Now().Unix()}}}}
	if script.Pay {
		ops = append(ops,
			txn.Op{C: "news", Id: senderNews.Id, Update: M{"$set": M{"newsType": 208, "updateAt": time.Now().Unix()}}},
			txn.Op{C: "news", Id: ownerNews.Id, Update: M{"$set": M{"newsType": 209, "updateAt": time.Now().Unix()}}})

	} else {
		ops = append(ops,
			txn.Op{C: "news", Id: senderNews.Id, Update: M{"$set": M{"newsType": 206, "updateAt": time.Now().Unix()}}},
			txn.Op{C: "news", Id: ownerNews.Id, Update: M{"$set": M{"newsType": 207, "updateAt": time.Now().Unix()}}})
	}
	runner := txn.NewRunner(db.C("txns"))
	id := bson.NewObjectId()
	err = runner.Run(ops, id, nil)
	errs.Check400(c, err, errs.E1000)

	c.JSON(http.StatusCreated, gin.H{"status": "ok"})
}

func Pay(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	owner := c.MustGet(gin.AuthUserKey).(model.User)
	lock := c.MustGet("lock").(*freecoin.TransferLocks)
	did := bson.ObjectIdHex(c.Param("did"))

	//面基
	date := model.Date{}
	err := db.C("date").FindId(did).One(&date)
	errs.Check400(c, err, errs.E1000)
	//剧本
	script := model.Script{}
	err = db.C("script").FindId(date.ScriptId).Select(bson.M{"_id": 1, "superCoin": 1, "price": 1, "coinName": 1}).One(&script)
	errs.Check400(c, err, errs.E1000)

	//交易锁
	if lock.Locks[date.Owner.Hex()] == true || lock.Locks[date.Sender.Hex()] == true {
		http.Error(c.Writer, errs.E1019, http.StatusBadRequest)
		return
	}
	lock.Locks[date.Owner.Hex()] = true
	lock.Locks[date.Sender.Hex()] = true
	defer func() {
		delete(lock.Locks, date.Owner.Hex())
		delete(lock.Locks, date.Sender.Hex())
	}()

	//搭档
	sender := model.User{}
	err = db.C("user").FindId(date.Sender).Select(bson.M{"_id": 1, "coinAlias": 1, "name": 1}).One(&sender)
	errs.Check400(c, err, errs.E1000)
	//搭档消息需更新
	senderNews := model.News{}
	err = db.C("news").Find(M{"did": did, "toUser": date.Sender}).One(&senderNews)
	errs.Check400(c, err, errs.E1000)
	//楼主消息需更新
	ownerNews := model.News{}
	err = db.C("news").Find(M{"did": did, "toUser": owner.Id}).One(&ownerNews)
	errs.Check400(c, err, errs.E1000)
	//搭档收到片酬消息提示
	price := script.Price
	priceStr := strconv.FormatInt(price, 10)
	if script.SuperCoin {
		price = 1
		priceStr = "1"
	}
	news := model.News{}
	news.Id = bson.NewObjectId()
	news.DId = date.Id
	news.ToUser = sender.Id
	if script.SuperCoin {
		news.Msg = "你收到了[" + owner.Name + "]支付的片酬：" + priceStr + "个 超级" + script.CoinName + "币"
	} else {
		news.Msg = "你收到了[" + owner.Name + "]支付的片酬：" + priceStr + "个 " + script.CoinName + "币"
	}
	news.NewsType = 0
	news.UpdateAt = time.Now().Unix()
	news.CreatedAt = time.Now()
	//楼主支出片酬消息提示
	news2 := model.News{}
	news2.Id = bson.NewObjectId()
	news2.DId = date.Id
	news2.ToUser = owner.Id
	if script.SuperCoin {
		news2.Msg = "你支付了 " + priceStr + "个 超级" + script.CoinName + "币给[" + sender.Name + "]作为片酬"
	} else {
		news2.Msg = "你支付了 " + priceStr + "个 " + script.CoinName + "币给[" + sender.Name + "]作为片酬"
	}
	news2.NewsType = 0
	news2.UpdateAt = time.Now().Unix()
	news2.CreatedAt = time.Now()

	//====================转账相关=======================
	//鸟币类型
	coinType := new(freecoin.CoinT)
	err = db.C("coinT").Find(bson.M{"alias": script.CoinName, "superCoin": script.SuperCoin}).One(&coinType)
	errs.Check400(c, err, errs.E1000)
	//鸟币发行者
	coinCreator := new(model.User)
	err = db.C("user").FindId(coinType.Creator).Select(bson.M{"_id": 1, "skillUpdated": 1}).One(&coinCreator)
	errs.Check400(c, err, errs.E1000)
	//转账流水transferLog
	ctLog := new(freecoin.CoinTransferLog)
	ctLog.Id = bson.NewObjectId()
	ctLog.FromUser = owner.Id
	ctLog.ToUser = sender.Id
	ctLog.Tally = price
	ctLog.CoinT = coinType
	ctLog.CoinGoBack = false
	ctLog.Note = date.Note
	ctLog.CreatedAt = time.Now()

	//============coinTT=============
	//搭档赚到的此类型鸟币总数
	coinTTNum, err := db.C("coinTT").Find(bson.M{"coinT._id": coinType.Id, "owner": sender.Id}).Count()
	errs.Check400(c, err, errs.E1000)
	coinTT := new(freecoin.CoinTTally)
	if coinTTNum == 0 {
		coinTT.Id = bson.NewObjectId()
		coinTT.Owner = sender.Id
		coinTT.CoinType = coinType
		coinTT.Tally = price
	} else {
		err := db.C("coinTT").Find(bson.M{"coinT._id": coinType.Id, "owner": sender.Id}).One(&coinTT)
		errs.Check400(c, err, errs.E1000)
	}
	//楼主支出的此类型鸟币总数
	coinTTNum2, err := db.C("coinTT").Find(bson.M{"coinT._id": coinType.Id, "owner": owner.Id}).Count()
	errs.Check400(c, err, errs.E1000)
	coinTT2 := new(freecoin.CoinTTally)
	if coinTTNum2 == 0 {
		coinTT2.Id = bson.NewObjectId()
		coinTT2.Owner = owner.Id
		coinTT2.CoinType = coinType
		coinTT2.Tally = -price
	} else {
		err := db.C("coinTT").Find(bson.M{"coinT._id": coinType.Id, "owner": owner.Id}).One(&coinTT2)
		errs.Check400(c, err, errs.E1000)
	}
	ops := []txn.Op{}
	//搭档
	if coinTTNum == 0 {
		ops = append(ops, txn.Op{C: "coinTT", Id: coinTT.Id, Insert: coinTT})
	} else {
		ops = append(ops, txn.Op{C: "coinTT", Id: coinTT.Id, Update: M{"$inc": M{"tally": price}}})
	}
	//楼主
	if coinTTNum2 == 0 {
		ops = append(ops, txn.Op{C: "coinTT", Id: coinTT2.Id, Insert: coinTT2})
	} else {
		ops = append(ops, txn.Op{C: "coinTT", Id: coinTT2.Id, Update: M{"$inc": M{"tally": -price}}})
	}
	//============coinTT=============
	//~~~~
	//情况1.买家或转账方使用自己发行的鸟币
	//情况2.买家或转账方使用收款人方发行的鸟币(即鸟币回流)
	//情况3.买家或转账方使用第三方发行的鸟币
	//~~~~~这里目前只考虑情况1~~~~~

	//技能id列表
	skillList := []freecoin.Skill{}
	if script.SuperCoin {
		err = db.C("skill").Find(bson.M{"owner": coinType.Creator, "inStock": true, "price": 0}).Select(bson.M{"_id": 1}).Sort("-createdAt").All(&skillList)
		errs.Check400(c, err, errs.E1000)
	} else {
		err = db.C("skill").Find(bson.M{"owner": coinType.Creator, "inStock": true, "price": M{"$gt": 0}}).Select(bson.M{"_id": 1}).Sort("-createdAt").All(&skillList)
		errs.Check400(c, err, errs.E1000)
	}
	skillIdList := []bson.ObjectId{}
	for _, s := range skillList {
		skillIdList = append(skillIdList, s.Id)
	}
	//发行次数
	coinVNum, err := db.C("coinV").Find(bson.M{"ctid": coinType.Id}).Count()
	errs.Check400(c, err, errs.E1000)
	//获取最后一个发行版本
	coinVisionArray := []freecoin.CoinV{}
	if coinVNum > 0 {
		err = db.C("coinV").Find(bson.M{"ctid": coinType.Id}).Limit(1).Sort("-createdAt").All(&coinVisionArray)
		errs.Check400(c, err, errs.E1000)
	}
	//发行(转账或交易)鸟币时，若技能有改动，则版本号+1
	if coinCreator.SkillUpdated == true || coinVNum == 0 {
		//版本＋1
		sids := new(freecoin.SkillIds)
		sids.Id = bson.NewObjectId()
		sids.List = skillIdList
		sids.CreatedAt = time.Now()

		coinVision := freecoin.CoinV{}
		coinVision.Id = bson.NewObjectId()
		coinVision.CoinTId = coinType.Id
		coinVision.CreatedAt = time.Now()
		coinVision.SkillIdList = sids.Id
		if coinVNum == 0 {
			coinVision.Vision = 1
		} else {
			coinVision.Vision = coinVisionArray[0].Vision + 1
		}
		//搭档收入明细
		coinState := new(freecoin.CoinS)
		coinState.Id = bson.NewObjectId()
		coinState.User = sender.Id
		coinState.CoinTLId = ctLog.Id
		coinState.CoinVId = coinVision.Id
		coinState.CoinT = coinType
		coinState.Count = price
		coinState.CreatedAt = time.Now()
		//楼主支出明细
		coinState2 := new(freecoin.CoinS)
		coinState2.Id = bson.NewObjectId()
		coinState2.User = owner.Id
		coinState2.CoinTLId = ctLog.Id
		coinState2.CoinVId = coinVision.Id
		coinState2.CoinT = coinType
		coinState2.Count = -price
		coinState2.CreatedAt = time.Now()

		//搭档赚到的同一个版本的鸟币总数
		coinVT := new(freecoin.CoinVTally)
		coinVT.Id = bson.NewObjectId()
		coinVT.Owner = sender.Id
		coinVT.CoinV = coinVision
		coinVT.Tally = price
		//楼主支出的同一个版本的鸟币总数
		coinVT2 := new(freecoin.CoinVTally)
		coinVT2.Id = bson.NewObjectId()
		coinVT2.Owner = owner.Id
		coinVT2.CoinV = coinVision
		coinVT2.Tally = -price

		ops = append(ops,
			//＝＝＝转账＝＝＝
			txn.Op{C: "skillIds", Id: sids.Id, Insert: sids},
			txn.Op{C: "coinV", Id: coinVision.Id, Insert: coinVision},
			txn.Op{C: "coinS", Id: coinState.Id, Insert: coinState},
			txn.Op{C: "coinS", Id: coinState2.Id, Insert: coinState2},
			txn.Op{C: "coinTL", Id: ctLog.Id, Insert: ctLog},
			txn.Op{C: "user", Id: coinCreator.Id, Update: M{"$set": M{"skillUpdated": false}}},
			txn.Op{C: "coinVT", Id: coinVT.Id, Insert: coinVT},
			txn.Op{C: "coinVT", Id: coinVT2.Id, Insert: coinVT2},
			//＝＝＝更新面基和消息＝＝＝
			txn.Op{C: "date", Id: did, Update: M{"$set": M{"state": 4, "updateAt": time.Now().Unix()}}},
			txn.Op{C: "news", Id: senderNews.Id, Update: M{"$set": M{"newsType": 210, "updateAt": time.Now().Unix()}}},
			txn.Op{C: "news", Id: ownerNews.Id, Update: M{"$set": M{"newsType": 211, "updateAt": time.Now().Unix()}}},
			txn.Op{C: "news", Id: news.Id, Insert: news},
			txn.Op{C: "news", Id: news2.Id, Insert: news2},
			txn.Op{C: "user", Id: date.Owner, Update: M{"$set": M{"hasNews": true}}},
			txn.Op{C: "user", Id: date.Sender, Update: M{"$set": M{"hasNews": true}}})

		runner := txn.NewRunner(db.C("txns"))
		id := bson.NewObjectId()
		err = runner.Run(ops, id, nil)
		errs.Check400(c, err, errs.E1000)
	} else {
		//版本未变
		//技能列表和上一次发行时一样
		coinState := new(freecoin.CoinS)
		coinState.Id = bson.NewObjectId()
		coinState.User = sender.Id
		coinState.CoinTLId = ctLog.Id
		coinState.CoinVId = coinVisionArray[0].Id
		coinState.CoinT = coinType
		coinState.Count = price
		coinState.CreatedAt = time.Now()

		coinState2 := new(freecoin.CoinS)
		coinState2.Id = bson.NewObjectId()
		coinState2.User = owner.Id
		coinState2.CoinTLId = ctLog.Id
		coinState2.CoinVId = coinVisionArray[0].Id
		coinState2.CoinT = coinType
		coinState2.Count = -price
		coinState2.CreatedAt = time.Now()

		//搭档赚到的同一个版本的鸟币总数
		coinVTNum, err := db.C("coinVT").Find(bson.M{"coinV._id": coinVisionArray[0].Id, "owner": sender.Id}).Count()
		errs.Check400(c, err, errs.E1000)
		coinVT := new(freecoin.CoinVTally)
		if coinVTNum == 0 {
			coinVT.Id = bson.NewObjectId()
			coinVT.Owner = sender.Id
			coinVT.CoinV = coinVisionArray[0]
			coinVT.Tally = price
		} else {
			err := db.C("coinVT").Find(bson.M{"coinV._id": coinVisionArray[0].Id, "owner": sender.Id}).One(&coinVT)
			errs.Check400(c, err, errs.E1000)
		}
		//搭档
		if coinVTNum == 0 {
			ops = append(ops, txn.Op{C: "coinVT", Id: coinVT.Id, Insert: coinVT})
		} else {
			ops = append(ops, txn.Op{C: "coinVT", Id: coinVT.Id, Update: M{"$inc": M{"tally": price}}})
		}
		//楼主支出的同一个版本的鸟币总数
		coinVT2 := new(freecoin.CoinVTally)
		err = db.C("coinVT").Find(bson.M{"coinV._id": coinVisionArray[0].Id, "owner": owner.Id}).One(&coinVT2)
		errs.Check400(c, err, errs.E1000)
		//楼主
		ops = append(ops, txn.Op{C: "coinVT", Id: coinVT2.Id, Update: M{"$inc": M{"tally": -price}}})

		ops = append(ops,
			//＝＝＝转账＝＝＝
			txn.Op{C: "coinV", Id: coinVisionArray[0].Id, Update: M{"$inc": M{"tally": price}}},
			txn.Op{C: "coinS", Id: coinState.Id, Insert: coinState},
			txn.Op{C: "coinS", Id: coinState2.Id, Insert: coinState2},
			txn.Op{C: "coinTL", Id: ctLog.Id, Insert: ctLog},
			txn.Op{C: "user", Id: coinCreator.Id, Update: M{"$set": M{"skillUpdated": false}}},
			//＝＝＝更新面基和消息＝＝＝
			txn.Op{C: "date", Id: did, Update: M{"$set": M{"state": 4, "updateAt": time.Now().Unix()}}},
			txn.Op{C: "news", Id: senderNews.Id, Update: M{"$set": M{"newsType": 210, "updateAt": time.Now().Unix()}}},
			txn.Op{C: "news", Id: ownerNews.Id, Update: M{"$set": M{"newsType": 211, "updateAt": time.Now().Unix()}}},
			txn.Op{C: "news", Id: news.Id, Insert: news},
			txn.Op{C: "news", Id: news2.Id, Insert: news2},
			txn.Op{C: "user", Id: date.Owner, Update: M{"$set": M{"hasNews": true}}},
			txn.Op{C: "user", Id: date.Sender, Update: M{"$set": M{"hasNews": true}}})

		runner := txn.NewRunner(db.C("txns"))
		id := bson.NewObjectId()
		err = runner.Run(ops, id, nil)
		errs.Check400(c, err, errs.E1000)
	}

	c.JSON(http.StatusCreated, gin.H{"status": "ok"})
}

func RankDate(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	did := bson.ObjectIdHex(c.Param("did"))

	rf := new(model.RankForm)
	if c.BindJSON(&rf) == nil {
		err := db.C("date").UpdateId(did, bson.M{"$set": bson.M{"rank": rf.Rank, "comment": rf.Comment}})
		errs.Check400(c, err, errs.E1000)
		c.JSON(http.StatusCreated, gin.H{"status": "ok"})
	} else {
		c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1010})
	}
}
