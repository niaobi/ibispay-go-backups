package controller

import (
	"github.com/asaskevich/govalidator"
	"github.com/gin-gonic/gin"
	"github.com/kennygrant/sanitize"
	"github.com/microcosm-cc/bluemonday"
	"github.com/russross/blackfriday"
	"github.com/sgoertzen/html2text"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"html/template"
	"net/http"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"
	"xingdongpai.com/errs"
	"xingdongpai.com/freecoin"
	"xingdongpai.com/model"
	"xingdongpai.com/utils"
)

const (
	PassionListPage = 20
)

func NewPassion(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)

	passion := freecoin.Passion{}
	if c.Bind(&passion) == nil {
		if passion.Md {
			// 把markdown转换成html
			passion.DescHtml = getHtmlFromMarkdown(passion.DescMarkdown)
			// 获取标题和正文
			passion.Title, passion.DescText = getTitleAndBodyFromHtml(passion.DescHtml)
			if govalidator.IsNull(passion.Title) || govalidator.IsNull(passion.DescText) {
				c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1024})
				return
			}
			//获取缩略描述
			if utf8.RuneCountInString(passion.DescText) > 128 {
				passion.Desc = utils.SubString(passion.DescText, 0, 128)
			} else {
				passion.Desc = passion.DescText
			}
		} else {
			// 把\n\n全部转换成<br>
			passion.DescHtml = strings.Join(strings.Split(passion.DescHtml, "\n\n"), "<br>")
			// 确保合法性
			passion.DescHtml = bluemonday.UGCPolicy().Sanitize(passion.DescHtml)
			//获取缩略描述
			if utf8.RuneCountInString(passion.DescText) > 128 {
				passion.Desc = utils.SubString(passion.DescText, 0, 128)
			} else {
				passion.Desc = passion.DescText
			}
		}

		passion.Id = bson.NewObjectId()
		passion.Owner = user.Id
		passion.UpdateAt = time.Now().Unix()
		passion.CreatedAt = time.Now()

		//新建技能，插入数据库
		err := db.C("passion").Insert(passion)
		errs.Check400(c, err, errs.E1000)

		//激活超级鸟币
		if user.SuperCoinEnabled == false {
			db.C("user").UpsertId(user.Id, bson.M{"$set": bson.M{"superCoinEnabled": true}})
		}

		c.JSON(http.StatusCreated, passion)
	} else {
		c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1010})
	}
}

func EditPassion(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	pid := bson.ObjectIdHex(c.Param("pid"))

	passion := freecoin.Passion{}
	if c.Bind(&passion) == nil {
		if passion.Md {
			// 把markdown转换成html
			passion.DescHtml = getHtmlFromMarkdown(passion.DescMarkdown)
			// 获取标题和正文
			passion.Title, passion.DescText = getTitleAndBodyFromHtml(passion.DescHtml)
			if govalidator.IsNull(passion.Title) || govalidator.IsNull(passion.DescText) {
				c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1024})
				return
			}
			//获取缩略描述
			if utf8.RuneCountInString(passion.DescText) > 128 {
				passion.Desc = utils.SubString(passion.DescText, 0, 128)
			} else {
				passion.Desc = passion.DescText
			}
		} else {
			// 把\n\n全部转换成<br>
			passion.DescHtml = strings.Join(strings.Split(passion.DescHtml, "\n\n"), "<br>")
			// 确保合法性
			passion.DescHtml = bluemonday.UGCPolicy().Sanitize(passion.DescHtml)
			//获取缩略描述
			if utf8.RuneCountInString(passion.DescText) > 128 {
				passion.Desc = utils.SubString(passion.DescText, 0, 128)
			} else {
				passion.Desc = passion.DescText
			}
		}

		err := db.C("passion").Update(bson.M{"_id": pid}, bson.M{"$set": bson.M{"title": passion.Title, "desc": passion.Desc, "descText": passion.DescText, "descMarkdown": passion.DescMarkdown, "descHtml": passion.DescHtml, "updateAt": time.Now().Unix()}})
		errs.Check400(c, err, errs.E1000)

		c.JSON(http.StatusOK, gin.H{"status": "ok"})
	} else {
		c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1010})
	}
}

func PassionHtmlById(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	pid := bson.ObjectIdHex(c.Param("pid"))

	passion := freecoin.Passion{}
	err := db.C("passion").FindId(pid).Select(bson.M{"owner": 1, "md": 1, "title": 1, "descHtml": 1, "views": 1, "updateAt": 1, "createdAt": 1}).One(&passion)
	errs.Check400(c, err, errs.E1000)

	user := model.User{}
	db.C("user").FindId(passion.Owner).Select(bson.M{"name": 1}).One(&user)
	errs.Check400(c, err, errs.E1000)

	if passion.Md {
		c.HTML(http.StatusOK, "GFM.tmpl", gin.H{
			"Title":    passion.Title,
			"DescHtml": template.HTML(passion.DescHtml),
			"Name":     user.Name,
		})
	} else {
		titleTag := "<h1>" + passion.Title + "</h1>"
		c.HTML(http.StatusOK, "GFM.tmpl", gin.H{
			"Title":     passion.Title,
			"TitleHtml": template.HTML(titleTag),
			"DescHtml":  template.HTML(passion.DescHtml),
			"Name":      user.Name,
		})
	}

	db.C("passion").Update(bson.M{"_id": passion.Id}, bson.M{"$inc": bson.M{"views": +1}, "$set": bson.M{"updateAt": time.Now().Unix()}})
}

func PassionById(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	pid := bson.ObjectIdHex(c.Param("pid"))
	md, _ := strconv.Atoi(c.Param("md"))

	passion := freecoin.Passion{}
	if md == 0 {
		err := db.C("passion").FindId(pid).Select(bson.M{"owner": 1, "md": 1, "title": 1, "descHtml": 1, "views": 1, "updateAt": 1, "createdAt": 1}).One(&passion)
		errs.Check400(c, err, errs.E1000)
	} else {
		err := db.C("passion").FindId(pid).Select(bson.M{"owner": 1, "md": 1, "title": 1, "descMarkdown": 1, "views": 1, "updateAt": 1, "createdAt": 1}).One(&passion)
		errs.Check400(c, err, errs.E1000)
	}

	c.JSON(http.StatusOK, passion)
}

func PassionListById(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)
	skip, _ := strconv.Atoi(c.Param("skip"))

	uid := bson.ObjectIdHex(c.Param("uid"))
	if govalidator.IsNull(c.Param("uid")) {
		uid = user.Id
	}

	passionList := []freecoin.Passion{}
	err := db.C("passion").Find(bson.M{"owner": uid}).Select(bson.M{"owner": 1, "md": 1, "title": 1, "desc": 1, "views": 1, "updateAt": 1, "createdAt": 1}).Skip(skip).Limit(PassionListPage).Sort("-createdAt").All(&passionList)
	errs.Check400(c, err, errs.E1000)

	returnSkip := skip + PassionListPage
	if len(passionList) < PassionListPage {
		returnSkip = -1
	}

	c.JSON(http.StatusOK, gin.H{"list": passionList, "skip": returnSkip})
}

//==========private functions===========
func getHtmlFromMarkdown(input string) string {

	htmlFlags := 0
	htmlFlags |= blackfriday.HTML_USE_XHTML
	htmlFlags |= blackfriday.HTML_USE_SMARTYPANTS
	htmlFlags |= blackfriday.HTML_SMARTYPANTS_FRACTIONS
	htmlFlags |= blackfriday.HTML_SMARTYPANTS_DASHES
	htmlFlags |= blackfriday.HTML_FOOTNOTE_RETURN_LINKS
	htmlFlags |= blackfriday.HTML_HREF_TARGET_BLANK

	renderer := blackfriday.HtmlRenderer(htmlFlags, "", "")

	extensions := 0
	extensions |= blackfriday.EXTENSION_TABLES
	extensions |= blackfriday.EXTENSION_FENCED_CODE
	extensions |= blackfriday.EXTENSION_AUTOLINK
	extensions |= blackfriday.EXTENSION_STRIKETHROUGH
	extensions |= blackfriday.EXTENSION_SPACE_HEADERS
	extensions |= blackfriday.EXTENSION_HARD_LINE_BREAK
	extensions |= blackfriday.EXTENSION_FOOTNOTES
	extensions |= blackfriday.EXTENSION_NO_EMPTY_LINE_BEFORE_BLOCK
	extensions |= blackfriday.EXTENSION_HEADER_IDS
	extensions |= blackfriday.EXTENSION_TITLEBLOCK
	extensions |= blackfriday.EXTENSION_DEFINITION_LISTS

	unSafe := blackfriday.Markdown([]byte(input), renderer, extensions)
	html := bluemonday.UGCPolicy().SanitizeBytes(unSafe)

	return string(html)
}

func getTitleAndBodyFromHtml(input string) (string, string) {
	strs := strings.Split(input, "\n")
	//－－－－－标题－－－－－－
	var strTitle string
	if len(strs) > 0 {
		strTitle = strs[0]
	} else {
		return "", ""
	}
	//转换成纯文本,最多20个字  todo：字数判断有点小问题
	if utf8.RuneCountInString(strTitle) > 20 {
		strTitle = utils.SubString(strTitle, 0, 20)
	}
	strTitle = strings.TrimSpace(sanitize.HTML(strTitle))
	if govalidator.IsNull(strTitle) {
		return "", ""
	}
	//－－－－－－正文缩略－－－－－
	//转换成纯文本
	strBody := strings.Replace(input, strs[0], "", -1)
	strBody, err := html2text.Textify(strBody)
	if govalidator.IsNull(strBody) || err != nil {
		return "", ""
	}

	return strTitle, strBody
}
