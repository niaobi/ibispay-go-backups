package controller

import (
	"fmt"
	"github.com/asaskevich/govalidator"
	"github.com/gin-gonic/gin"
	"github.com/ttacon/libphonenumber"
	"golang.org/x/crypto/scrypt"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"log"
	"net/http"
	"os"
	"strings"
	"time"
	"xingdongpai.com/common"
	"xingdongpai.com/config"
	"xingdongpai.com/errs"
	"xingdongpai.com/freecoin"
	"xingdongpai.com/model"
	"xingdongpai.com/utils"
)

const (
	UserMaxAvatar = 5 * 1024 * 1024 //上传头像最大3MB
)

func Profile(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)
	autoRejectlock := c.MustGet("ARDLock").(*model.AutoRejectDealLocks)

	profile := getMyProfile(db, user, autoRejectlock)
	c.JSON(http.StatusOK, profile)

	//更新最后活跃时间
	db.C("user").UpdateId(user.Id, bson.M{"$set": bson.M{"updateAt": time.Now().Unix()}})
	//后台刷新鸟币信用等
	common.RefreshDataInBG(&user)
}

func ProfilePage(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)
	autoRejectlock := c.MustGet("ARDLock").(*model.AutoRejectDealLocks)

	//别人的用户主页
	isMyProfile := true
	if user.Id.Hex() != c.Param("uid") {
		uid := bson.ObjectIdHex(c.Param("uid"))
		err := db.C("user").FindId(uid).One(&user)
		errs.Check400(c, err, errs.E1000)
		isMyProfile = false
	}

	//passion总数
	allPassionNum, _ := db.C("passion").Find(bson.M{"owner": user.Id}).Count()
	//最近3项热情
	passionList := []freecoin.Passion{}
	err := db.C("passion").Find(bson.M{"owner": user.Id}).Select(bson.M{"owner": 1, "md": 1, "title": 1, "desc": 1, "views": 1, "updateAt": 1, "createdAt": 1}).Limit(3).Sort("-updateAt").All(&passionList)
	errs.Check400(c, err, errs.E1000)
	//feed总数
	allFeedNum, _ := db.C("feed").Find(bson.M{"uid": user.Id}).Count()
	//最近3项行动
	feedList := []model.Feed{}
	err = db.C("feed").Find(bson.M{"uid": user.Id}).Limit(3).Sort("-createdAt").All(&feedList)
	errs.Check400(c, err, errs.E1000)

	newFeedList := []gin.H{}
	for _, f := range feedList {
		if f.FeedType == 0 {
			skill := freecoin.Skill{}
			passion := freecoin.Passion{}
			if db.C("skill").FindId(f.SId).One(&skill) != nil {
				continue
			}
			if db.C("passion").FindId(skill.Passion).Select(bson.M{"owner": 1, "md": 1, "title": 1, "desc": 1, "views": 1, "updateAt": 1, "createdAt": 1}).One(&passion) != nil {
				continue
			}
			newFeedList = append(newFeedList, gin.H{"owner": user, "passion": passion, "skill": skill, "feedType": 0})
		} else if f.FeedType == 1 {
			script := model.Script{}
			passion := freecoin.Passion{}
			if db.C("script").FindId(f.SId).One(&script) != nil {
				continue
			}
			if db.C("passion").FindId(script.Passion).Select(bson.M{"owner": 1, "md": 1, "title": 1, "desc": 1, "views": 1, "updateAt": 1, "createdAt": 1}).One(&passion) != nil {
				continue
			}
			newFeedList = append(newFeedList, gin.H{"owner": user, "passion": passion, "script": script, "feedType": 1})
		}
	}

	if isMyProfile {
		//用户信息和消息、检查是否有超时未接受的回流请求
		profile := getMyProfile(db, user, autoRejectlock)

		c.JSON(http.StatusOK, gin.H{"passionList": passionList, "passionNum": allPassionNum, "feedList": newFeedList, "feedNum": allFeedNum, "profile": profile})

		//更新最后活跃时间
		db.C("user").UpdateId(user.Id, bson.M{"$set": bson.M{"updateAt": time.Now().Unix()}})
	} else {
		c.JSON(http.StatusOK, gin.H{"passionList": passionList, "passionNum": allPassionNum, "feedList": newFeedList, "feedNum": allFeedNum})

		//检查是否有超时未接受的回流请求
		goBackNum, _ := db.C("news").Find(bson.M{"toUser": user.Id, "newsType": 101, "needAutoReject": true}).Count()
		if goBackNum > 0 {
			common.AutoRejectDealInBG(&user, autoRejectlock)
		}
	}

	//在后台刷新鸟币信用等
	common.RefreshDataInBG(&user)
}

func Login(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)

	user := new(model.User)
	if c.BindJSON(&user) == nil {
		//处理手机号
		num, err := libphonenumber.Parse(user.Phone, user.PhoneCC)
		errs.Check400(c, err, errs.E1001)
		formattedNum := libphonenumber.Format(num, libphonenumber.E164)
		//获取加密后的密码
		safePwd, err := scrypt.Key([]byte(user.Pwd), []byte(config.PwdSalt), 16384, 8, 1, 32)
		errs.Check400(c, err, errs.E1000)
		strSafePwd := fmt.Sprintf("%x", safePwd)
		//查询用户
		u := new(model.User)
		err = db.C("user").Find(bson.M{"phone": formattedNum}).One(&u)
		errs.Check400(c, err, errs.E1005)
		//检查密码
		if u.Pwd != strSafePwd {
			c.JSON(http.StatusUnauthorized, gin.H{"status": errs.E1006})
			return
		}

		c.JSON(http.StatusOK, u)
	} else {
		c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1010})
	}
}

func Register(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)

	user := new(model.User)
	if c.BindJSON(&user) == nil {
		//排除一些关键字
		if strings.Contains(user.Name, "鸟币") || strings.Contains(user.Name, "鸟神") || strings.Contains(user.Name, "官方") || strings.Contains(user.Name, "系统") || strings.Contains(user.Name, "消息") || strings.Contains(user.Name, "行动派") || strings.Contains(user.Name, "玩剧本") || strings.Contains(user.Name, "赚大钱") || strings.Contains(user.Name, "赚钱") || strings.Contains(user.Name, "热情") {
			c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1011})
			return
		}

		//处理手机号
		num, err := libphonenumber.Parse(user.Phone, user.PhoneCC)
		errs.Check400(c, err, errs.E1001)
		//auth头的手机号格式都为E164 eg.+8618612345678
		formattedNum := libphonenumber.Format(num, libphonenumber.E164)
		user.Phone = formattedNum
		//密码加密
		safePwd, err := scrypt.Key([]byte(user.Pwd), []byte(config.PwdSalt), 16384, 8, 1, 32)
		errs.Check400(c, err, errs.E1000)
		strSafePwd := fmt.Sprintf("%x", safePwd)
		user.Pwd = strSafePwd

		user.Id = bson.NewObjectId()
		user.CreatedAt = time.Now()
		user.Credit = 0.0
		user.Wealth = 0.0
		user.SkillUpdated = false
		user.RmbExr = freecoin.RmbExr
		user.UpdateAt = time.Now().Unix()
		user.Founder = false

		log.Println(user)

		//新建用户，插入数据库
		if err := db.C("user").Insert(user); err != nil {
			if mgo.IsDup(err) {
				c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1002})
			} else {
				c.JSON(http.StatusInternalServerError, gin.H{"status": err.Error()})
			}
		} else {
			//密码不用返回
			user.Pwd = ""
			c.JSON(http.StatusCreated, user)
		}
	} else {
		c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1010})
	}
}

func FinishRegister(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)

	updateProfile(true, db, user, c)
}

func EditProfileWithPhoto(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)

	updateProfile(true, db, user, c)
}
func EditProfileWithOutPhoto(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)

	updateProfile(false, db, user, c)
}

func UpdateEmail(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)
	email := c.Param("email")

	if govalidator.IsEmail(email) == false {
		c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1025})
		return
	}

	err := db.C("user").Update(bson.M{"_id": user.Id}, bson.M{"$set": bson.M{"email": email}})
	errs.Check400(c, err, errs.E1000)

	user.Email = email

	c.JSON(http.StatusOK, user)
}

func UpdatePwd(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)

	form := new(model.PwdUpdateForm)
	if c.BindJSON(&form) != nil {
		c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1000})
		return
	}

	//获取加密后的老密码
	safeOldPwd, err := scrypt.Key([]byte(form.OldPwd), []byte(config.PwdSalt), 16384, 8, 1, 32)
	errs.Check400(c, err, errs.E1000)
	strSafeOldPwd := fmt.Sprintf("%x", safeOldPwd)

	if strSafeOldPwd != user.Pwd {
		//老密码错误
		c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1006})
		return
	}

	if govalidator.IsNull(form.NewPwd) {
		c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1024})
		return
	}

	//获取加密后的新密码
	safePwd, err := scrypt.Key([]byte(form.NewPwd), []byte(config.PwdSalt), 16384, 8, 1, 32)
	errs.Check400(c, err, errs.E1000)
	strSafePwd := fmt.Sprintf("%x", safePwd)

	err = db.C("user").Update(bson.M{"_id": user.Id}, bson.M{"$set": bson.M{"pwd": strSafePwd}})
	errs.Check400(c, err, errs.E1000)

	//密码不用返回
	user.Pwd = ""
	c.JSON(http.StatusOK, user)
}

//更新真人头像
func EditRealPhoto(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)

	oldPhotoId := user.Photo.Largest.PId

	err := c.Request.ParseMultipartForm(UserMaxAvatar)
	errs.Check400(c, err, errs.E1004)
	//接收原图
	pics, err := utils.ReceivePics(c, config.PicDir)
	errs.Check400(c, err, errs.E1007)

	err = db.C("user").Update(bson.M{"_id": user.Id}, bson.M{"$set": bson.M{"photo": pics[0], "hasPhoto": true}})
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"status": err.Error()})
		return
	}

	c.JSON(http.StatusCreated, gin.H{"status": "ok"})

	//生成缩略图、更新数据库、删除老的图片
	go func(pics []utils.Pic, user model.User, oldPhotoId string) {
		session, err := mgo.Dial(config.MgoAddr)
		if err != nil {
			log.Println(err.Error())
			return
		}
		session.SetMode(mgo.Monotonic, true)
		db := session.DB(config.MgoDB)
		defer session.Close()

		newPics, err := utils.ResizePics(pics, config.PicDir, 640, 320, 160)
		if err != nil {
			return
		}
		//更新缩略后的图片对象
		err = db.C("user").Update(bson.M{"_id": user.Id}, bson.M{"$set": bson.M{"photo": newPics[0]}})

		if err == nil && govalidator.IsNull(oldPhotoId) == false {
			//删除老的头像
			largestPicDir := fmt.Sprintf("%s/%s.jpg", config.PicDir, oldPhotoId)
			largePicDir := fmt.Sprintf("%s/%s_%s.jpg", config.PicDir, oldPhotoId, "large")
			middlePicDir := fmt.Sprintf("%s/%s_%s.jpg", config.PicDir, oldPhotoId, "middle")
			thumbnailPicDir := fmt.Sprintf("%s/%s_%s.jpg", config.PicDir, oldPhotoId, "thumbnail")

			os.Remove(largestPicDir)
			os.Remove(largePicDir)
			os.Remove(middlePicDir)
			os.Remove(thumbnailPicDir)
		}
	}(pics, user, oldPhotoId)
}

//=============prvate function============

func getMyProfile(db *mgo.Database, user model.User, autoRecectLock *model.AutoRejectDealLocks) model.MyProfile {
	//汇率
	user.RmbExr = freecoin.RmbExr
	//检查Alias
	if govalidator.IsNull(user.CoinAlias) == true {
		coinT := new(freecoin.CoinT)
		if err := db.C("coinT").Find(bson.M{"creator": user.Id, "superCoin": false}).One(&coinT); err == nil {
			if err := db.C("user").UpdateId(user.Id, bson.M{"$set": bson.M{"coinAlias": coinT.Alias}}); err == nil {
				user.CoinAlias = coinT.Alias
			}
		}
	}
	//检查超级鸟币
	passionNum, err := db.C("passion").Find(bson.M{"owner": user.Id}).Count()
	if passionNum == 0 && err == nil {
		err := db.C("user").Update(bson.M{"_id": user.Id}, bson.M{"$set": bson.M{"superCoinEnabled": false}})
		if err == nil {
			user.SuperCoinEnabled = false
		}
	}
	//检查普通鸟币
	skillNum, err := db.C("skill").Find(bson.M{"owner": user.Id, "inStock": true}).Count()
	if skillNum == 0 && err == nil {
		err := db.C("user").Update(bson.M{"_id": user.Id}, bson.M{"$set": bson.M{"coinEnabled": false}})
		if err == nil {
			user.CoinEnabled = false
		}
	}

	profile := model.MyProfile{}
	profile.User = user
	//检查消息
	if user.HasNews {
		newsNum, _ := db.C("news").Find(bson.M{"toUser": user.Id}).Count()
		profile.UnReadNews = newsNum - user.ReadNews
		if profile.UnReadNews < 0 {
			profile.UnReadNews = 0
		}
	} else {
		profile.UnReadNews = 0
	}
	//获取行动任务数
	todoNum, _ := db.C("news").Find(bson.M{"toUser": user.Id, "newsType": M{"$in": []int{102, 103, 202, 203, 208, 209}}}).Count()
	profile.TaskNum = todoNum

	//检查是否有超时未接受的回流请求
	goBackNum, _ := db.C("news").Find(bson.M{"toUser": user.Id, "newsType": 101, "needAutoReject": true}).Count()
	if goBackNum > 0 {
		common.AutoRejectDealInBG(&user, autoRecectLock)
	}

	return profile
}

func updateProfile(hasAvatar bool, db *mgo.Database, user model.User, c *gin.Context) {
	//接收参数
	userForm := model.UserForm{}
	err := c.Bind(&userForm)
	errs.Check400(c, err, errs.E1010)

	if hasAvatar {
		//＝＝＝＝＝带头像情况＝＝＝＝＝＝
		oldAvatarId := user.Avatar.Largest.PId

		err = c.Request.ParseMultipartForm(UserMaxAvatar)
		errs.Check400(c, err, errs.E1004)
		//接收原图
		pics, err := utils.ReceivePics(c, config.PicDir)
		errs.Check400(c, err, errs.E1007)

		err = db.C("user").Update(bson.M{"_id": user.Id}, bson.M{"$set": bson.M{
			"name":     userForm.Name,
			"sex":      userForm.Sex,
			"bio":      userForm.Bio,
			"city":     userForm.City,
			"lat":      userForm.Lat,
			"lng":      userForm.Lng,
			"birthday": userForm.Birthday,
			"openType": userForm.OpenType,
			"avatar":   pics[0]}})
		if err != nil {
			if mgo.IsDup(err) {
				c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1011})
			} else {
				c.JSON(http.StatusInternalServerError, gin.H{"status": err.Error()})
			}
			return
		}

		c.JSON(http.StatusCreated, gin.H{"status": "ok"})

		//生成缩略图、更新数据库、删除老的图片
		go func(pics []utils.Pic, user model.User, oldAvatarId string) {
			session, err := mgo.Dial(config.MgoAddr)
			if err != nil {
				log.Println(err.Error())
				return
			}
			session.SetMode(mgo.Monotonic, true)
			db := session.DB(config.MgoDB)
			defer session.Close()

			newPics, err := utils.ResizePics(pics, config.PicDir, 640, 320, 160)
			if err != nil {
				return
			}
			//更新缩略后的图片对象
			err = db.C("user").Update(bson.M{"_id": user.Id}, bson.M{"$set": bson.M{"avatar": newPics[0]}})

			if err == nil && govalidator.IsNull(oldAvatarId) == false {
				//删除老的头像
				largestPicDir := fmt.Sprintf("%s/%s.jpg", config.PicDir, oldAvatarId)
				largePicDir := fmt.Sprintf("%s/%s_%s.jpg", config.PicDir, oldAvatarId, "large")
				middlePicDir := fmt.Sprintf("%s/%s_%s.jpg", config.PicDir, oldAvatarId, "middle")
				thumbnailPicDir := fmt.Sprintf("%s/%s_%s.jpg", config.PicDir, oldAvatarId, "thumbnail")

				os.Remove(largestPicDir)
				os.Remove(largePicDir)
				os.Remove(middlePicDir)
				os.Remove(thumbnailPicDir)
			}
		}(pics, user, oldAvatarId)
	} else {
		//＝＝＝＝＝不带头像情况＝＝＝＝＝＝
		err = db.C("user").Update(bson.M{"_id": user.Id}, bson.M{"$set": bson.M{
			"name":     userForm.Name,
			"sex":      userForm.Sex,
			"bio":      userForm.Bio,
			"city":     userForm.City,
			"lat":      userForm.Lat,
			"lng":      userForm.Lng,
			"birthday": userForm.Birthday,
			"openType": userForm.OpenType}})
		if err != nil {
			if mgo.IsDup(err) {
				c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1011})
			} else {
				c.JSON(http.StatusInternalServerError, gin.H{"status": err.Error()})
			}
			return
		}

		c.JSON(http.StatusCreated, gin.H{"status": "ok"})
	}
}

//更换头像的接口
/**
func Avatar(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)

	oldAvatar := user.Avatar
	user.Avatar = utils.Uid()

	if err := c.Request.ParseMultipartForm(MaxAvatar); err != nil {
		errs.Check400(c, err, errs.E1004)
	}

	//update avatar
	err := db.C("user").Update(bson.M{"_id": user.Id}, bson.M{"$set": bson.M{"avatar": user.Avatar}})
	errs.Check400(c, err, errs.E1000)

	c.JSON(http.StatusOK, user)

	c.Next()

	PicDir := fmt.Sprintf("%s/%s", config.PicDir, user.Avatar)
	toPath1 := fmt.Sprintf("%s_%s.jpg", PicDir, Avatar960x960)
	toPath2 := fmt.Sprintf("%s_%s.jpg", PicDir, Avatar750x750)
	toPath3 := fmt.Sprintf("%s_%s.jpg", PicDir, Avatar100x100)

	for _, fileHeaders := range c.Request.MultipartForm.File {
		for _, fileHeader := range fileHeaders {
			// original image
			file, err := fileHeader.Open()
			errs.Check400(c, err, errs.E1000)
			defer file.Close()

			inBuf, err := ioutil.ReadAll(file)
			errs.Check400(c, err, errs.E1000)
			err = ioutil.WriteFile(toPath1, inBuf, os.ModePerm)
			errs.Check400(c, err, errs.E1000)

			// thumbnail 750x750
			options := vips.Options{
				Width:        750,
				Height:       750,
				Crop:         true,
				Extend:       vips.EXTEND_WHITE,
				Interpolator: vips.BILINEAR,
				Gravity:      vips.CENTRE,
				Quality:      100,
			}
			buf, err := vips.Resize(inBuf, options)
			errs.Check400(c, err, errs.E1008)
			ioutil.WriteFile(toPath2, buf, os.ModePerm)
			errs.Check400(c, err, errs.E1008)

			// thumbnail 100x100
			options = vips.Options{
				Width:        100,
				Height:       100,
				Crop:         true,
				Extend:       vips.EXTEND_WHITE,
				Interpolator: vips.BILINEAR,
				Gravity:      vips.CENTRE,
				Quality:      100,
			}
			buf, err = vips.Resize(inBuf, options)
			errs.Check400(c, err, errs.E1008)
			err = ioutil.WriteFile(toPath3, buf, os.ModePerm)
			errs.Check400(c, err, errs.E1008)

			break
		}
	}

	if valid.IsNull(oldAvatar) == false {
		oldPicDir := fmt.Sprintf("%s/%s", config.PicDir, oldAvatar)
		oldPath1 := fmt.Sprintf("%s_%s.jpg", oldPicDir, Avatar960x960)
		oldPath2 := fmt.Sprintf("%s_%s.jpg", oldPicDir, Avatar750x750)
		oldPath3 := fmt.Sprintf("%s_%s.jpg", oldPicDir, Avatar100x100)
		os.Remove(oldPath1)
		os.Remove(oldPath2)
		os.Remove(oldPath3)
	}
}
*/

// type registerDone struct {
// 	Role  string `json:"role" binding:"required"`
// 	Email string `json:"email" binding:"required"`
// }

// func FinishRegister(c *gin.Context) {
// 	db := c.MustGet("db").(*mgo.Database)
// 	user := c.MustGet(gin.AuthUserKey).(model.User)

// 	var param registerDone
// 	if c.BindJSON(&param) == nil {
// 		email := param.Email
// 		role := param.Role

// 		if valid.IsEmail(email) == false {
// 			http.Error(c.Writer, errs.E1009, http.StatusBadRequest)
// 			return
// 		}

// 		err := db.C("user").Update(bson.M{"_id": user.Id}, bson.M{"$set": bson.M{"role": role, "email": email}})
// 		errs.Check400(c, err, errs.E1000)

// 		user.Email = email
// 		user.Role = role

// 		c.JSON(http.StatusOK, user)
// 	} else {
// 		http.Error(c.Writer, errs.E1010, http.StatusBadRequest)
// 	}
// }
