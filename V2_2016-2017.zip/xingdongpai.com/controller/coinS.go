package controller

import (
	"github.com/asaskevich/govalidator"
	"github.com/gin-gonic/gin"
	"github.com/ttacon/libphonenumber"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"gopkg.in/mgo.v2/txn"
	"math"
	"net/http"
	"strconv"
	"strings"
	"time"
	"xingdongpai.com/common"
	"xingdongpai.com/errs"
	"xingdongpai.com/freecoin"
	"xingdongpai.com/model"
)

const (
	CoinTPerPage = 50
	CoinVPerPage = 20
	RLListPage   = 50
)

type M map[string]interface{}

//通过用户名或手机号 转账
func TransferCoin(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)
	lock := c.MustGet("lock").(*freecoin.TransferLocks)

	tf := new(freecoin.TransferForm)
	if c.BindJSON(&tf) == nil {
		isSuperCoin := tf.SuperCoin
		if isSuperCoin == true {
			tf.Count = 1
		} else {
			if govalidator.IsInt(strconv.FormatInt(tf.Count, 10)) == false {
				c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1010})
				return
			}
		}

		//转账方式
		toUser := new(model.User)
		if govalidator.IsNull(tf.ToPhone) == false && govalidator.IsNull(tf.PhoneCC) == false {
			//通过对方手机号转账
			num, err := libphonenumber.Parse(tf.ToPhone, tf.PhoneCC)
			errs.Check400(c, err, errs.E1001)
			formattedNum := libphonenumber.Format(num, libphonenumber.E164)
			if strings.Contains(user.Phone, formattedNum) {
				c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1015})
				return
			}
			err = db.C("user").Find(bson.M{"phone": formattedNum}).Select(bson.M{"_id": 1, "coinAlias": 1, "name": 1}).One(&toUser)
			errs.Check400(c, err, errs.E1005)
		} else {
			//通过对方名称转账
			err := db.C("user").Find(bson.M{"name": tf.ToName}).Select(bson.M{"_id": 1, "coinAlias": 1, "name": 1}).One(&toUser)
			errs.Check400(c, err, errs.E1000)
			if toUser.Name == user.Name {
				c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1015})
				return
			}
		}
		//对方鸟币未激活不转账
		if govalidator.IsNull(toUser.CoinAlias) {
			c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1022})
			return
		}

		//交易锁
		if lock.Locks[user.Id.Hex()] == true || lock.Locks[toUser.Id.Hex()] == true {
			http.Error(c.Writer, errs.E1019, http.StatusBadRequest)
			return
		}
		lock.Locks[user.Id.Hex()] = true
		lock.Locks[toUser.Id.Hex()] = true
		defer func() {
			delete(lock.Locks, user.Id.Hex())
			delete(lock.Locks, toUser.Id.Hex())
		}()

		//转账方的消息提示
		news := model.News{}
		news.Id = bson.NewObjectId()
		news.DId = bson.NewObjectId()
		news.ToUser = user.Id
		strCount := strconv.FormatInt(tf.Count, 10)
		if tf.SuperCoin {
			news.Msg = "已成功转账给[" + toUser.Name + "]" + strCount + "个 超级" + tf.CoinName + "币"
		} else {
			news.Msg = "已成功转账给[" + toUser.Name + "]" + strCount + "个 " + tf.CoinName + "币"
		}
		if govalidator.IsNull(tf.Note) == false {
			news.Msg = news.Msg + ". 转账备注:" + tf.Note
		}
		news.NewsType = 0
		news.UpdateAt = time.Now().Unix()
		news.CreatedAt = time.Now()
		//收款方的消息提示
		news2 := model.News{}
		news2.Id = bson.NewObjectId()
		news2.DId = bson.NewObjectId()
		news2.ToUser = toUser.Id
		if tf.SuperCoin {
			news2.Msg = "收到 " + strCount + "个 超级" + tf.CoinName + "币,来自于[" + user.Name + "]的转账"
		} else {
			news2.Msg = "收到 " + strCount + "个 " + tf.CoinName + "币,来自于[" + user.Name + "]的转账"
		}
		if govalidator.IsNull(tf.Note) == false {
			news2.Msg = news2.Msg + ". 转账备注:" + tf.Note
		}
		news2.NewsType = 0
		news2.UpdateAt = time.Now().Unix()
		news2.CreatedAt = time.Now()

		//====================转账相关=======================
		//鸟币类型
		coinType := new(freecoin.CoinT)
		err := db.C("coinT").Find(bson.M{"alias": tf.CoinName, "superCoin": tf.SuperCoin}).One(&coinType)
		errs.Check400(c, err, errs.E1000)
		//鸟币发行者
		coinCreator := new(model.User)
		err = db.C("user").FindId(coinType.Creator).Select(bson.M{"_id": 1, "skillUpdated": 1}).One(&coinCreator)
		errs.Check400(c, err, errs.E1000)
		//转账流水transferLog
		ctLog := new(freecoin.CoinTransferLog)
		ctLog.Id = bson.NewObjectId()
		ctLog.FromUser = user.Id
		ctLog.ToUser = toUser.Id
		ctLog.Tally = tf.Count
		ctLog.CoinT = coinType
		ctLog.CoinGoBack = false
		ctLog.Note = tf.Note
		ctLog.CreatedAt = time.Now()

		//============coinTT=============
		//收款人拥有的此类型鸟币总数
		coinTTNum, err := db.C("coinTT").Find(bson.M{"coinT._id": coinType.Id, "owner": toUser.Id}).Count()
		errs.Check400(c, err, errs.E1000)
		coinTT := new(freecoin.CoinTTally)
		if coinTTNum == 0 {
			coinTT.Id = bson.NewObjectId()
			coinTT.Owner = toUser.Id
			coinTT.CoinType = coinType
			coinTT.Tally = tf.Count
		} else {
			err := db.C("coinTT").Find(bson.M{"coinT._id": coinType.Id, "owner": toUser.Id}).One(&coinTT)
			errs.Check400(c, err, errs.E1000)
		}
		//转账者支出的此类型鸟币总数
		coinTTNum2, err := db.C("coinTT").Find(bson.M{"coinT._id": coinType.Id, "owner": user.Id}).Count()
		errs.Check400(c, err, errs.E1000)
		coinTT2 := new(freecoin.CoinTTally)
		if coinTTNum2 == 0 {
			coinTT2.Id = bson.NewObjectId()
			coinTT2.Owner = user.Id
			coinTT2.CoinType = coinType
			coinTT2.Tally = -tf.Count
		} else {
			err := db.C("coinTT").Find(bson.M{"coinT._id": coinType.Id, "owner": user.Id}).One(&coinTT2)
			errs.Check400(c, err, errs.E1000)
		}
		ops := []txn.Op{}
		//收款人
		if coinTTNum == 0 {
			ops = append(ops, txn.Op{C: "coinTT", Id: coinTT.Id, Insert: coinTT})
		} else {
			ops = append(ops, txn.Op{C: "coinTT", Id: coinTT.Id, Update: M{"$inc": M{"tally": tf.Count}}})
		}
		//转账者
		if coinTTNum2 == 0 {
			ops = append(ops, txn.Op{C: "coinTT", Id: coinTT2.Id, Insert: coinTT2})
		} else {
			ops = append(ops, txn.Op{C: "coinTT", Id: coinTT2.Id, Update: M{"$inc": M{"tally": -tf.Count}}})
		}
		//============coinTT=============

		//情况1.转账者使用自己发行的鸟币
		//情况2.转账者使用收款人方发行的鸟币(即鸟币回流)
		//情况3.转账者使用第三方发行的鸟币
		userIsCreator := false
		coinGoBack := false
		otherCreator := false
		if user.CoinAlias == tf.CoinName {
			//判断是否买家自己发行
			userIsCreator = true //情况1
		} else {
			//判断是否是鸟币回流
			if coinType.Creator == toUser.Id {
				coinGoBack = true //情况2
			} else {
				otherCreator = true //情况3
			}
		}
		//-------------不同情况不同的转账过程-------------
		if userIsCreator == true {
			//技能id列表
			skillList := []freecoin.Skill{}
			if isSuperCoin {
				err = db.C("skill").Find(bson.M{"owner": coinType.Creator, "inStock": true, "price": 0}).Select(bson.M{"_id": 1}).Sort("-createdAt").All(&skillList)
				errs.Check400(c, err, errs.E1000)
			} else {
				err = db.C("skill").Find(bson.M{"owner": coinType.Creator, "inStock": true, "price": M{"$gt": 0}}).Select(bson.M{"_id": 1}).Sort("-createdAt").All(&skillList)
				errs.Check400(c, err, errs.E1000)
			}
			skillIdList := []bson.ObjectId{}
			for _, s := range skillList {
				skillIdList = append(skillIdList, s.Id)
			}
			//发行次数
			coinVNum, err := db.C("coinV").Find(bson.M{"ctid": coinType.Id}).Count()
			errs.Check400(c, err, errs.E1000)
			//获取最后一个发行版本
			coinVisionArray := []freecoin.CoinV{}
			if coinVNum > 0 {
				err = db.C("coinV").Find(bson.M{"ctid": coinType.Id}).Limit(1).Sort("-createdAt").All(&coinVisionArray)
				errs.Check400(c, err, errs.E1000)
			}
			//发行(转账或交易)鸟币时，若技能有改动，则版本号+1
			if coinCreator.SkillUpdated == true || coinVNum == 0 {
				//版本＋1
				sids := new(freecoin.SkillIds)
				sids.Id = bson.NewObjectId()
				sids.List = skillIdList
				sids.CreatedAt = time.Now()

				coinVision := freecoin.CoinV{}
				coinVision.Id = bson.NewObjectId()
				coinVision.CoinTId = coinType.Id
				coinVision.CreatedAt = time.Now()
				coinVision.SkillIdList = sids.Id
				if coinVNum == 0 {
					coinVision.Vision = 1
				} else {
					coinVision.Vision = coinVisionArray[0].Vision + 1
				}

				//收款人收入明细
				coinState := new(freecoin.CoinS)
				coinState.Id = bson.NewObjectId()
				coinState.User = toUser.Id
				coinState.CoinTLId = ctLog.Id
				coinState.CoinVId = coinVision.Id
				coinState.CoinT = coinType
				coinState.Count = tf.Count
				coinState.CreatedAt = time.Now()
				//转账者支出明细
				coinState2 := new(freecoin.CoinS)
				coinState2.Id = bson.NewObjectId()
				coinState2.User = user.Id
				coinState2.CoinTLId = ctLog.Id
				coinState2.CoinVId = coinVision.Id
				coinState2.CoinT = coinType
				coinState2.Count = -tf.Count
				coinState2.CreatedAt = time.Now()

				//收款人拥有的同一个版本的鸟币总数
				coinVT := new(freecoin.CoinVTally)
				coinVT.Id = bson.NewObjectId()
				coinVT.Owner = toUser.Id
				coinVT.CoinV = coinVision
				coinVT.Tally = tf.Count
				//转账者支出的同一个版本的鸟币总数
				coinVT2 := new(freecoin.CoinVTally)
				coinVT2.Id = bson.NewObjectId()
				coinVT2.Owner = user.Id
				coinVT2.CoinV = coinVision
				coinVT2.Tally = -tf.Count

				ops = append(ops,
					//＝＝＝转账＝＝＝
					txn.Op{C: "skillIds", Id: sids.Id, Insert: sids},
					txn.Op{C: "coinV", Id: coinVision.Id, Insert: coinVision},
					txn.Op{C: "coinS", Id: coinState.Id, Insert: coinState},
					txn.Op{C: "coinS", Id: coinState2.Id, Insert: coinState2},
					txn.Op{C: "coinTL", Id: ctLog.Id, Insert: ctLog},
					txn.Op{C: "user", Id: coinCreator.Id, Update: M{"$set": M{"skillUpdated": false}}},
					txn.Op{C: "coinVT", Id: coinVT.Id, Insert: coinVT},
					txn.Op{C: "coinVT", Id: coinVT2.Id, Insert: coinVT2},
					//＝＝＝更新消息等＝＝＝
					txn.Op{C: "news", Id: news.Id, Insert: news},
					txn.Op{C: "news", Id: news2.Id, Insert: news2},
					txn.Op{C: "user", Id: user.Id, Update: M{"$set": M{"hasNews": true}}},
					txn.Op{C: "user", Id: toUser.Id, Update: M{"$set": M{"hasNews": true}}})

				runner := txn.NewRunner(db.C("txns"))
				id := bson.NewObjectId()
				err = runner.Run(ops, id, nil)
				errs.Check400(c, err, errs.E1000)
			} else {
				//版本未变
				//技能列表和上一次发行时一样
				coinState := new(freecoin.CoinS)
				coinState.Id = bson.NewObjectId()
				coinState.User = toUser.Id
				coinState.CoinTLId = ctLog.Id
				coinState.CoinVId = coinVisionArray[0].Id
				coinState.CoinT = coinType
				coinState.Count = tf.Count
				coinState.CreatedAt = time.Now()

				coinState2 := new(freecoin.CoinS)
				coinState2.Id = bson.NewObjectId()
				coinState2.User = user.Id
				coinState2.CoinTLId = ctLog.Id
				coinState2.CoinVId = coinVisionArray[0].Id
				coinState2.CoinT = coinType
				coinState2.Count = -tf.Count
				coinState2.CreatedAt = time.Now()

				//收款人拥有的同一个版本的鸟币总数
				coinVTNum, err := db.C("coinVT").Find(bson.M{"coinV._id": coinVisionArray[0].Id, "owner": toUser.Id}).Count()
				errs.Check400(c, err, errs.E1000)
				coinVT := new(freecoin.CoinVTally)
				if coinVTNum == 0 {
					coinVT.Id = bson.NewObjectId()
					coinVT.Owner = toUser.Id
					coinVT.CoinV = coinVisionArray[0]
					coinVT.Tally = tf.Count
				} else {
					err := db.C("coinVT").Find(bson.M{"coinV._id": coinVisionArray[0].Id, "owner": toUser.Id}).One(&coinVT)
					errs.Check400(c, err, errs.E1000)
				}
				//收款人
				if coinVTNum == 0 {
					ops = append(ops, txn.Op{C: "coinVT", Id: coinVT.Id, Insert: coinVT})
				} else {
					ops = append(ops, txn.Op{C: "coinVT", Id: coinVT.Id, Update: M{"$inc": M{"tally": tf.Count}}})
				}
				//转账者支出的同一个版本的鸟币总数
				coinVT2 := new(freecoin.CoinVTally)
				err = db.C("coinVT").Find(bson.M{"coinV._id": coinVisionArray[0].Id, "owner": user.Id}).One(&coinVT2)
				errs.Check400(c, err, errs.E1000)
				//转账者
				ops = append(ops, txn.Op{C: "coinVT", Id: coinVT2.Id, Update: M{"$inc": M{"tally": -tf.Count}}})

				ops = append(ops,
					//＝＝＝转账＝＝＝
					txn.Op{C: "coinV", Id: coinVisionArray[0].Id, Update: M{"$inc": M{"tally": tf.Count}}},
					txn.Op{C: "coinS", Id: coinState.Id, Insert: coinState},
					txn.Op{C: "coinS", Id: coinState2.Id, Insert: coinState2},
					txn.Op{C: "coinTL", Id: ctLog.Id, Insert: ctLog},
					txn.Op{C: "user", Id: coinCreator.Id, Update: M{"$set": M{"skillUpdated": false}}},
					//＝＝＝更新消息等＝＝＝
					txn.Op{C: "news", Id: news.Id, Insert: news},
					txn.Op{C: "news", Id: news2.Id, Insert: news2},
					txn.Op{C: "user", Id: user.Id, Update: M{"$set": M{"hasNews": true}}},
					txn.Op{C: "user", Id: toUser.Id, Update: M{"$set": M{"hasNews": true}}})

				runner := txn.NewRunner(db.C("txns"))
				id := bson.NewObjectId()
				err = runner.Run(ops, id, nil)
				errs.Check400(c, err, errs.E1000)
			}
		} else if coinGoBack == true || otherCreator == true {
			//检查鸟币是否足够
			userCoinTTally := freecoin.CoinTTally{}
			err = db.C("coinTT").Find(M{"owner": user.Id, "coinT._id": coinType.Id}).One(&userCoinTTally)
			errs.Check400(c, err, errs.E1000)
			if userCoinTTally.Tally < tf.Count {
				//鸟币数量不够
				c.JSON(http.StatusBadRequest, gin.H{"status": errs.E1018})
				return
			}

			//转账者拥有的此鸟币的全部版本(tally大于0)，按照倒序使用鸟币版本
			coinVTs := []freecoin.CoinVTally{}
			err = db.C("coinVT").Find(M{"owner": user.Id, "coinV.ctid": coinType.Id, "tally": M{"$gt": 0}}).Sort("-coinV.vision").All(&coinVTs)
			errs.Check400(c, err, errs.E1000)

			leftTransfer := tf.Count
			for i := 0; i < len(coinVTs); i++ {
				var userCountChange int64
				var toUserCountChange int64
				breakNow := false
				if coinVTs[i].Tally < leftTransfer {
					leftTransfer = leftTransfer - coinVTs[i].Tally
					userCountChange = -coinVTs[i].Tally
					toUserCountChange = coinVTs[i].Tally
				} else {
					userCountChange = -leftTransfer
					toUserCountChange = leftTransfer
					breakNow = true
				}

				//--------coinState------------
				coinState := new(freecoin.CoinS)
				coinState.Id = bson.NewObjectId()
				coinState.User = user.Id
				coinState.CoinTLId = ctLog.Id
				coinState.CoinVId = coinVTs[i].CoinV.Id
				coinState.CoinT = coinType
				coinState.Count = userCountChange
				coinState.CreatedAt = time.Now()

				coinState2 := new(freecoin.CoinS)
				coinState2.Id = bson.NewObjectId()
				coinState2.User = toUser.Id
				coinState2.CoinTLId = ctLog.Id
				coinState2.CoinVId = coinVTs[i].CoinV.Id
				coinState2.CoinT = coinType
				coinState2.Count = toUserCountChange
				coinState2.CreatedAt = time.Now()

				ops = append(ops,
					//＝＝＝转账相关＝＝＝
					txn.Op{C: "coinS", Id: coinState.Id, Insert: coinState},
					txn.Op{C: "coinS", Id: coinState2.Id, Insert: coinState2})

				cv := freecoin.CoinV{}
				err = db.C("coinV").FindId(coinVTs[i].CoinV.Id).One(&cv)
				if err != nil {
					errs.Check400(c, err, errs.E1000)
					break
				}

				//--------coinVT------------
				//收款人拥有的同一个版本的鸟币总数
				coinVTNum, err := db.C("coinVT").Find(bson.M{"coinV._id": coinVTs[i].CoinV.Id, "owner": toUser.Id}).Count()
				errs.Check400(c, err, errs.E1000)
				coinVT := new(freecoin.CoinVTally)
				if coinVTNum == 0 {
					coinVT.Id = bson.NewObjectId()
					coinVT.Owner = toUser.Id
					coinVT.CoinV = cv
					coinVT.Tally = toUserCountChange
				} else {
					err := db.C("coinVT").Find(bson.M{"coinV._id": coinVTs[i].CoinV.Id, "owner": toUser.Id}).One(&coinVT)
					errs.Check400(c, err, errs.E1000)
				}
				//转账者支出的同一个版本的鸟币总数
				coinVTNum2, err := db.C("coinVT").Find(bson.M{"coinV._id": coinVTs[i].CoinV.Id, "owner": user.Id}).Count()
				errs.Check400(c, err, errs.E1000)
				coinVT2 := new(freecoin.CoinVTally)
				if coinVTNum2 == 0 {
					coinVT2.Id = bson.NewObjectId()
					coinVT2.Owner = user.Id
					coinVT2.CoinV = cv
					coinVT2.Tally = userCountChange
				} else {
					err := db.C("coinVT").Find(bson.M{"coinV._id": coinVTs[i].CoinV.Id, "owner": user.Id}).One(&coinVT2)
					errs.Check400(c, err, errs.E1000)
				}
				//收款人
				if coinVTNum == 0 {
					ops = append(ops, txn.Op{C: "coinVT", Id: coinVT.Id, Insert: coinVT})
				} else {
					ops = append(ops, txn.Op{C: "coinVT", Id: coinVT.Id, Update: M{"$inc": M{"tally": toUserCountChange}}})
				}
				//转账者
				if coinVTNum2 == 0 {
					ops = append(ops, txn.Op{C: "coinVT", Id: coinVT2.Id, Insert: coinVT2})
				} else {
					ops = append(ops, txn.Op{C: "coinVT", Id: coinVT2.Id, Update: M{"$inc": M{"tally": userCountChange}}})
				}

				if breakNow {
					break
				}
			}

			if coinGoBack == true {
				ctLog.CoinGoBack = true
				if tf.SuperCoin {
					news2.Msg = "回收了 " + strCount + "个 超级" + tf.CoinName + "币,来自于[" + user.Name + "]的转账"
				} else {
					news2.Msg = "回收了 " + strCount + "个 " + tf.CoinName + "币,来自于[" + user.Name + "]的转账"
				}
				if govalidator.IsNull(tf.Note) == false {
					news2.Msg = news2.Msg + ". 转账备注:" + tf.Note
				}
			}
			ops = append(ops,
				//＝＝＝转账相关＝＝＝
				txn.Op{C: "coinTL", Id: ctLog.Id, Insert: ctLog},
				//＝＝＝更新消息等＝＝＝
				txn.Op{C: "news", Id: news.Id, Insert: news},
				txn.Op{C: "news", Id: news2.Id, Insert: news2},
				txn.Op{C: "user", Id: user.Id, Update: M{"$set": M{"hasNews": true}}},
				txn.Op{C: "user", Id: toUser.Id, Update: M{"$set": M{"hasNews": true}}})

			runner := txn.NewRunner(db.C("txns"))
			id := bson.NewObjectId()
			err = runner.Run(ops, id, nil)
			errs.Check400(c, err, errs.E1000)
		}
	}
	c.JSON(http.StatusCreated, gin.H{"status": "ok"})
}

func CoinDetail(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)
	superCoin, _ := strconv.Atoi(c.Param("super"))

	isSuper := false
	if superCoin == 1 {
		isSuper = true
	}
	//使用的鸟币类型
	coinType := freecoin.CoinT{}
	err := db.C("coinT").Find(bson.M{"creator": user.Id, "superCoin": isSuper}).One(&coinType)
	errs.Check400(c, err, errs.E1000)

	//我发行的鸟币数量
	myCoinTT := freecoin.CoinTTally{}
	myCoinTTR := freecoin.CoinTTReturn{}
	err = db.C("coinTT").Find(M{"owner": user.Id, "coinT._id": coinType.Id}).One(&myCoinTT)
	if err != nil {
		if err == mgo.ErrNotFound {
			myCoinTTR.Tally = 0
		} else {
			errs.Check400(c, err, errs.E1000)
		}
	} else {
		myCoinTTR.Tally = myCoinTT.Tally
	}

	//我赚到的鸟币数量
	m1 := bson.M{"$match": bson.M{"owner": user.Id}}
	m2 := bson.M{"$match": bson.M{"coinT._id": M{"$ne": coinType.Id}}}
	m3 := bson.M{"$match": bson.M{"coinT.superCoin": isSuper}}
	m4 := bson.M{"$group": bson.M{"_id": 0, "tally": bson.M{"$sum": "$tally"}}}
	operations := []bson.M{m1, m2, m3, m4}
	coinTTR := freecoin.CoinTTReturn{}
	err = db.C("coinTT").Pipe(operations).One(&coinTTR)
	if err != nil {
		if err == mgo.ErrNotFound {
			coinTTR.Tally = 0
		} else {
			errs.Check400(c, err, errs.E1000)
		}
	}

	//我的交易次数
	tNum, err := db.C("coinTL").Find(bson.M{"$or": []bson.M{bson.M{"fromUser": user.Id}, bson.M{"toUser": user.Id}}}).Count()
	if err != nil {
		if err == mgo.ErrNotFound {
			tNum = 0
		} else {
			errs.Check400(c, err, errs.E1000)
		}
	}

	//我拒绝回收的次数
	rNum, err := db.C("coinRL").Find(M{"coinT._id": coinType.Id, "toUser": user.Id, "accpet": false}).Count()
	if err != nil {
		if err == mgo.ErrNotFound {
			rNum = 0
		} else {
			errs.Check400(c, err, errs.E1000)
		}
	}

	coinDR := freecoin.MyCoinDetailReturn{}
	coinDR.MyCoinCount = int64(math.Abs(float64(myCoinTTR.Tally)))
	coinDR.EarnedCoinCount = coinTTR.Tally
	coinDR.TransferNum = int64(tNum)
	coinDR.RejectNum = int64(rNum)
	c.JSON(http.StatusOK, coinDR)

	common.RefreshDataInBG(&user)
}

//拥有的所有种类的鸟币
func CoinTypeEarned(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)
	superCoin, _ := strconv.Atoi(c.Param("super"))
	skip, _ := strconv.Atoi(c.Param("skip"))

	isSuper := false
	if superCoin == 1 {
		isSuper = true
	}

	//我发行的鸟币
	coinType := freecoin.CoinT{}
	err := db.C("coinT").Find(bson.M{"creator": user.Id, "superCoin": isSuper}).One(&coinType)
	errs.Check400(c, err, errs.E1000)
	myCoinTT := freecoin.CoinTTally{}
	myCoinReturn := freecoin.CoinTTReturn{}
	err = db.C("coinTT").Find(M{"owner": user.Id, "coinT._id": coinType.Id}).One(&myCoinTT)
	if err != nil {
		if err == mgo.ErrNotFound {
			myCoinReturn.Tally = 0
		} else {
			errs.Check400(c, err, errs.E1000)
		}
	} else {
		myCoinReturn.Tally = myCoinTT.Tally
	}
	//我赚到的所有鸟币
	coinTT := []freecoin.CoinTTally{}
	err = db.C("coinTT").Find(M{"owner": user.Id}).Skip(skip).Limit(CoinTPerPage).Sort("-tally").All(&coinTT)
	errs.Check400(c, err, errs.E1000)
	returnList := []freecoin.CoinTTallyReturn{}
	for _, cte := range coinTT {
		ct := freecoin.CoinT{}
		err := db.C("coinT").FindId(cte.CoinType.Id).One(&ct)
		if err != nil {
			continue
		}
		if ct.Creator == user.Id && ct.SuperCoin == isSuper {
			//自己的鸟币
			continue
		}
		if cte.Tally == 0 {
			continue
		}
		owner := model.User{}
		err = db.C("user").FindId(ct.Creator).One(&owner)
		if err != nil {
			continue
		}
		cter := freecoin.CoinTTallyReturn{}
		cter.CoinType = ct
		cter.Id = cte.Id
		cter.Owner = owner
		cter.Tally = cte.Tally
		returnList = append(returnList, cter)
	}

	returnSkip := skip + CoinTPerPage
	if len(returnList) < CoinTPerPage {
		returnSkip = -1
	}

	c.JSON(http.StatusOK, gin.H{"myCoin": myCoinReturn, "list": returnList, "skip": returnSkip})
}

//一个类型的鸟币下，拥有的所有版本
func CoinAllVision(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	superCoin, _ := strconv.Atoi(c.Param("super"))
	skip, _ := strconv.Atoi(c.Param("skip"))
	coinName := c.Param("coinName")

	isSuper := false
	if superCoin == 1 {
		isSuper = true
	}

	coinType := freecoin.CoinT{}
	err := db.C("coinT").Find(M{"alias": coinName, "superCoin": isSuper}).One(&coinType)
	errs.Check400(c, err, errs.E1000)

	coinVisionList := []freecoin.CoinV{}
	err = db.C("coinV").Find(M{"ctid": coinType.Id}).Skip(skip).Limit(CoinVPerPage).Sort("-vision").All(&coinVisionList)
	errs.Check400(c, err, errs.E1000)

	returnList := []gin.H{}
	for _, cv := range coinVisionList {
		coinVT := freecoin.CoinVTally{}
		err := db.C("coinVT").Find(M{"owner": coinType.Creator, "coinV._id": cv.Id}).One(&coinVT)
		sidl := freecoin.SkillIds{}
		err = db.C("skillIds").FindId(coinVT.CoinV.SkillIdList).One(&sidl)
		if err != nil {
			continue
		}
		returnList = append(returnList, gin.H{"skillNum": len(sidl.List), "coinVT": coinVT})
	}

	returnSkip := skip + CoinVPerPage
	if len(coinVisionList) < CoinVPerPage {
		returnSkip = -1
	}

	c.JSON(http.StatusOK, gin.H{"list": returnList, "skip": returnSkip})
}

//我拒绝回收的鸟币列表
func CoinGoBackRejectedList(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)
	skip, _ := strconv.Atoi(c.Param("skip"))

	rejectedList := []freecoin.CoinGoBackRejectLog{}
	err := db.C("coinRL").Find(M{"toUser": user.Id, "accpet": false}).Skip(skip).Limit(RLListPage).Sort("-createdAt").All(&rejectedList)
	errs.Check400(c, err, errs.E1000)

	newList := []gin.H{}
	for _, n := range rejectedList {
		deal := freecoin.Deal{}
		if db.C("deal").FindId(n.DealId).One(&deal) != nil {
			continue
		}
		skill := freecoin.Skill{}
		if db.C("skill").FindId(deal.SkillId).One(&skill) != nil {
			continue
		}
		buyer := model.User{}
		if db.C("user").FindId(deal.Buyer).Select(bson.M{"avatar": 1, "name": 1, "wealth": 1, "credit": 1, "coinAlias": 1, "hasPhoto": 1, "city": 1, "lat": 1, "lng": 1, "openType": 1, "bio": 1, "phone": 1, "phoneCC": 1}).One(&buyer) != nil {
			continue
		}

		seller := model.User{}
		if db.C("user").FindId(deal.Seller).Select(bson.M{"avatar": 1, "name": 1, "wealth": 1, "credit": 1, "coinAlias": 1, "hasPhoto": 1, "city": 1, "lat": 1, "lng": 1, "openType": 1, "bio": 1, "phone": 1, "phoneCC": 1}).One(&seller) != nil {
			continue
		}

		news := model.News{}
		if db.C("news").Find(M{"toUser": user.Id, "newsType": 105, "did": deal.Id}).One(&news) != nil {
			continue
		}

		newList = append(newList, gin.H{"coinRL": n, "deal": deal, "skill": skill, "buyer": buyer, "seller": seller, "news": news})
	}

	returnSkip := skip + RLListPage
	if len(newList) < RLListPage {
		returnSkip = -1
	}

	c.JSON(http.StatusOK, gin.H{"list": newList, "skip": returnSkip})
}
