package controller

import (
	"gopkg.in/mgo.v2/txn"
	"log"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"xingdongpai.com/config"
	"xingdongpai.com/errs"
	"xingdongpai.com/freecoin"
	"xingdongpai.com/model"
	"xingdongpai.com/utils"
)

const (
	skillPerPage = 25
	skillMaxPics = 25 * 1024 * 1024 //上传9张图最大15MB
)

func UpdateSkill(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)
	sid := bson.ObjectIdHex(c.Param("sid"))

	ss := freecoin.SkillForm{}
	if c.Bind(&ss) == nil {
		oldSkill := freecoin.Skill{}
		err := db.C("skill").FindId(sid).One(&oldSkill)
		errs.Check400(c, err, errs.E1000)

		feed := model.Feed{}
		err = db.C("feed").Find(bson.M{"sid": oldSkill.Id}).One(&feed)
		errs.Check400(c, err, errs.E1000)

		//新建skill
		skill := freecoin.Skill{}
		skill.Id = bson.NewObjectId()
		skill.Owner = user.Id
		skill.GroupId = oldSkill.GroupId
		skill.Passion = bson.ObjectIdHex(ss.Passion)
		skill.Title = ss.Title
		skill.Desc = ss.Desc
		skill.Pics = oldSkill.Pics
		skill.Price = ss.Price
		skill.Unit = ss.Unit
		skill.Tag = ss.Tag
		skill.Category = ss.Category
		skill.CanCome = ss.CanCome
		skill.CanGo = ss.CanGo
		skill.CanCafe = ss.CanCafe
		skill.CanOnline = ss.CanOnline
		skill.ComeNote = ss.ComeNote
		skill.GoNote = ss.GoNote
		skill.CafeNote = ss.CafeNote
		skill.OnlineNote = ss.OnlineNote
		skill.Likes = oldSkill.Likes
		skill.InStock = true
		skill.IsSnap = true
		skill.UpdateAt = time.Now().Unix()
		skill.CreatedAt = oldSkill.CreatedAt

		ops := []txn.Op{}
		ops = append(ops,
			txn.Op{C: "skill", Id: oldSkill.Id, Update: M{"$set": M{"inStock": false}}},
			txn.Op{C: "skill", Id: skill.Id, Insert: skill},
			txn.Op{C: "feed", Id: feed.Id, Update: M{"$set": M{"sid": skill.Id}}})

		runner := txn.NewRunner(db.C("txns"))
		id := bson.NewObjectId()
		err = runner.Run(ops, id, nil)
		errs.Check400(c, err, errs.E1000)

		c.JSON(http.StatusCreated, skill)
	}
}

func NewSkill(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)

	ss := freecoin.SkillForm{}
	if c.Bind(&ss) == nil {
		skill := freecoin.Skill{}
		skill.Id = bson.NewObjectId()
		skill.GroupId = bson.NewObjectId()
		skill.Owner = user.Id
		skill.InStock = true
		skill.IsSnap = false
		skill.UpdateAt = time.Now().Unix()
		skill.CreatedAt = time.Now()

		skill.Passion = bson.ObjectIdHex(ss.Passion)
		skill.Title = ss.Title
		skill.Desc = ss.Desc
		skill.Price = ss.Price
		skill.Unit = ss.Unit
		skill.Tag = ss.Tag
		skill.Category = ss.Category
		skill.CanCome = ss.CanCome
		skill.CanGo = ss.CanGo
		skill.CanCafe = ss.CanCafe
		skill.CanOnline = ss.CanOnline
		skill.ComeNote = ss.ComeNote
		skill.GoNote = ss.GoNote
		skill.CafeNote = ss.CafeNote
		skill.OnlineNote = ss.OnlineNote

		log.Println(skill)

		//新建技能，插入数据库
		err := db.C("skill").Insert(skill)
		errs.Check400(c, err, errs.E1000)

		//激活鸟币
		if user.CoinEnabled == false {
			db.C("user").UpsertId(user.Id, bson.M{"$set": bson.M{"coinEnabled": true}})
		}

		if user.SkillUpdated == false {
			db.C("user").UpsertId(user.Id, bson.M{"$set": bson.M{"skillUpdated": true}})
		}

		c.JSON(http.StatusCreated, skill)

		go func(skill freecoin.Skill, user model.User) {
			session, err := mgo.Dial(config.MgoAddr)
			if err != nil {
				log.Println(err.Error())
				return
			}
			session.SetMode(mgo.Monotonic, true)
			db := session.DB(config.MgoDB)
			defer session.Close()

			//插入feed
			feed := model.Feed{}
			feed.Id = bson.NewObjectId()
			feed.Uid = user.Id
			feed.SId = skill.Id
			feed.FeedType = 0
			feed.CreatedAt = skill.CreatedAt
			err = db.C("feed").Insert(feed)
			if err != nil {
				log.Println(errs.E1012)
			}
		}(skill, user)

	} else {
		log.Println(errs.E1010)
		http.Error(c.Writer, errs.E1010, http.StatusBadRequest)
	}
}

func NewSkillPics(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	user := c.MustGet(gin.AuthUserKey).(model.User)

	err := c.Request.ParseMultipartForm(skillMaxPics)
	errs.Check400(c, err, errs.E1004)

	//接收参数
	ss := freecoin.SkillForm{}
	err = c.Bind(&ss)
	errs.Check400(c, err, errs.E1010)
	//接收图片
	pics, err := utils.ReceivePics(c, config.PicDir)
	errs.Check400(c, err, errs.E1007)

	skill := freecoin.Skill{}
	skill.Id = bson.NewObjectId()
	skill.GroupId = bson.NewObjectId()
	skill.Owner = user.Id
	skill.InStock = true
	skill.IsSnap = false
	skill.UpdateAt = time.Now().Unix()
	skill.CreatedAt = time.Now()

	skill.Passion = bson.ObjectIdHex(ss.Passion)
	skill.Title = ss.Title
	skill.Desc = ss.Desc
	skill.Price = ss.Price
	skill.Unit = ss.Unit
	skill.Tag = ss.Tag
	skill.Category = ss.Category
	skill.CanCome = ss.CanCome
	skill.CanGo = ss.CanGo
	skill.CanCafe = ss.CanCafe
	skill.CanOnline = ss.CanOnline
	skill.ComeNote = ss.ComeNote
	skill.GoNote = ss.GoNote
	skill.CafeNote = ss.CafeNote
	skill.OnlineNote = ss.OnlineNote
	skill.Pics = pics

	//新建技能，插入数据库
	err = db.C("skill").Insert(skill)
	errs.Check400(c, err, errs.E1000)

	//激活鸟币
	if user.CoinEnabled == false {
		db.C("user").UpsertId(user.Id, bson.M{"$set": bson.M{"coinEnabled": true}})
	}

	if user.SkillUpdated == false {
		db.C("user").UpsertId(user.Id, bson.M{"$set": bson.M{"skillUpdated": true}})
	}

	c.JSON(http.StatusCreated, skill)

	//后台继续执行
	go func(pics []utils.Pic, skill freecoin.Skill, user model.User) {
		session, err := mgo.Dial(config.MgoAddr)
		if err != nil {
			log.Println(err.Error())
			return
		}
		session.SetMode(mgo.Monotonic, true)
		db := session.DB(config.MgoDB)
		defer session.Close()

		//生成缩略图
		newPics, err := utils.ResizePics(pics, config.PicDir, 1334, 1136, 320)
		if err == nil {
			//更新图片对象
			db.C("skill").Update(bson.M{"_id": skill.Id}, bson.M{"$set": bson.M{"pics": newPics}})
		}

		//插入feed
		feed := model.Feed{}
		feed.Id = bson.NewObjectId()
		feed.Uid = user.Id
		feed.SId = skill.Id
		feed.FeedType = 0
		feed.CreatedAt = skill.CreatedAt
		err = db.C("feed").Insert(feed)
		if err != nil {
			log.Println(errs.E1012)
		}
	}(pics, skill, user)
}

func SkillList(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	skip, _ := strconv.Atoi(c.Param("skip"))

	skillList := []freecoin.Skill{}
	err := db.C("skill").Find(bson.M{"inStock": true}).Skip(skip).Limit(skillPerPage).Sort("-createdAt").All(&skillList)
	errs.Check400(c, err, errs.E1000)

	newSkillList := []gin.H{}
	for _, s := range skillList {
		u := model.User{}
		err := db.C("user").FindId(s.Owner).Select(bson.M{"avatar": 1, "name": 1, "wealth": 1, "credit": 1}).One(&u)
		if err != nil {
			continue
		}
		newSkillList = append(newSkillList, gin.H{"ownerInfo": u, "skill": s})
	}

	returnSkip := skip + skillPerPage
	if len(newSkillList) < skillPerPage {
		returnSkip = -1
	}

	c.JSON(http.StatusOK, gin.H{"list": newSkillList, "skip": returnSkip})
}

func SkillListByCoinName(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	skip, _ := strconv.Atoi(c.Param("skip"))
	coinName := c.Param("coinName")
	superCoin, _ := strconv.Atoi(c.Param("super"))

	isSuper := false
	if superCoin == 1 {
		isSuper = true
	}

	price := bson.M{"$gt": 0}
	if isSuper {
		price = bson.M{"$eq": 0}
	}

	coinType := freecoin.CoinT{}
	err := db.C("coinT").Find(bson.M{"alias": coinName, "superCoin": isSuper}).One(&coinType)
	errs.Check400(c, err, errs.E1000)

	creator := model.User{}
	err = db.C("user").FindId(coinType.Creator).Select(bson.M{"avatar": 1, "name": 1, "wealth": 1, "credit": 1, "coinAlias": 1, "hasPhoto": 1, "city": 1, "lat": 1, "lng": 1, "openType": 1, "bio": 1, "phone": 1, "phoneCC": 1, "founder": 1, "createdAt": 1}).One(&creator)
	errs.Check400(c, err, errs.E1000)

	skillList := []freecoin.Skill{}
	err = db.C("skill").Find(bson.M{"owner": coinType.Creator, "inStock": true, "price": price}).Skip(skip).Limit(skillPerPage).Sort("-createdAt").All(&skillList)
	errs.Check400(c, err, errs.E1000)

	returnSkip := skip + skillPerPage
	if len(skillList) < skillPerPage {
		returnSkip = -1
	}

	c.JSON(http.StatusOK, gin.H{"list": skillList, "creator": creator, "skip": returnSkip})
}

func SkillListByCoinVision(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	skip, _ := strconv.Atoi(c.Param("skip"))
	cvid := bson.ObjectIdHex(c.Param("cvid"))

	coinV := freecoin.CoinV{}
	err := db.C("coinV").FindId(cvid).One(&coinV)
	errs.Check400(c, err, errs.E1000)

	skillIdList := freecoin.SkillIds{}
	err = db.C("skillIds").FindId(coinV.SkillIdList).One(&skillIdList)
	errs.Check400(c, err, errs.E1000)

	newSkillList := []freecoin.Skill{}
	for i := 0; i < len(skillIdList.List); i++ {
		if i < skip {
			continue
		}
		skill := freecoin.Skill{}
		err := db.C("skill").FindId(skillIdList.List[i]).One(&skill)
		if err != nil {
			continue
		}
		newSkillList = append(newSkillList, skill)
		if i == skip+skillPerPage-1 {
			break
		}
	}

	returnSkip := skip + skillPerPage
	if len(newSkillList) < skillPerPage {
		returnSkip = -1
	}
	c.JSON(http.StatusOK, gin.H{"list": newSkillList, "skip": returnSkip})
}

func SkillListByUser(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	skip, _ := strconv.Atoi(c.Param("skip"))
	uid := bson.ObjectIdHex(c.Param("uid"))

	skillList := []freecoin.Skill{}
	err := db.C("skill").Find(bson.M{"owner": uid, "inStock": true}).Skip(skip).Limit(skillPerPage).Sort("-createdAt").All(&skillList)
	errs.Check400(c, err, errs.E1000)

	returnSkip := skip + skillPerPage
	if len(skillList) < skillPerPage {
		returnSkip = -1
	}

	c.JSON(http.StatusOK, gin.H{"list": skillList, "skip": returnSkip})
}

func SkillById(c *gin.Context) {
	db := c.MustGet("db").(*mgo.Database)
	sid := bson.ObjectIdHex(c.Param("sid"))

	skill := freecoin.Skill{}
	err := db.C("skill").FindId(sid).One(&skill)
	errs.Check400(c, err, errs.E1000)

	passion := freecoin.Passion{}
	err = db.C("passion").FindId(skill.Passion).Select(M{"owner": 1, "md": 1, "title": 1, "desc": 1, "views": 1, "updateAt": 1, "createdAt": 1}).One(&passion)
	errs.Check400(c, err, errs.E1000)
	skill.PassionDetail = passion

	c.JSON(http.StatusOK, skill)
}
